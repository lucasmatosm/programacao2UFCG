/*
 * Aluno: Filipe Pires Guimaraes
 * Mat.: 113110873
 */

package lp2.lab08;
import java.util.*;

/**
 * @author filipepires
 * @version 1.0
 */
public class MeuSistemaSimplesDeTributacao {
	private static Scanner sc;
	private static List<Contribuinte> contribuintes = new ArrayList<Contribuinte>();
	
	public static void main(String[] args) throws Exception {
		int opcao;
		
		do {
			System.out.println("1. Cadastrar contribuintes.\n"
					+ "2. Calcular e mostrar impostos e descontos associados a um contribuinte.\n"
					+ "3. Mostrar a quantidade de contribuintes por profissão.\n"
					+ "4. Listar os contribuintes em função dos sinais exteriores de riqueza indicando se são "
					+ "excessivos ou não.\n"
					+ "5. Sair.");
			
			System.out.print("\nOpção: ");
			opcao = lerInteiro();
			
			switch (opcao) {
			case 1:
				cadastrarContribuinte();
				System.out.println("****************************");
				break;
			case 2:
				if(contribuintes.size() < 1) System.out.println("Não existe contribuinte cadastrado!\n");
				else calculaContribuinte();
				System.out.println("****************************");
				break;
			case 3:
				if(contribuintes.size() < 1) System.out.println("Não existe contribuinte cadastrado!\n");
				else System.out.println(quantContribuinte());
				System.out.println("****************************");
				break;
			case 4:
				if(contribuintes.size() < 1) System.out.println("Não existe contribuinte cadastrado!\n");
				else System.out.println(listarSinaisExcessivos());
				System.out.println("****************************");
				break;
			case 5:
				System.out.println("Programa finalizado!");
				break;
				
			default:
				System.out.println("Opção invalida!\n");
				System.out.println("****************************");
				break;
			}
		} while (opcao != 5);
		
	}
	
	/**
	 *  Cadastra os contribuintes em uma lista
	 * @throws Exception Caso alguma informacao do contribuinte esteja errada
	 */
	private static void cadastrarContribuinte() throws Exception {
		Contribuinte novoContribuinte = null;
		int opcao = 0;
		
		System.out.print("1. Caminhoneiro\n"
				+ "2. Medico\n"
				+ "3. Professor\n"
				+ "4. Taxista\n"
				+ "\nOpção: ");
		opcao = lerInteiro();
		
		switch (opcao) {
		case 1:
			novoContribuinte = Caminhoneiro();
			contribuintes.add(novoContribuinte);
			break;
		case 2:
			novoContribuinte = Medico();
			contribuintes.add(novoContribuinte);
			break;
		case 3:
			novoContribuinte = Professor();
			contribuintes.add(novoContribuinte);
			break;
		case 4:
			novoContribuinte = Taxista();
			contribuintes.add(novoContribuinte);
			break;

		default:
			System.out.print("Opção invalida!");
			break;
		}
	}
	
	/**
	 * Calcula e imprime na tela as informacoes dos contribuintes
	 */
	private static void calculaContribuinte() {
		for(int i=0; i<contribuintes.size(); i++)
			System.out.println((i+1)+" "+contribuintes.get(i).getCpf()+" - "+contribuintes.get(i).getNome()+";");
		
		System.out.print("Qual contribuinte: ");
		int opcao = lerInteiro();
		
		Contribuinte contribuinte = contribuintes.get(opcao-1);
		System.out.println("\nNome: "+contribuinte.getNome()
				+"\nCPF: "+contribuinte.getCpf()
				+"\nImpostos: R$"+ contribuinte.calculoTributacao()
				+"\nDesconto: R$"+ contribuinte.calculoDesconto()
				+"\nValor para pagar: R$" + contribuinte.calculoImposto()
				+"\n");
	}

	/**
	 * Imprime na tela a lista dos contribuintes e se existem sinais excessivos de riqueza
	 * @return Retorna uma lista dos contribuintes em funcao dos sinais excessivos de riqueza
	 */
	private static String listarSinaisExcessivos(){
		String frase  = "Nome / Sinais de Riqueza";
		for(int i=0; i < contribuintes.size(); i++)
			frase += contribuintes.get(i).getNome() + " / " +contribuintes.get(i).sinaisExcesso(valorMedioProfissao(contribuintes.get(i)));
		return frase;
	}
	
	/**
	 * Calcula a quantidade de contribuintes por profissao
	 * @return Retorna a quantidade de contribuintes por profissao
	 */
	private static String quantContribuinte(){
		int caminhoneiro = 0, medico = 0, professor = 0, taxista = 0;
		for(int i=0; i < contribuintes.size(); i++){
			if(contribuintes.get(i).getClass().getSimpleName().equals("Caminhoneiro")) caminhoneiro++;
			else if(contribuintes.get(i).getClass().getSimpleName().equals("Medico")) medico++;
			else if(contribuintes.get(i).getClass().getSimpleName().equals("Professor")) professor++;
			else taxista++;
		}
		return "Caminhoneiro: "+caminhoneiro+"\nMedico: "+medico+"\nProfessor: "+professor+"\nTaxista: "+taxista;
	}

	/**
	 * Metodo para cadastrar um contribuinte caminhoneiro
	 * @return Retorna os dados do caminhoneiro
	 * @throws Exception Caso os dados do caminhoneiro sejam invalidos
	 */
	private static Contribuinte Caminhoneiro() throws Exception {
		String nome = lerNome(), num = lerCpf();
		int km, toneladas;
		System.out.print("Quantos Km percorridos: ");
		km = lerInteiro();
		System.out.print("Quantas toneladas transportadas: ");
		toneladas = lerInteiro();
		
		Contribuinte caminhoneiro = new Caminhoneiro(nome, num, km, toneladas);
		return caminhoneiro;
	}
	
	/**
	 * Metodo para cadastrar um contribuinte medico
	 * @return Retorna os dados do medico
	 * @throws Exception Caso os dados do medico sejam invalidos
	 */
	private static Contribuinte Medico() throws Exception {
		String nome = lerNome(), num = lerCpf();
		int paciente;
		double despesas;
		System.out.print("Quantos pacientes atendidos: ");
		paciente = lerInteiro();
		System.out.print("Qual o valor das despesas em congresso: ");
		despesas = lerDouble();
		
		Contribuinte medico = new Medico(nome, num, paciente, despesas);
		return medico;
	}
	
	/**
	 * Metodo para cadastrar um contribuinte professor
	 * @return Retorna os dados do professor
	 * @throws Exception Caso os dados do professor sejam invalidos
	 */
	private static Contribuinte Professor() throws Exception {
		String nome = lerNome(), num = lerCpf();
		double despesas;
		System.out.print("Qual as despesas com materiais escolares: ");
		despesas = lerDouble();
		
		Contribuinte professor = new Professor(nome, num, despesas);
		return professor;
	}
	
	/**
	 * Metodo para cadastrar um contribuinte taxista
	 * @return Retorna os dados do taxista
	 * @throws Exception Caso os dados do taxista sejam invalidos
	 */
	private static Contribuinte Taxista() throws Exception {
		String nome = lerNome(), num = lerCpf();
		int km, passageiros;
		System.out.print("Quantos Km percorridos: ");
		km = lerInteiro();
		System.out.print("Quantos passageiros atendidos: ");
		passageiros = lerInteiro();
		
		Contribuinte taxista = new Taxista(nome, num, km, passageiros);
		return taxista;
	}
	
	/**
	 * Calcula o total os bens por profissao
	 * @param contribuinte Contribuinte para consulta da profissao
	 * @return Retorna o total os bens por profissao
	 */
	private static double valorMedioProfissao(Contribuinte contribuinte){
		double valorMedio = 0;
		for(int i=0; i< contribuintes.size(); i++)
			if((contribuinte.getClass().getSimpleName()).equals(contribuintes.get(i).getClass().getSimpleName()))
				valorMedio += contribuintes.get(i).valorDosBens();
		return valorMedio;
	}

	/**
	 * Ler do teclado um valor Inteiro
	 * @return Retorna o valor Inteiro lido pelo teclado
	 */
	private static int lerInteiro(){
		sc = new Scanner(System.in);
		return sc.nextInt();
	}
	
	/**
	 * Ler do teclado um valor Double
	 * @return Retonar o valor lido pelo teclado
	 */
	private static double lerDouble(){
		sc = new Scanner(System.in);
		return sc.nextDouble();
	}
	
	/**
	 * Ler do teclado uma String
	 * @return Retorna o nome do contribuinte
	 */
	private static String lerNome(){
		sc = new Scanner(System.in);
		System.out.print("Digite seu nome: ");
		return sc.nextLine();
	}
	
	/**
	 * Ler do teclado uma String
	 * @return Retorna o CPF do contribuinte
	 */
	private static String lerCpf(){
		sc = new Scanner(System.in);
		System.out.print("Digite seu CPF: ");
		return sc.nextLine();
	}
	
}
