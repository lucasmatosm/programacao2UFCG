/*
 * Aluno: Filipe Pires Guimaraes
 * Mat.: 113110873
 */

package lp2.lab08;

/**
 * @author filipepires
 * @version 1.0
 * @category financeiro
 */
public class Rodoviario extends Contribuinte{
	protected double quilometros;
	
	/**
	 * Construtor da classe Rodoviario
	 * @param nome Nome do Rodoviario
	 * @param num CPF do Rodoviario
	 * @param quilometros Km rodados pelo taxista
	 * @throws Exception Caso o nome e/ou CPF estejam invalidos
	 */
	public Rodoviario(String nome, String num, double quilometros) throws Exception{
		super(nome, num);
		this.quilometros = quilometros;
	}
	
	/**
	 * Seta a quantidade de quilometros do rodoviario
	 * @param quant quantidade de Km do rodoviario
	 */
	public void setQuilometros(double quant) {
		this.quilometros = quant;
	}
	
	@Override
	public double calculoDesconto(){
		return quilometros * 0.01;
	}
}
