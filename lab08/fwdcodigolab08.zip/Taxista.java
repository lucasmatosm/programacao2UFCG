/*
 * Aluno: Filipe Pires Guimaraes
 * Mat.: 113110873
 */

package lp2.lab08;

/**
 * @author filipepires
 * @version 1.0
 * @category financeiro
 */
public class Taxista extends Rodoviario {
	private int passageiro = 0;
	
	/**
	 * Construtor da classe taxista
	 * @param nome Nome do taxista
	 * @param num CPF do taxista
	 * @param quilometros Km rodados pelo taxista
	 * @param passageiro Quantidade de passageiros transportado pelo taxista
	 * @throws Exception Caso o nome e/ou CPF estejam invalidos
	 */
	public Taxista(String nome, String num, int quilometros, int passageiro) throws Exception{
		super(nome, num, quilometros);
		this.passageiro = passageiro;
	}
	
	/**
	 * Seta a quantidade de passageiros do taxista
	 * @param quant Quantidade de passageiros transportado pelo taxista
	 */
	public void setPassageiro(int quant) {
		this.passageiro = quant;
	}
	
	@Override
	public double calculoTributacao(){
		return passageiro*0.5;
	}

}
