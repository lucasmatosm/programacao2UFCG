/*
 * Aluno: Filipe Pires Guimaraes
 * Mat.: 113110873
 */

package lp2.lab08;

/**
 * @author filipepires
 * @version 1.0
 * @category financeiro
 */
public class Medico extends Contribuinte {
	private int pacientes;
	private double despesasCongresso;

	/**
	 * Construtor da classe Medico
	 * @param nome Nome do medico
	 * @param num CPF do medico
	 * @param pacientes Pacientes atendidos pelo medico
	 * @param despesas Despesas gastas em congresso pelo medico
	 * @throws Exception Caso os dados do medico sejam invalidos
	 */
	public Medico(String nome, String num, int pacientes, double despesas) throws Exception {
		super(nome, num);
		this.pacientes = pacientes;
		this.despesasCongresso = despesas;
	}
	
	/**
	 * Seta a quantidade de pacientes
	 * @param quant Quantidade de pacientes atendidos pelo medico
	 */
	public void setPacientes(int quant) {
		this.pacientes = quant;
	}
	
	/**
	 * Seta o valor das despesas
	 * @param valor Valor das despesas gastos em congresso pelo medico
	 */
	public void setDespesas(double valor) {
		this.despesasCongresso = valor;
	}
	
	@Override
	public double calculoTributacao(){
		return pacientes * 10;
	}
	
	@Override
	public double calculoDesconto(){
		return despesasCongresso;
	}

}
