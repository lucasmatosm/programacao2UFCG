/*
 * Aluno: Filipe Pires Guimaraes
 * Mat.: 113110873
 */

package lp2.lab08;

/**
 * @author filipepires
 * @version 1.0
 * @category financeiro
 */
public class Caminhoneiro extends Rodoviario{
	private int toneladas;
	
	/**
	 * Construtor da classe Caminhoneiro
	 * @param nome Nome do caminhoneiro
	 * @param num CPF do caminhoneiro
	 * @param quilometros Km rodados pelo caminhoneiro
	 * @param toneladas Toneladas transportadas pelo caminhoneiro
	 * @throws Exception Caso os dados do caminhoneiro sejam invalidos
	 */
	public Caminhoneiro(String nome, String num, int quilometros, int toneladas) throws Exception {
		super(nome, num, quilometros);
		this.toneladas = toneladas;
	}
	
	/**
	 * Seta a quantidade de toneladas transportadas pelo caminhoneiro
	 * @param quant quantidade de toneladas transportadas pelo caminhoneiro
	 */
	public void setToneladas(int quant){
		this.toneladas = quant;
	}
	
	@Override
	public double calculoTributacao(){
		if(toneladas <= 10) return 500;
		return 500 + ((toneladas - 10) * 100);
	}
	
}
