/*
 * Aluno: Filipe Pires Guimaraes
 * Mat.: 113110873
 */

package lp2.lab08;

/**
 * @author filipepires
 * @version 1.0
 * @category financeiro
 */
public class Professor extends Contribuinte {
	private double despesasMateriais;
	
	/**
	 * Construtor da classe Professor
	 * @param nome Nome do professor
	 * @param num CPF do professor
	 * @param salarioBase Salario do professor
	 * @param despesas Despesas gastas com materiais escolares
	 * @throws Exception Caso os dados do professor sejam invalidos
	 */
	public Professor(String nome, String num,  double despesas) throws Exception {
		super(nome, num);
		this.despesasMateriais = despesas;
	}
	
	/**
	 * Seta o valor das despesas
	 * @param valor Valor das despesas do professor com materiais escolares
	 */
	public void setDespesas(double valor) {
		this.despesasMateriais = valor;
	}
	
	@Override
	public double calculoTributacao(){
		return 0;
	}
	
	@Override
	public double calculoDesconto(){
		return despesasMateriais / 2;
	}

}
