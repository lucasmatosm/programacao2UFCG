/*
 * Aluno: Filipe Pires Guimaraes
 * Mat.: 113110873
 */

package lp2.lab08;

/**
 * @author filipepires
 * @version 1.0
 * @category financeiro
 */
public class Contribuinte {
	private String nome, cpf;
	double carro = 0, casa = 0;
	
	/**
	 * Construtor da clase Contribuinte
	 * @param nome Nome do contribuinte
	 * @param cpf CPF do contribuinte
	 * @throws Exception Caso o nome ou o CPF sejam invalidos
	 */
	public Contribuinte(String nome, String cpf) throws Exception{
		if(nome.trim().isEmpty() || cpf.trim().isEmpty()) new Exception("Nome e/ou num invalido!");
		
		this.nome = nome;
		this.cpf = cpf;
	}
	
	/**
	 * Acessador do nome.
	 * @return Retorna o nome do contribuinte
	 */
	public String getNome(){
		return nome;
	}
	
	/**
	 * Acessador do CPF
	 * @return Retorna o CPF do contribuinte
	 */
	public String getCpf(){
		return cpf;
	}
	
	/**
	 * Seta  o valor do carro
	 * @param valor Valor do carro  do contribuinte, se o valor for 0 quer dizer que o contribuinte nao tem carro
	 * @throws Exception Caso o valor declarado seja menor que zero
	 */
	public void setCarro(double valor) throws Exception{
		if(valor < 0) new Exception("Valor invalido!");
		this.carro = valor;
	}
	
	/**
	 * Seta  o valor da casa
	 * @param valor Valor da casa  do contribuinte, se o valor for 0 quer dizer que o contribuinte nao tem casa
	 * @throws Exception Caso o valor declarado seja menor que zero
	 */
	public void setCasa(double valor) throws Exception{
		if(valor < 0) new Exception("Valor invalido!");
		this.casa = valor;
	}
	
	/**
	 * Calcula o valor dos bens
	 * @return Retorna o valor dos bens do contribuinte (Casa + Carro)
	 */
	public double valorDosBens(){
		return casa+carro;
	}
	
	/**
	 * Calcula o valor da tributacao
	 * @return Retorna o valor da tributacao do contribuinte
	 */
	public double calculoTributacao(){
		return 0;
	}
	
	/**
	 * Calcula o valor do desconto
	 * @return Retorna o valor dos descontos do contribuinte
	 */
	public double calculoDesconto(){
		return 0;
	}
	
	/**
	 * Calcula o valor dos impostos a pagar
	 * @return Retorna o valor dos impostos que o contribuinte ira pagar, caso o desconto seja maior o contribuinte nao pagara imposto.
	 */
	public double calculoImposto(){
		if(calculoDesconto() > calculoTributacao()) return 0;
		return calculoTributacao() - calculoDesconto();
	}
	
	/**
	 * Informa se o contribuinte existe sinais de riqueza excessiva
	 * @param valorMedio Valor ao qual os bens do contribuinte serao comparados
	 * @return Retorna <b>true</b> se os sinais de riqueza forem existentes e <b>false</b> senao existirem.
	 */
	public boolean sinaisExcesso(double valorMedio){
		if(valorDosBens() > (valorMedio * 1.5)) return true;
		return false;
	}
	
}
