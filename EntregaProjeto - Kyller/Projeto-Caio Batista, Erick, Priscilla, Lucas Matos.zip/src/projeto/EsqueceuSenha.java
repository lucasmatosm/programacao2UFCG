package projeto;


import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;

import javax.swing.*;



/**
 * Classe para recuperacao de senha
 */
	public class EsqueceuSenha extends JFrame {
		
		/**
		 * 
		 */
		private static final long serialVersionUID = -1912392693134449594L;
  
		private JLabel labelUser;
		private JLabel pergunta;
		private JLabel resposta;
		private JLabel labelSenha;
		private JLabel labelRepetirSenha;
		private JTextField textuser;
		private JPasswordField textSenha;
		private JPasswordField textRepetirSenha;
		private JTextField textResposta;
		private JButton buttonModificar;
		private String escolhido2;
		private boolean verdade = true;
		
		/**
		 * Construtor da classe
		 */
		public EsqueceuSenha(){
		super(".:: CLEP Bol�o - FIFA World Cup 2014");
	
		labelUser = new JLabel("Login:");
		labelUser.setBounds(120, 50, 58, 14);
		labelSenha = new JLabel("Nova senha:");
		labelSenha.setBounds(120, 81, 79, 14);
		labelRepetirSenha = new JLabel("Repetir senha:");
		labelRepetirSenha.setBounds(120, 112, 95, 14);
        pergunta = new JLabel("Escolha a pergunta de seguran�a:");
        pergunta.setBounds(24, 140, 207, 14);
        resposta = new JLabel("Digite a resposta de seguran�a:");
        resposta.setBounds(24, 170, 191, 14);
		textuser = new JTextField(47);
		textuser.setBounds(212, 47, 109, 20);
		textSenha = new JPasswordField(47);
		textSenha.setBounds(212, 75, 109, 20);
		textRepetirSenha = new JPasswordField(47);
		textRepetirSenha.setBounds(212, 106, 109, 20);
		textResposta = new JTextField(47);
		textResposta.setBounds(230, 167, 239, 20);

		JComboBox<String> jComboBox2 = new JComboBox<String>();
		jComboBox2.setBounds(230, 137, 239, 20);
		JComboBox<String> ecolha2 = jComboBox2;
		ecolha2.addActionListener(new ActionListener(){
		@Override
		public void actionPerformed(ActionEvent f) {
			JComboBox<?> cb2 = (JComboBox<?>)f.getSource();
			escolhido2 = (String)cb2.getSelectedItem();	 	
		}});
		
		jComboBox2.addItem("Qual foi nome do seu primeiro cachorro?");
		jComboBox2.addItem("Qual o nome de solteira da sua m�e?");
		jComboBox2.addItem("Onde seu pai nasceu?");
		jComboBox2.addItem("Qual a primeira escola que voc� estudou?");
		textSenha.setEchoChar('*');
		textRepetirSenha.setEchoChar('*');
		
		buttonModificar = new JButton("Modificar Senha");
		buttonModificar.setBounds(187, 215, 133, 23);
		buttonModificar.addActionListener(new ActionListener() {
			/**
			 * Metodo que modifica a senha ao clicar no botao
			 * @param ActionEvent e
			 */
			public void actionPerformed(ActionEvent e) {
				String u = textuser.getText();
				@SuppressWarnings("deprecation")
				String s = textSenha.getText();
				@SuppressWarnings("deprecation")
				String em = textRepetirSenha.getText();
				String r = textResposta.getText().toLowerCase();
				if( s.equals("") || u.equals("") || em.equals("") || r.equals("")){
					JOptionPane.showMessageDialog(null,"Campos n�o preenchidos");
				}else if(!(s.equals(em))){
					JOptionPane.showMessageDialog(null,"As senhas devem ser iguais");
				}
				else if(s.length() < 6 || s.length() > 8){
					JOptionPane.showMessageDialog(null,"As senhas devem conter entre 6 e 8 caracteres");	
				}
				
				else{
					
					Output login = new Output();
					login.openfile();
					login.lerarquivo();
					for (int i = 0; i < login.usalista().size(); i++) {
						if (u.equals(login.usalista().get(i).getLogin()) && escolhido2.equals(login.usalista().get(i).getPergunta())
								&& r.equals(login.usalista().get(i).getResposta().toLowerCase())){
							login.usalista().get(i).setSenha(s);
							verdade = true;
							break;
							}	
						verdade = false;
						}
					login.closefile();
					if(verdade == true){
						Input remove = new Input();
						try {
							remove.openfile();
						} catch (FileNotFoundException f) {
							f.printStackTrace();
						}
						for (int i = 0; i < login.usalista().size(); i++) {
							remove.Gravaarquivo(login.usalista().get(i));
						}
						remove.closefile();
						JOptionPane.showMessageDialog(null,"Senha alterada com sucesso");
					}	
					else{
						JOptionPane.showMessageDialog(null,"Dados incorretos");
					}
					}
						
					

		}
					
			}
				
				
				
			);
		
		
		Container pane = this.getContentPane();
		getContentPane().setLayout(null);
		
		
		pane.add(labelUser);
		pane.add(textuser);
		pane.add(labelSenha);
		pane.add(textSenha);
		pane.add(labelRepetirSenha);
		pane.add(textRepetirSenha);
		pane.add(pergunta);
		pane.add(jComboBox2);
		pane.add(resposta);
		pane.add(textResposta);
		pane.add(buttonModificar);
		
		this.setSize(500, 292);
		this.setResizable(false); 
		this.setVisible(true);
        
		}		
	}
