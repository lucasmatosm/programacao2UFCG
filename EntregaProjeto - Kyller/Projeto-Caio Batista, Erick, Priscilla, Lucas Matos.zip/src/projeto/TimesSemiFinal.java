package projeto;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class TimesSemiFinal extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3499063038405611833L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private List<String> resultsuser = new ArrayList<String>();
	private boolean mudarApostas;
	private Usuario user;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TimesSemiFinal frame = new TimesSemiFinal(false,null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TimesSemiFinal(final boolean mudarApostas, final Usuario user) {
		this.mudarApostas = mudarApostas;
		this.user = user;
		
		setBounds(100, 100, 385, 182);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel label = new JLabel("Jogo 1:");
		label.setBounds(10, 14, 46, 14);
		contentPane.add(label);

		JLabel label_1 = new JLabel(pegaTime(0,1));
		label_1.setBounds(66, 14, 106, 14);
		contentPane.add(label_1);

		textField = new JTextField(retornaApostaCasoExista(mudarApostas, 6, 0));
		textField.setColumns(10);
		textField.setBounds(164, 11, 23, 20);
		contentPane.add(textField);

		JLabel label_2 = new JLabel("X");
		label_2.setBounds(201, 14, 23, 14);
		contentPane.add(label_2);

		textField_1 = new JTextField(retornaApostaCasoExista(mudarApostas, 6, 1));
		textField_1.setColumns(10);
		textField_1.setBounds(221, 11, 23, 20);
		contentPane.add(textField_1);

		JLabel label_3 = new JLabel(pegaTime(0,2));
		label_3.setBounds(266, 14, 105, 14);
		contentPane.add(label_3);

		JLabel label_4 = new JLabel("Jogo 2:");
		label_4.setBounds(10, 42, 46, 14);
		contentPane.add(label_4);

		JLabel label_5 = new JLabel(pegaTime(1,1));
		label_5.setBounds(66, 42, 106, 14);
		contentPane.add(label_5);

		textField_2 = new JTextField(retornaApostaCasoExista(mudarApostas, 6, 2));
		textField_2.setColumns(10);
		textField_2.setBounds(164, 39, 23, 20);
		contentPane.add(textField_2);

		JLabel label_6 = new JLabel("X");
		label_6.setBounds(201, 42, 23, 14);
		contentPane.add(label_6);

		textField_3 = new JTextField(retornaApostaCasoExista(mudarApostas, 6, 3));
		textField_3.setColumns(10);
		textField_3.setBounds(221, 39, 23, 20);
		contentPane.add(textField_3);

		JLabel label_7 = new JLabel(pegaTime(1,2));
		label_7.setBounds(266, 42, 105, 14);
		contentPane.add(label_7);

		JButton btnConclur = new JButton("Concluir");
		btnConclur.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if(user instanceof Administrador){

					resultsuser.add(textField.getText());
					resultsuser.add(textField_1.getText());
					resultsuser.add(textField_2.getText());
					resultsuser.add(textField_3.getText());




					Outputtimes f = new Outputtimes(); //cria objeto do tipo output
					f.openfile(); //abre o arquivo
					f.lerarquivo(); // le todos os objeto e salva em um arquivo
					for (Resultado r: f.retornaArquivoFases()) {

						if (r.getFase().equals("Semifinal")){// verifica se o usuario é do tipo administrador
							r.setResultados(resultsuser);	
						}
					}

					Inputtimes atualiza = new Inputtimes();
					try {
						atualiza.openfile();
					} catch (FileNotFoundException e1) {

						e1.printStackTrace();
					}

					for(Resultado r2 : f.retornaArquivoFases()){
						
							atualiza.Gravaarquivo(r2);
						
					}

					f.closefile();
					atualiza.closefile();
					
					calculaPontosDeTodosOsUsuarios(6);
					
					JOptionPane.showMessageDialog(null,"Resultados atualizados com sucesso");
					dispose();
					
				}else{

					resultsuser.add(textField.getText());
					resultsuser.add(textField_1.getText());
					resultsuser.add(textField_2.getText());
					resultsuser.add(textField_3.getText());
					Jogador apostador = (Jogador) user;


					Output usuario = new Output();
					usuario.openfile();
					usuario.lerarquivo();

					for (Usuario user2: usuario.usalista()) {
						if(user2.getLogin().equals(apostador.getLogin())){
							apostador.getApostas().add(6,((ArrayList<String>) resultsuser));
							apostador.getApostas().remove(7);

						}
					}
					usuario.closefile();
					Input Usuario2 = new Input();
					try {
						Usuario2.openfile();
					} catch (FileNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}

					int controle = 1;

					for (Usuario  user4 : usuario.usalista()) {
						if(user4.getLogin().equals(apostador.getLogin())){
							if (user4 instanceof Jogador && controle == 1){
								controle++;	
								Jogador	user3 = (Jogador) user4;


								user3.setapostas(apostador.getApostas());
								Usuario2.Gravaarquivo(user3);

							}	
						}
						else{
							Usuario2.Gravaarquivo(user4);
						}





					}
					Usuario2.closefile();

					JOptionPane.showMessageDialog(null,"Resultados atualizados com sucesso");
					dispose();
				}





			}
		});
		btnConclur.setBounds(135, 97, 89, 23);
		contentPane.add(btnConclur);
	}

	private String pegaTime(int jogo, int time){
		Outputtimes f = new Outputtimes();
		f.openfile();
		f.lerarquivo();

		Resultado re = null;
		List<String> primeiroTime = new ArrayList<String>();
		List<String> segundoTime = new ArrayList<String>();

		for (Resultado r: f.retornaArquivoFases()){
			if (r.getFase().equals("Semifinal")){
				re = r;
				break;
			}
		}

		f.closefile();

		for (int i= 0; i < re.getTimes().size(); i++){
			if (i % 2 == 0)
				primeiroTime.add(re.getTimes().get(i));
			else
				segundoTime.add(re.getTimes().get(i));
		}

		if (time == 1){
			return primeiroTime.get(jogo);
		}else{
			return segundoTime.get(jogo);
		}
	}
	
	
	private  void calculaPontosDeTodosOsUsuarios(int rodada){

		CalculaPontosSemiFinal c1 = new CalculaPontosSemiFinal();

		Output usuario = new Output();
		usuario.openfile();
		usuario.lerarquivo();
		
		List<ArrayList<String>> c = new ArrayList<ArrayList<String>>();

		for (Usuario user2: usuario.usalista()) {
			Usuario user21 = user2;
			try{
			c = user21.getApostas();
			}catch(Exception e){
				c = null;
			}
		
			if (!(user21  instanceof Administrador)){
			
				if((user21.getApostas().isEmpty()) || c.get(rodada - 1).isEmpty()){ 
					user21.setPontos(user21.getPontos() + 0);
				}else{
					user21.setPontos(user21.getPontos() + c1.calculaPontos(rodada, user21));

				}
			
			
			}
		}

		usuario.openfile();
		Input Usuario2 = new Input();
		try {
			Usuario2.openfile();
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		for (Usuario  user3 : usuario.usalista()) {
			Usuario2.Gravaarquivo(user3);
		}
		Usuario2.closefile();




	}
	
private String retornaApostaCasoExista(boolean mudarAposta, int rodada, int aposta){
		
		mudarAposta = mudarApostas; 
		
		if (mudarAposta){
			
			Output g = new Output();
			g.openfile();
			g.lerarquivo();
			
			for (Usuario r : g.usalista()) {
				if (!(r instanceof Administrador)){
					if (r.getLogin().equals(user.getLogin())){
						return user.getApostas().get(rodada - 1).get(aposta);
						}
					}
				}
		}
		
		return "0";
		
		
		
	}




}
