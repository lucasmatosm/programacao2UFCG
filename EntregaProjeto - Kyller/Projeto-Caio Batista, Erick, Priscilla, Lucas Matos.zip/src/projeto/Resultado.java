/**
 * 
 */
package projeto;

import java.io.Serializable;
import java.util.*;

/**
 * @author CLEP
 *
 */
public class Resultado implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private List<String> times = new ArrayList<String>();
	private List<String> resultados = new ArrayList<String>();
	private String fase;
	
	
	
	public Resultado(String fase, List<String> times, List<String> resultados){
		this.fase = fase;
		this.times = times;
		this.resultados = resultados;
		
	}



	public List<String> getTimes() {
		return times;
	}



	public void setTimes(List<String> times) {
		this.times = times;
	}



	public List<String> getResultados() {
		return resultados;
	}



	public void setResultados(List<String> resultados) {
		this.resultados = resultados;
	}



	public String getFase() {
		return fase;
	}



	public void setFase(String fase) {
		this.fase = fase;
	}



	@Override
	public String toString() {
		return "Resultado [" + "getTimes()=" + getTimes()
				+ ", getResultados()=" + getResultados() + ", getFase()="
				+ getFase() + "]";
	}
	
	
	

}
