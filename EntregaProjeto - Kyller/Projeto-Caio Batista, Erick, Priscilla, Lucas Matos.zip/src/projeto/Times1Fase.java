package projeto;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Times1Fase extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * Create the panel.
	 */
	private String Login;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTextField textField_10;
	private JTextField textField_11;
	private JTextField textField_12;
	private JTextField textField_13;
	private JTextField textField_14;
	private JTextField textField_15;
	private JTextField textField_16;
	private JTextField textField_17;
	private JTextField textField_18;
	private JTextField textField_19;
	private JTextField textField_20;
	private JTextField textField_21;
	private JTextField textField_22;
	private JTextField textField_23;
	private JTextField textField_24;
	private JTextField textField_25;
	private JTextField textField_26;
	private JTextField textField_27;
	private JTextField textField_28;
	private JTextField textField_29;
	private JTextField textField_30;
	private JTextField textField_31;
	private Usuario user;
	private int fase;
	private boolean mudarApostas;
	protected List<String> resultsuser = new ArrayList<String>();
	private List<String> results = new ArrayList<String>();
	private List<String> times = new ArrayList<String>();


	public Times1Fase(final boolean mudarApostas, final int fase, final Usuario user) {
		this.fase = fase;
		this.user = user;
		this.mudarApostas = mudarApostas;

		setBounds(100, 100,385, 520);


		getContentPane().setLayout(null);

		JPanel contentPane = new JPanel();

		contentPane.setLayout(null);

		JLabel lblJogo = new JLabel("Jogo 1:");
		lblJogo.setBounds(10, 11, 46, 14);
		contentPane.add(lblJogo);

		JLabel lblHaha = new JLabel(pegaTime(0,1));
		lblHaha.setBounds(66, 11, 106, 14);
		contentPane.add(lblHaha);

		textField = new JTextField(retornaApostaCasoExista(mudarApostas, fase, 0));
		textField.setBounds(164, 8, 23, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		JLabel lblX = new JLabel("X");
		lblX.setBounds(201, 11, 23, 14);
		contentPane.add(lblX);

		textField_1 = new JTextField(retornaApostaCasoExista(mudarApostas, fase, 1));
		textField_1.setBounds(221, 8, 23, 20);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		JLabel label = new JLabel(pegaTime(0,2));
		label.setBounds(266, 11, 105, 14);
		contentPane.add(label);

		JLabel lblJogo_1 = new JLabel("Jogo 2:");
		lblJogo_1.setBounds(10, 36, 46, 14);
		contentPane.add(lblJogo_1);

		JLabel label_2 = new JLabel(pegaTime(1,1));
		label_2.setBounds(66, 36, 106, 14);
		contentPane.add(label_2);

		textField_2 = new JTextField(retornaApostaCasoExista(mudarApostas, fase, 2));
		textField_2.setColumns(10);
		textField_2.setBounds(164, 36, 23, 20);
		contentPane.add(textField_2);

		JLabel label_3 = new JLabel("X");
		label_3.setBounds(201, 33, 11, 14);
		contentPane.add(label_3);

		textField_3 = new JTextField(retornaApostaCasoExista(mudarApostas, fase, 3));
		textField_3.setColumns(10);
		textField_3.setBounds(221, 36, 23, 20);
		contentPane.add(textField_3);

		JLabel label_4 = new JLabel(pegaTime(1,2));
		label_4.setBounds(266, 36, 105, 14);
		contentPane.add(label_4);

		JLabel lblJogo_2 = new JLabel("Jogo 3:");
		lblJogo_2.setBounds(10, 61, 46, 14);
		contentPane.add(lblJogo_2);

		JLabel lblJogo_3 = new JLabel("Jogo 4:");
		lblJogo_3.setBounds(10, 86, 46, 14);
		contentPane.add(lblJogo_3);

		JLabel lblJogo_4 = new JLabel("Jogo 5:");
		lblJogo_4.setBounds(10, 111, 46, 14);
		contentPane.add(lblJogo_4);

		JLabel lblJogo_5 = new JLabel("Jogo 6:");
		lblJogo_5.setBounds(10, 136, 46, 14);
		contentPane.add(lblJogo_5);

		JLabel lblJogo_6 = new JLabel("Jogo 7:");
		lblJogo_6.setBounds(10, 161, 46, 14);
		contentPane.add(lblJogo_6);

		JLabel lblJogo_7 = new JLabel("Jogo 8:");
		lblJogo_7.setBounds(10, 186, 46, 14);
		contentPane.add(lblJogo_7);

		JLabel lblJogo_8 = new JLabel("Jogo 9:");
		lblJogo_8.setBounds(10, 211, 46, 14);
		contentPane.add(lblJogo_8);

		JLabel lblJogo_9 = new JLabel("Jogo 10:");
		lblJogo_9.setBounds(10, 236, 56, 14);
		contentPane.add(lblJogo_9);

		JLabel lblJogo_10 = new JLabel("Jogo 11:");
		lblJogo_10.setBounds(10, 261, 56, 14);
		contentPane.add(lblJogo_10);

		JLabel lblJogo_11 = new JLabel("Jogo 12:");
		lblJogo_11.setBounds(10, 286, 56, 14);
		contentPane.add(lblJogo_11);

		JLabel lblJogo_12 = new JLabel("Jogo 13:");
		lblJogo_12.setBounds(10, 311, 56, 14);
		contentPane.add(lblJogo_12);

		JLabel lblJogo_13 = new JLabel("Jogo 14:");
		lblJogo_13.setBounds(10, 336, 56, 14);
		contentPane.add(lblJogo_13);

		JLabel lblJogo_14 = new JLabel("Jogo 15:");
		lblJogo_14.setBounds(10, 361, 56, 14);
		contentPane.add(lblJogo_14);

		JLabel lblJogo_15 = new JLabel("Jogo 16:");
		lblJogo_15.setBounds(10, 386, 56, 14);
		contentPane.add(lblJogo_15);

		JLabel label_1 = new JLabel((pegaTime(2,1)));
		label_1.setBounds(66, 60, 106, 14);
		contentPane.add(label_1);

		textField_4 = new JTextField(retornaApostaCasoExista(mudarApostas, fase, 4));
		textField_4.setColumns(10);
		textField_4.setBounds(164, 61, 23, 20);
		contentPane.add(textField_4);

		JLabel label_5 = new JLabel("X");
		label_5.setBounds(201, 61, 11, 14);
		contentPane.add(label_5);

		textField_5 = new JTextField(retornaApostaCasoExista(mudarApostas, fase, 5));
		textField_5.setColumns(10);
		textField_5.setBounds(221, 61, 23, 20);
		contentPane.add(textField_5);

		JLabel label_6 = new JLabel(pegaTime(2,2));
		label_6.setBounds(266, 61, 105, 14);
		contentPane.add(label_6);

		JLabel label_7 = new JLabel(pegaTime(3,1));
		label_7.setBounds(66, 86, 106, 14);
		contentPane.add(label_7);

		textField_6 = new JTextField(retornaApostaCasoExista(mudarApostas, fase, 6));
		textField_6.setColumns(10);
		textField_6.setBounds(164, 86, 23, 20);
		contentPane.add(textField_6);

		JLabel label_8 = new JLabel("X");
		label_8.setBounds(201, 86, 11, 14);
		contentPane.add(label_8);

		textField_7 = new JTextField(retornaApostaCasoExista(mudarApostas, fase, 7));
		textField_7.setColumns(10);
		textField_7.setBounds(221, 86, 23, 20);
		contentPane.add(textField_7);

		JLabel label_9 = new JLabel(pegaTime(3,2));
		label_9.setBounds(266, 86, 105, 14);
		contentPane.add(label_9);

		JLabel label_10 = new JLabel(pegaTime(4,1));
		label_10.setBounds(66, 111, 106, 14);
		contentPane.add(label_10);

		textField_8 = new JTextField(retornaApostaCasoExista(mudarApostas, fase, 8));
		textField_8.setColumns(10);
		textField_8.setBounds(164, 111, 23, 20);
		contentPane.add(textField_8);

		JLabel label_11 = new JLabel("X");
		label_11.setBounds(201, 111, 11, 14);
		contentPane.add(label_11);

		textField_9 = new JTextField(retornaApostaCasoExista(mudarApostas, fase, 9));
		textField_9.setColumns(10);
		textField_9.setBounds(221, 111, 23, 20);
		contentPane.add(textField_9);

		JLabel label_12 = new JLabel(pegaTime(4,2));
		label_12.setBounds(266, 111, 105, 14);
		contentPane.add(label_12);

		JLabel label_13 = new JLabel(pegaTime(5,1));
		label_13.setBounds(66, 136, 106, 14);
		contentPane.add(label_13);

		textField_10 = new JTextField(retornaApostaCasoExista(mudarApostas, fase, 10));
		textField_10.setColumns(10);
		textField_10.setBounds(164, 136, 23, 20);
		contentPane.add(textField_10);

		JLabel label_14 = new JLabel("X");
		label_14.setBounds(201, 136, 11, 14);
		contentPane.add(label_14);

		textField_11 = new JTextField(retornaApostaCasoExista(mudarApostas, fase, 11));
		textField_11.setColumns(10);
		textField_11.setBounds(221, 136, 23, 20);
		contentPane.add(textField_11);

		JLabel label_15 = new JLabel(pegaTime(5,2));
		label_15.setBounds(266, 136, 105, 14);
		contentPane.add(label_15);

		JLabel label_16 = new JLabel(pegaTime(6,1));
		label_16.setBounds(66, 161, 106, 14);
		contentPane.add(label_16);

		textField_12 = new JTextField(retornaApostaCasoExista(mudarApostas, fase, 12));
		textField_12.setColumns(10);
		textField_12.setBounds(164, 161, 23, 20);
		contentPane.add(textField_12);

		JLabel label_17 = new JLabel("X");
		label_17.setBounds(201, 161, 11, 14);
		contentPane.add(label_17);

		textField_13 = new JTextField(retornaApostaCasoExista(mudarApostas, fase, 13));
		textField_13.setColumns(10);
		textField_13.setBounds(221, 161, 23, 20);
		contentPane.add(textField_13);

		JLabel label_18 = new JLabel(pegaTime(6,2));
		label_18.setBounds(266, 161, 105, 14);
		contentPane.add(label_18);

		JLabel label_19 = new JLabel(pegaTime(7,1));
		label_19.setBounds(66, 186, 106, 14);
		contentPane.add(label_19);

		textField_14 = new JTextField(retornaApostaCasoExista(mudarApostas, fase, 14));
		textField_14.setColumns(10);
		textField_14.setBounds(164, 186, 23, 20);
		contentPane.add(textField_14);

		JLabel label_20 = new JLabel("X");
		label_20.setBounds(201, 186, 11, 14);
		contentPane.add(label_20);

		textField_15 = new JTextField(retornaApostaCasoExista(mudarApostas, fase, 15));
		textField_15.setColumns(10);
		textField_15.setBounds(221, 186, 23, 20);
		contentPane.add(textField_15);

		JLabel label_21 = new JLabel(pegaTime(7,2));
		label_21.setBounds(266, 186, 105, 14);
		contentPane.add(label_21);

		JLabel label_22 = new JLabel(pegaTime(8,1));
		label_22.setBounds(66, 211, 106, 14);
		contentPane.add(label_22);

		textField_16 = new JTextField(retornaApostaCasoExista(mudarApostas, fase, 16));
		textField_16.setColumns(10);
		textField_16.setBounds(164, 211, 23, 20);
		contentPane.add(textField_16);

		JLabel label_23 = new JLabel("X");
		label_23.setBounds(201, 211, 11, 14);
		contentPane.add(label_23);

		textField_17 = new JTextField(retornaApostaCasoExista(mudarApostas, fase, 17));
		textField_17.setColumns(10);
		textField_17.setBounds(221, 211, 23, 20);
		contentPane.add(textField_17);

		JLabel label_24 = new JLabel(pegaTime(8,2));
		label_24.setBounds(266, 211, 105, 14);
		contentPane.add(label_24);

		JLabel label_25 = new JLabel(pegaTime(9,1));
		label_25.setBounds(66, 236, 106, 14);
		contentPane.add(label_25);

		textField_18 = new JTextField(retornaApostaCasoExista(mudarApostas, fase, 18));
		textField_18.setColumns(10);
		textField_18.setBounds(164, 236, 23, 20);
		contentPane.add(textField_18);

		JLabel label_26 = new JLabel("X");
		label_26.setBounds(201, 236, 11, 14);
		contentPane.add(label_26);

		textField_19 = new JTextField(retornaApostaCasoExista(mudarApostas, fase, 19));
		textField_19.setColumns(10);
		textField_19.setBounds(221, 236, 23, 20);
		contentPane.add(textField_19);

		JLabel label_27 = new JLabel(pegaTime(9,2));
		label_27.setBounds(266, 236, 105, 14);
		contentPane.add(label_27);

		JLabel label_28 = new JLabel(pegaTime(10,1));
		label_28.setBounds(66, 261, 106, 14);
		contentPane.add(label_28);

		textField_20 = new JTextField(retornaApostaCasoExista(mudarApostas, fase, 20));
		textField_20.setColumns(10);
		textField_20.setBounds(164, 261, 23, 20);
		contentPane.add(textField_20);

		JLabel label_29 = new JLabel("X");
		label_29.setBounds(201, 261, 11, 14);
		contentPane.add(label_29);

		textField_21 = new JTextField(retornaApostaCasoExista(mudarApostas, fase, 21));
		textField_21.setColumns(10);
		textField_21.setBounds(221, 261, 23, 20);
		contentPane.add(textField_21);

		JLabel label_30 = new JLabel(pegaTime(10,2));
		label_30.setBounds(266, 261, 105, 14);
		contentPane.add(label_30);

		JLabel label_31 = new JLabel(pegaTime(11,1));
		label_31.setBounds(66, 286, 106, 14);
		contentPane.add(label_31);

		textField_22 = new JTextField(retornaApostaCasoExista(mudarApostas, fase, 22));
		textField_22.setColumns(10);
		textField_22.setBounds(164, 286, 23, 20);
		contentPane.add(textField_22);

		JLabel label_32 = new JLabel("X");
		label_32.setBounds(201, 286, 11, 14);
		contentPane.add(label_32);

		textField_23 = new JTextField(retornaApostaCasoExista(mudarApostas, fase, 23));
		textField_23.setColumns(10);
		textField_23.setBounds(221, 286, 23, 20);
		contentPane.add(textField_23);

		JLabel label_33 = new JLabel(pegaTime(11,2));
		label_33.setBounds(266, 286, 105, 14);
		contentPane.add(label_33);

		JLabel label_34 = new JLabel(pegaTime(12,1));
		label_34.setBounds(66, 311, 106, 14);
		contentPane.add(label_34);

		textField_24 = new JTextField(retornaApostaCasoExista(mudarApostas, fase, 24));
		textField_24.setColumns(10);
		textField_24.setBounds(164, 311, 23, 20);
		contentPane.add(textField_24);

		JLabel label_35 = new JLabel("X");
		label_35.setBounds(201, 311, 11, 14);
		contentPane.add(label_35);

		textField_25 = new JTextField(retornaApostaCasoExista(mudarApostas, fase, 25));
		textField_25.setColumns(10);
		textField_25.setBounds(221, 311, 23, 20);
		contentPane.add(textField_25);

		JLabel label_36 = new JLabel(pegaTime(12,2));
		label_36.setBounds(266, 311, 105, 14);
		contentPane.add(label_36);

		JLabel label_37 = new JLabel(pegaTime(13,1));
		label_37.setBounds(66, 336, 106, 14);
		contentPane.add(label_37);

		textField_26 = new JTextField(retornaApostaCasoExista(mudarApostas, fase, 26));
		textField_26.setColumns(10);
		textField_26.setBounds(164, 336, 23, 20);
		contentPane.add(textField_26);

		JLabel label_38 = new JLabel("X");
		label_38.setBounds(201, 336, 11, 14);
		contentPane.add(label_38);

		textField_27 = new JTextField(retornaApostaCasoExista(mudarApostas, fase, 27));
		textField_27.setColumns(10);
		textField_27.setBounds(221, 336, 23, 20);
		contentPane.add(textField_27);

		JLabel label_39 = new JLabel(pegaTime(13,2));
		label_39.setBounds(266, 336, 105, 14);
		contentPane.add(label_39);

		JLabel label_40 = new JLabel(pegaTime(14,1));
		label_40.setBounds(66, 361, 106, 14);
		contentPane.add(label_40);

		textField_28 = new JTextField(retornaApostaCasoExista(mudarApostas, fase, 28));
		textField_28.setColumns(10);
		textField_28.setBounds(164, 361, 23, 20);
		contentPane.add(textField_28);

		JLabel label_41 = new JLabel("X");
		label_41.setBounds(201, 361, 11, 14);
		contentPane.add(label_41);

		textField_29 = new JTextField(retornaApostaCasoExista(mudarApostas, fase, 29));
		textField_29.setColumns(10);
		textField_29.setBounds(221, 361, 23, 20);
		contentPane.add(textField_29);

		JLabel label_42 = new JLabel(pegaTime(14,2));
		label_42.setBounds(266, 361, 105, 14);
		contentPane.add(label_42);

		JLabel label_43 = new JLabel(pegaTime(15,1));
		label_43.setBounds(66, 386, 106, 14);
		contentPane.add(label_43);

		textField_30 = new JTextField(retornaApostaCasoExista(mudarApostas, fase, 30));
		textField_30.setColumns(10);
		textField_30.setBounds(164, 386, 23, 20);
		contentPane.add(textField_30);

		JLabel label_44 = new JLabel("X");
		label_44.setBounds(201, 386, 11, 14);
		contentPane.add(label_44);

		textField_31 = new JTextField(retornaApostaCasoExista(mudarApostas, fase, 31));
		textField_31.setColumns(10);
		textField_31.setBounds(221, 386, 23, 20);
		contentPane.add(textField_31);

		JLabel label_45 = new JLabel(pegaTime(15,2));
		label_45.setBounds(266, 386, 105, 14);
		contentPane.add(label_45);

		getContentPane().add(contentPane);
		contentPane.setBounds(0, 0, 381, 509);

		JButton btnAtualizar = new JButton("Atualizar");
		btnAtualizar.setBounds(142, 434, 89, 23);
		btnAtualizar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("aqui");

				if (user instanceof Administrador){
					
					((Administrador) user).iniciaJogos();


					results.add(textField.getText());
					results.add(textField_1.getText());
					results.add(textField_2.getText());
					results.add(textField_3.getText());
					results.add(textField_4.getText());
					results.add(textField_5.getText());
					results.add(textField_6.getText());
					results.add(textField_7.getText());
					results.add(textField_8.getText());
					results.add(textField_9.getText());
					results.add(textField_10.getText());
					results.add(textField_11.getText());
					results.add(textField_12.getText());
					results.add(textField_13.getText());
					results.add(textField_14.getText());
					results.add(textField_15.getText());
					results.add(textField_16.getText());
					results.add(textField_17.getText());
					results.add(textField_18.getText());
					results.add(textField_19.getText());
					results.add(textField_20.getText());
					results.add(textField_21.getText());
					results.add(textField_22.getText());
					results.add(textField_23.getText());
					results.add(textField_24.getText());
					results.add(textField_25.getText());
					results.add(textField_26.getText());
					results.add(textField_27.getText());
					results.add(textField_28.getText());
					results.add(textField_29.getText());
					results.add(textField_30.getText());
					results.add(textField_31.getText());


					
					if (fase == 1){
						
						Inputtimes atualiza = new Inputtimes();
						try {

							atualiza.openfile();
						} catch (FileNotFoundException e1) {

							e1.printStackTrace();
						}
						

						atualiza.Gravaarquivo(new Resultado("1 Fase - 1 Rodada", Administrador.timesJogos1fase, results));
						atualiza.Gravaarquivo(new Resultado("1 Fase - 2 Rodada", new ArrayList<String>() , new ArrayList<String>()));
						atualiza.Gravaarquivo(new Resultado("1 Fase - 3 Rodada", new ArrayList<String>(), new ArrayList<String>()));
						atualiza.Gravaarquivo(new Resultado("Oitavas de final", new ArrayList<String>(), new ArrayList<String>()));
						atualiza.Gravaarquivo(new Resultado("Quartas de final", new ArrayList<String>(), new ArrayList<String>()));
						atualiza.Gravaarquivo(new Resultado("Semifinal", new ArrayList<String>(), new ArrayList<String>()));
						atualiza.Gravaarquivo(new Resultado("Final", new ArrayList<String>(), new ArrayList<String>()));

						

						
						atualiza.closefile();


						calculaPontosDeTodosOsUsuarios(1);

					}else if (fase == 2){
						Inputtimes atualiza = new Inputtimes();
						try {

							atualiza.openfile();
						} catch (FileNotFoundException e1) {

							e1.printStackTrace();
						}
						
						
						Outputtimes f = new Outputtimes(); //cria objeto do tipo output
						f.openfile(); //abre o arquivo
						f.lerarquivo(); // le todos os objeto e salva em um arquivo
						for (Resultado r: f.retornaArquivoFases()) {

							if (r.getFase().equals("1 Fase - 2 Rodada")){// verifica se o usuario é do tipo administrador
								r.setResultados(results);	
							}
						}


						for(Resultado r2 : f.retornaArquivoFases()){
							if (r2.getFase().equals("1 Fase - 2 Rodada")){// verifica se o usuario é do tipo administrador
								r2.setResultados(results);
								atualiza.Gravaarquivo(r2);
							}else{

							atualiza.Gravaarquivo(r2);
							}
						}

						f.closefile();
						
						atualiza.closefile();

						calculaPontosDeTodosOsUsuarios(2);

					}else{
						
						Inputtimes atualiza = new Inputtimes();
						try {

							atualiza.openfile();
						} catch (FileNotFoundException e1) {

							e1.printStackTrace();
						}
						
						
						Outputtimes f = new Outputtimes(); //cria objeto do tipo output
						f.openfile(); //abre o arquivo
						f.lerarquivo(); // le todos os objeto e salva em um arquivo
						for (Resultado r: f.retornaArquivoFases()) {

							if (r.getFase().equals("1 Fase - 3 Rodada")){// verifica se o usuario é do tipo administrador
								r.setResultados(results);	
							}
						}


						for(Resultado r2 : f.retornaArquivoFases()){

							atualiza.Gravaarquivo(r2);

						}

						f.closefile();
						
						atualiza.closefile();


					}


					calculaPontosDeTodosOsUsuarios(3);



					

					JOptionPane.showMessageDialog(null,"Resultados atualizados com sucesso");
					dispose();

				}else{

					


					resultsuser.add(textField.getText());
					resultsuser.add(textField_1.getText());
					resultsuser.add(textField_2.getText());
					resultsuser.add(textField_3.getText());
					resultsuser.add(textField_4.getText());
					resultsuser.add(textField_5.getText());
					resultsuser.add(textField_6.getText());
					resultsuser.add(textField_7.getText());
					resultsuser.add(textField_8.getText());
					resultsuser.add(textField_9.getText());
					resultsuser.add(textField_10.getText());
					resultsuser.add(textField_11.getText());
					resultsuser.add(textField_12.getText());
					resultsuser.add(textField_13.getText());
					resultsuser.add(textField_14.getText());
					resultsuser.add(textField_15.getText());
					resultsuser.add(textField_16.getText());
					resultsuser.add(textField_17.getText());
					resultsuser.add(textField_18.getText());
					resultsuser.add(textField_19.getText());
					resultsuser.add(textField_20.getText());
					resultsuser.add(textField_21.getText());
					resultsuser.add(textField_22.getText());
					resultsuser.add(textField_23.getText());
					resultsuser.add(textField_24.getText());
					resultsuser.add(textField_25.getText());
					resultsuser.add(textField_26.getText());
					resultsuser.add(textField_27.getText());
					resultsuser.add(textField_28.getText());
					resultsuser.add(textField_29.getText());
					resultsuser .add(textField_30.getText());
					resultsuser.add(textField_31.getText());
					
					if (textField.getText().trim().equals("") || Integer.parseInt(textField.getText()) < 0
							|| textField_1.getText().trim().equals("") || Integer.parseInt(textField_1.getText()) < 0
							|| textField_2.getText().trim().equals("") || Integer.parseInt(textField_2.getText()) < 0
							|| textField_3.getText().trim().equals("") || Integer.parseInt(textField_3.getText()) < 0
							|| textField_4.getText().trim().equals("") || Integer.parseInt(textField_4.getText()) < 0
							|| textField_5.getText().trim().equals("") || Integer.parseInt(textField_5.getText()) < 0
							|| textField_6.getText().trim().equals("") || Integer.parseInt(textField_6.getText()) < 0
							|| textField_7.getText().trim().equals("") || Integer.parseInt(textField_7.getText()) < 0
							|| textField_8.getText().trim().equals("") || Integer.parseInt(textField_8.getText()) < 0
							|| textField_9.getText().trim().equals("") || Integer.parseInt(textField_9.getText()) < 0
							|| textField_10.getText().trim().equals("") || Integer.parseInt(textField_10.getText()) < 0
							|| textField_11.getText().trim().equals("") || Integer.parseInt(textField_11.getText()) < 0
							|| textField_12.getText().trim().equals("") || Integer.parseInt(textField_12.getText()) < 0
							|| textField_13.getText().trim().equals("") || Integer.parseInt(textField_13.getText()) < 0
							|| textField_14.getText().trim().equals("") || Integer.parseInt(textField_14.getText()) < 0
							|| textField_15.getText().trim().equals("") || Integer.parseInt(textField_15.getText()) < 0
							|| textField_16.getText().trim().equals("") || Integer.parseInt(textField_16.getText()) < 0
							|| textField_17.getText().trim().equals("") || Integer.parseInt(textField_17.getText()) < 0
							|| textField_18.getText().trim().equals("") || Integer.parseInt(textField_18.getText()) < 0
							|| textField_19.getText().trim().equals("") || Integer.parseInt(textField_19.getText()) < 0
							|| textField_20.getText().trim().equals("") || Integer.parseInt(textField_20.getText()) < 0
							|| textField_21.getText().trim().equals("") || Integer.parseInt(textField_21.getText()) < 0
							|| textField_22.getText().trim().equals("") || Integer.parseInt(textField_22.getText()) < 0
							|| textField_23.getText().trim().equals("") || Integer.parseInt(textField_23.getText()) < 0
							|| textField_24.getText().trim().equals("") || Integer.parseInt(textField_24.getText()) < 0
							|| textField_25.getText().trim().equals("") || Integer.parseInt(textField_25.getText()) < 0
							|| textField_26.getText().trim().equals("") || Integer.parseInt(textField_26.getText()) < 0
							|| textField_27.getText().trim().equals("") || Integer.parseInt(textField_27.getText()) < 0
							|| textField_28.getText().trim().equals("") || Integer.parseInt(textField_28.getText()) < 0
							|| textField_29.getText().trim().equals("") || Integer.parseInt(textField_29.getText()) < 0
							|| textField_30.getText().trim().equals("") || Integer.parseInt(textField_30.getText()) < 0
							|| textField_31.getText().trim().equals("") || Integer.parseInt(textField_31.getText()) < 0){
						
						JOptionPane.showMessageDialog(null, "Verifique os campos novamente, caractere inv\E1lido ou n\E3o preenchidos", "Erro na leitura dos campos", JOptionPane.ERROR_MESSAGE);

					}else{
					
					
					Jogador apostador = (Jogador) user;


					Output usuario = new Output();
					usuario.openfile();
					usuario.lerarquivo();

					for (Usuario user2: usuario.usalista()) {
						if(user2.getLogin().equals(apostador.getLogin())){
							apostador.getApostas().add(fase - 1,((ArrayList<String>) resultsuser));
							apostador.getApostas().remove(fase);


						}
					}
					
					
					Input Usuario2 = new Input();
					try {
						Usuario2.openfile();
					} catch (FileNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}

					int controle = 1;

					for (Usuario  user4 : usuario.usalista()) {
						if(user4.getLogin().equals(apostador.getLogin())){
							if (user4 instanceof Jogador && controle == 1){
								controle++;	
								Jogador	user3 = (Jogador) user4;
								user3.setapostas(apostador.getApostas());
								Usuario2.Gravaarquivo(user3);

							}	
						}else{
							Usuario2.Gravaarquivo(user4);
						}


						


					}
					Usuario2.closefile();
					usuario.closefile();


					}


					/*Output usuario = new Output();
					usuario.openfile();
					usuario.lerarquivo();
					for (Usuario user2: usuario.usalista()) {
						if(user2.getLogin().equals(apostador.getLogin())){
							apostador.setApostas(fase - 1,((ArrayList<String>) resultsuser));
						}
					}
					usuario.openfile();
				Input Usuario2 = new Input();
				try {
					Usuario2.openfile();
				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				for (Usuario  user3 : usuario.usalista()) {
					Usuario2.Gravaarquivo(apostador);
				}
				Usuario2.closefile();
					 */
					JOptionPane.showMessageDialog(null,"Resultados atualizados com sucesso");
					dispose();

				}	


			}	


		});



		contentPane.add(btnAtualizar);
		this.setResizable(false);
		setVisible(true);

	}






	public String getLogin() {
		return Login;
	}


	public void setLogin(String login) {
		Login = login;
	}


	private String pegaTime(int jogo, int time){
		if (fase == 1){
			String nome = "";
			for (int i = 0; i < Administrador.timesJogos1fase.get(jogo).length(); i++) {
				if (" ".equals(String.valueOf(Administrador.timesJogos1fase.get(jogo).charAt(i)))){
					if (time == 2){
						nome = "";
						for (int j = i; j < Administrador.timesJogos1fase.get(jogo).length(); j++){
							nome += Administrador.timesJogos1fase.get(jogo).charAt(j);
						}
					}
					return nome;
				}

				nome += Administrador.timesJogos1fase.get(jogo).charAt(i);
			}

			return nome;
		}

		if (fase == 2){
			Outputtimes f = new Outputtimes();
			f.openfile();
			f.lerarquivo();

			Resultado re = null;
			List<String> primeiroTime = new ArrayList<String>();
			List<String> segundoTime = new ArrayList<String>();

			for (Resultado r: f.retornaArquivoFases()){
				if (r.getFase().equals("1 Fase - 2 Rodada")){
					re = r;
					break;
				}
			}

			f.closefile();

			for (int i= 0; i < re.getTimes().size(); i++){
				if (i % 2 == 0)
					primeiroTime.add(re.getTimes().get(i));
				else
					segundoTime.add(re.getTimes().get(i));
			}

			if (time == 1){
				return primeiroTime.get(jogo);
			}else{
				return segundoTime.get(jogo);
			}

		}

		if (fase == 3){
			Outputtimes f = new Outputtimes();
			f.openfile();
			f.lerarquivo();

			Resultado re = null;
			List<String> primeiroTime = new ArrayList<String>();
			List<String> segundoTime = new ArrayList<String>();

			for (Resultado r: f.retornaArquivoFases()){
				if (r.getFase().equals("1 Fase - 3 Rodada")){
					re = r;
					break;
				}
			}

			f.closefile();

			for (int i= 0; i < re.getTimes().size(); i++){
				if (i % 2 == 0)
					primeiroTime.add(re.getTimes().get(i));
				else
					segundoTime.add(re.getTimes().get(i));
			}

			if (time == 1){
				return primeiroTime.get(jogo);
			}else{
				return segundoTime.get(jogo);
			}


		}



		return null;

	}


	private  void calculaPontosDeTodosOsUsuarios(int rodada){

		CalculaPontos1Fase c1 = new CalculaPontos1Fase();

		Output usuario = new Output();
		usuario.openfile();
		usuario.lerarquivo();
		
		List<ArrayList<String>> c = new ArrayList<ArrayList<String>>();

		for (Usuario user2: usuario.usalista()) {
			Usuario user21 = user2;
			try{
			c = user21.getApostas();
			}catch(Exception e){
				c = null;
			}
		
			if (!(user21  instanceof Administrador)){
			
				if((user21.getApostas().isEmpty()) || c.get(rodada - 1).isEmpty()){ 
					user21.setPontos(user21.getPontos() + 0);
				}else{
					user21.setPontos(user21.getPontos() + c1.calculaPontos(rodada, user21));

				}
			
			
			}
		}

		usuario.openfile();
		Input Usuario2 = new Input();
		try {
			Usuario2.openfile();
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		for (Usuario  user3 : usuario.usalista()) {
			Usuario2.Gravaarquivo(user3);
		}
		Usuario2.closefile();




	}

	private String retornaApostaCasoExista(boolean mudarAposta, int rodada, int aposta){
		
		mudarAposta = mudarApostas; 
		
		if (mudarAposta){
			
			Output g = new Output();
			g.openfile();
			g.lerarquivo();
			
			for (Usuario r : g.usalista()) {
				if (!(r instanceof Administrador)){
					if (r.getLogin().equals(user.getLogin())){
						if (fase == 1){
							return user.getApostas().get(rodada - 1).get(aposta);
						}else if (fase == 2){
							return user.getApostas().get(rodada - 1).get(aposta);
						}else if (fase == 3){
							return user.getApostas().get(rodada - 1).get(aposta);
						}
					}
				}
			}
		}
		
		return "0";
		
		
		
	}




}
