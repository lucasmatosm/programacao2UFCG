package projeto;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.util.ArrayList;

import javax.swing.*;




/**
 * Classe para o cadastro de usuarios do bolao.
 */
	public class Cadastro extends JFrame {
		public static void main(String[] args) {
			Cadastro cad = new Cadastro();
			cad.setVisible(true);
		}
		
		private static final long serialVersionUID = -1912392693134449594L;
		
		private JLabel labelEmail;
		private JLabel labelUsuario;
		private JLabel labelUser;
		private JLabel labelSenha;
		private JLabel pergunta;
		private JLabel resposta;
		private JLabel labelRepetirSenha;
		private JTextField textEmail;
		private JTextField textUsuario;
		private JTextField textuser;
		private JPasswordField textSenha;
		private JPasswordField textRepetirSenha;
		private JTextField textResposta;
		private JButton buttonCadastrar;
		private JButton buttonCancelar;
		private boolean possivel = true;
		private String escolhido, escolhido2;
		String[] opcao2 = {"Qual foi nome do seu primeiro cachorro?", "Qual o nome de solteira da sua m�e?", "Onde seu pai nasceu?",
				"Qual a primeira escola que voc� estudou?"};
		private JLabel label;
		
		/**
		 * Contrutor da classe cadastro.
		 */
		public Cadastro(){
		super(".:: CLEP Bolão - FIFA World Cup 2014");
		setTitle(".:: CLEP Bol\u00E3o - FIFA World Cup 2014");
		
		labelUsuario = new JLabel("Nome completo");
		labelUsuario.setBounds(256, 25, 246, 14);
		labelEmail = new JLabel("Endere�o de Email");
		labelEmail.setBounds(245, 81, 246, 14);
		labelUser = new JLabel("Nome de usuario");
		labelUser.setBounds(252, 137, 246, 14);
		labelSenha = new JLabel("Criar Senha");
		labelSenha.setBounds(264, 193, 246, 14);
		labelRepetirSenha = new JLabel("Repetir Senha");
		labelRepetirSenha.setBounds(258, 249, 246, 14);
        pergunta = new JLabel("Selecione a pergunta de seguran�a:");
        pergunta.setBounds(202, 305, 246, 14);
        resposta = new JLabel("Digite a resposta de seguran�a");
        resposta.setBounds(217, 375, 246, 14);
		textUsuario = new JTextField(47);
		textUsuario.setBounds(106, 50, 382, 20);
		textEmail = new JTextField(47);
		textEmail.setBounds(106, 106, 382, 20);
		textuser = new JTextField(47);
		textuser.setBounds(106, 161, 382, 20);
		textSenha = new JPasswordField(47);
		textSenha.setBounds(106, 218, 382, 20);
		textRepetirSenha = new JPasswordField(47);
		textRepetirSenha.setBounds(106, 274, 382, 20);
		textResposta = new JTextField(47);
		textResposta.setBounds(106, 400, 382, 20);

		
		JComboBox jComboBox2 = new JComboBox(opcao2);
		jComboBox2.setBounds(140, 330, 323, 20);
		JComboBox ecolha2 = jComboBox2;
		ecolha2.addActionListener(new ActionListener(){
		@Override
		/**
		 * Metodo para dar acao a JComboBox das perguntas secretas
		 * @param ActionEvent f
		 */
		public void actionPerformed(ActionEvent f) {
			JComboBox cb2 = (JComboBox)f.getSource();
			escolhido2 = (String)cb2.getSelectedItem();	 	
		}});
		
		System.out.println(escolhido2);
		
		textSenha.setEchoChar('*');
		textRepetirSenha.setEchoChar('*');
		
		buttonCadastrar = new JButton("Cadastrar");
		buttonCadastrar.setBounds(182, 456, 112, 23);
		buttonCadastrar.addActionListener(new ActionListener() {
			/**
			 * Metodo para cadastrar usuario, ao clicar no botao cadastrar
			 */
			public void actionPerformed(ActionEvent e) {
				System.out.println(escolhido2);
				
				String n = textUsuario.getText();
				String l = textEmail.getText();
				String u = textuser.getText();
				String s = textSenha.getText();
				String em = textRepetirSenha.getText();
				String r = textResposta.getText().toLowerCase();
				if(n.trim().equals("") || l.trim().equals("") || s.trim().equals("") || u.trim().equals("") || em.trim().equals("") || r.trim().equals("")){
					JOptionPane.showMessageDialog(null,"Campos n�o prenchidos");
				}else if(!(s.equals(em))){
					JOptionPane.showMessageDialog(null,"As senhas devem ser iguais");
				}
				else if(s.length() < 6 || s.length() > 8){
					JOptionPane.showMessageDialog(null,"As senhas devem conter entre 6 e 8 caracteres");	
				}
				
				else{
					Output g = new Output();
					g.openfile();
					g.lerarquivo();
					g.closefile();

					for (int i = 0; i < g.usalista().size(); i++) {
						if (u.equals(g.usalista().get(i).getLogin())){
							JOptionPane.showMessageDialog(null,"Nome de usuario existente");
							textuser.setText(null);
							possivel = false;
							break;
						}
						else{
							possivel = true;
						}
					}
					if (possivel == true){
						Input f = new Input();
						String a = textSenha.getText();
						
						ArrayList<ArrayList<String>> apostas  = new ArrayList<ArrayList<String>>();
							Jogador user = new Jogador(n,l,u,a,escolhido2, r, apostas);
							user.iniciaApostas();
							System.out.println(escolhido);
							g.usalista().add(user);
							try {
								f.openfile();
							} catch (FileNotFoundException e1) {
								e1.printStackTrace();
							}
							for (int i = 0; i < g.usalista().size(); i++) {
								f.Gravaarquivo(g.usalista().get(i));
							}
							f.closefile();
							JOptionPane.showMessageDialog(null,"Usu�rio cadastrado!");
							textUsuario.setText(null);
							textEmail.setText(null);
							textuser.setText(null);
							textEmail.setText(null);
							textSenha.setText(null);
							textRepetirSenha.setText(null);
							textResposta.setText(null);
						}
					}


				}	
			
				
				
				
			});
		
		
		
		buttonCancelar = new JButton("Cancelar");
		buttonCancelar.setBounds(304, 456, 112, 23);
		buttonCancelar.addActionListener(new ActionListener() {
			/**
			 * Metodo para cancelar o cadastro e voltar para o menu
			 */
			public void actionPerformed(ActionEvent e) {
				dispose();
				
			}
		});
		
		
		
		JFrame frame = new JFrame();
		Container pane = this.getContentPane();
		getContentPane().setLayout(null);
		
		pane.add(labelUsuario);
		pane.add(textUsuario);
		pane.add(labelEmail);
		pane.add(textEmail);
		pane.add(labelUser);
		pane.add(textuser);
		pane.add(labelSenha);
		pane.add(textSenha);
		pane.add(labelRepetirSenha);
		pane.add(textRepetirSenha);
		pane.add(pergunta);
		pane.add(jComboBox2);
		pane.add(resposta);
		pane.add(textResposta);
		pane.add(buttonCadastrar);
		pane.add(buttonCancelar);
		
		label = new JLabel("");
		label.setIcon(new ImageIcon(Cadastro.class.getResource("/projeto/logo-copa-2014.jpg")));
		label.setBounds(-16, -827, 1442, 1600);
		getContentPane().add(label);

		
		this.setSize(600, 590);
		this.setResizable(false); 
		this.setVisible(true);        
          
        frame.pack();  
    
        
		}		
	}
