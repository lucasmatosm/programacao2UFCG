package projeto;

import java.io.Serializable;
import java.util.*;

public class Usuario implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5769835560102465149L;
	public static final boolean PODE_APOSTAR = true;
	public static final boolean NAO_PODE_APOSTAR = false;
	protected String nome, email, login, pergunta;
	protected String senha;
	protected String resposta;
	private boolean situacao = PODE_APOSTAR;
	private int pontos = 0;
	private ArrayList<ArrayList<String>> apostas;
	
	public Usuario(String nome, String email, String login, String senha, String pergunta, String resposta, int pontos, boolean situacao , ArrayList<ArrayList<String>> apostas){
	
		this.nome = nome;
		this.email = email;
		this.login = login;
		this.senha = senha;
		this.pergunta = pergunta;
		this.resposta = resposta;
		this.pontos = pontos;
		this.situacao = situacao;
		if (apostas == null){
			this.apostas = new  ArrayList<ArrayList<String>>(); 
		}else{
		this.apostas = apostas;
		}
		
		
	}
	
	public Usuario(String nome, String email, String login, String senha, String pergunta, String resposta){
		this( nome, email,  login,  senha,  pergunta,  resposta, 0, true, new ArrayList<ArrayList<String>>());
		this.situacao = PODE_APOSTAR;
		
	}

	public String getResposta() {
		return resposta;
	}

	public void setResposta(String resposta) {
		this.resposta = resposta;
	}
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public String getPergunta() {
		return pergunta;
	}

	public void setPergunta(String pergunta) {
		this.pergunta = pergunta;
	}

	public ArrayList<ArrayList<String>> getApostas() {
		return apostas;
	}

	public void setApostas(double fase, ArrayList<String> aposta) {
		if (fase == 1.1)
			apostas.set(0, aposta);
		if (fase == 1.2)
			apostas.set(1, aposta);
		if (fase == 1.3)
			apostas.set(2, aposta);
		if (fase == 2)
			apostas.set(3, aposta);
		if (fase == 3)
			apostas.set(4, aposta);
		if (fase == 4)
			apostas.set(5, aposta);
		if (fase == 5)
			apostas.set(6, aposta);
		
	}

	public int getPontos() {
		return pontos;
	}

	public void setPontos(int pontos) {
		this.pontos = pontos;
	}
	
	
	
	public boolean isSituacao() {
		return situacao;
	}

	public void setSituacao(boolean situacao) {
		this.situacao = situacao;
	}

	public boolean fazerAposta(ArrayList<String> aposta){
		try{
		apostas.add(aposta);
		return true;
		}catch (Exception e){
			return false;
		}
	}
	
	public void iniciaApostas(){
		
		ArrayList<String> composicao = new ArrayList<String>();
		if (this.getApostas() == null){
			apostas = new ArrayList<ArrayList<String>>();
		}
		
		
		for (int i = 0; i < 7; i++){
			
			System.out.println(apostas);
			
			getApostas().add(composicao);
		}
		
	}

	

	@Override
	public String toString() {
		return "Usuario [nome=" + nome + ", email=" + email + ", login="
				+ login + ", senha=" + senha + ", pergunta=" + pergunta
				+ ", resposta=" + this.getResposta() + ", pontos=" + pontos
				+ ", apostas=" + this.getApostas() + " " + this.isSituacao()+"]";
	}
	
	

}
