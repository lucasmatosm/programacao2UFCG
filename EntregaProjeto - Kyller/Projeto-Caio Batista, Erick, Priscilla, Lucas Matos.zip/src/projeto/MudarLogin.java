package projeto;



import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.FileNotFoundException;

public class MudarLogin extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = -3446456084423030852L;
	private JTextField textField, textField1;

	/**
	 * Create the panel.
	 */
	public MudarLogin() {
		setLayout(null);
		
		JLabel lblDigiteAbaixoO = new JLabel("Digite abaixo o nome do usu\u00E1rio que voc\u00EA antigo");
		lblDigiteAbaixoO.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblDigiteAbaixoO.setBounds(26, 33, 367, 20);
		add(lblDigiteAbaixoO);
		
		textField = new JTextField();
		textField.setBounds(155, 173, 129, 20);
		add(textField);
		textField.setColumns(10);
		
		
		JLabel lblDigiteAbaixo1 = new JLabel("Digite abaixo o nome do usu\u00E1rio que voc\u00EA novo:");
		lblDigiteAbaixo1.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblDigiteAbaixo1.setBounds(26, 128, 367, 20);
		add(lblDigiteAbaixo1);
		
		textField1 = new JTextField();
		textField1.setBounds(155, 86, 129, 20);
		add(textField1);
		textField1.setColumns(10);
		
		JButton btnExcluir = new JButton("Mudar usuario");
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Output login = new Output();
				login.openfile();
				login.lerarquivo();
				String n = textField.getText();
				String g = textField1.getText();
				for (int i = 0; i < login.usalista().size(); i++) {
					if (g.equals(login.usalista().get(i).getLogin())){
						login.usalista().get(i).setLogin(n);		
						}	
					}
				login.closefile();
				Input remove = new Input();
				try {
					remove.openfile();
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				}
				for (int i = 0; i < login.usalista().size(); i++) {
					remove.Gravaarquivo(login.usalista().get(i));
				}
				remove.closefile();
				JOptionPane.showMessageDialog(null,"Login alterado com sucesso");
				}
			
		});
		btnExcluir.setBounds(155, 216, 129, 23);
		add(btnExcluir);

	}
}