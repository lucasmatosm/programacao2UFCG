package projeto;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

public class CalculaPontos8Final implements EstrategiaCalculaPontos {

	private Usuario usuario;

	@Override
	public int calculaPontos(int fase, Usuario user) {
		int pontos = 0;
		usuario = user;
		
		List<String> oitavas = new ArrayList<String>();
		List<Integer> oitavasInt = new ArrayList<Integer>();

		Output g = new Output();
		Input h = new Input();
		g.openfile();
		try {
			h.openfile();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		g.lerarquivo();

		for (Usuario user1: g.usalista()) {
			if (user1.getLogin().equals(user.getLogin())){
					oitavas = (List<String>) user.getApostas().get(3);
				
			}
		}



		for (int j = 0; j < oitavas.size(); j++){
			oitavasInt.add(Integer.parseInt(oitavas.get(j)));
		}
		for (int i1 = 0; i1 < (oitavasInt.size()/2); i1++) {
			if ((((pegaGolsAdministrador(i1, 1) > pegaGolsAdministrador(i1, 2)) 
					&& (pegaGolsApostados(i1, 1) > pegaGolsApostados(i1, 2)))) 
					|| ((((pegaGolsAdministrador(i1, 1) == pegaGolsAdministrador(i1, 2)) 
							&& ((pegaGolsApostados(i1, 1) == pegaGolsApostados(i1, 2)))))
							|| (((pegaGolsAdministrador(i1, 1) < pegaGolsAdministrador(i1, 2)) 
									&& (pegaGolsApostados(i1, 1) < pegaGolsApostados(i1, 2)))))){

				pontos+= 2;

			}
			if((pegaGolsAdministrador(i1, 1) == pegaGolsApostados(i1, 1)) 
					&& (pegaGolsAdministrador(i1, 2) != pegaGolsApostados(i1, 2))){

				pontos += 2;

			}
			if ((pegaGolsAdministrador(i1, 2) == pegaGolsApostados(i1, 2)) 
					&& (pegaGolsAdministrador(i1, 1) != pegaGolsApostados(i1, 1))){

				pontos += 2;

			}
		}



		return pontos;


		
	}
	
	
	
	
	private int pegaGolsAdministrador(int jogo, int time){
		List<Integer> primeiroTime = new ArrayList<Integer>();
		List<Integer> segundoTime = new ArrayList<Integer>();

		Outputtimes f = new Outputtimes();
		f.openfile();
		f.lerarquivo();

		for (Resultado r : f.retornaArquivoFases()) {
			if (r.getFase().equals("Oitavas de final")){
				for (int i = 0; i < r.getResultados().size(); i++) {
					if (i % 2 == 0){
						primeiroTime.add(Integer.parseInt(r.getResultados().get(i)));
					}else{
						segundoTime.add(Integer.parseInt(r.getResultados().get(i)));
					}
				}
			}
		}
		
		f.closefile();

		if (time == 1){
			return primeiroTime.get(jogo);
		}else{
			return segundoTime.get(jogo);
		}
	}
	
	

	private int pegaGolsApostados(int jogo, int time){
		List<Integer> primeiroTime = new ArrayList<Integer>();
		List<Integer> segundoTime = new ArrayList<Integer>();
		List<String> parcial = new ArrayList<String>();

		Output f = new Output();
		f.openfile();
		f.lerarquivo();

		for (Usuario r : f.usalista()) {
			if (r.getLogin().equals(usuario.getLogin())){
				parcial = (List<String>) r.getApostas().get(3);
				for (int i = 0; i < parcial.size(); i++) {
					if (i % 2 == 0){
						primeiroTime.add(Integer.parseInt(parcial.get(i)));
					}else{
						segundoTime.add(Integer.parseInt(parcial.get(i)));
					}
				}
			}
		}

		if (time == 1){
			return primeiroTime.get(jogo);
		}else{
			return segundoTime.get(jogo);
		}
	}

	
}
