package projeto;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.*;
/**
 * Construtor da classe Output para leitura de dados do arquivo
 */
public class Output {
	private ObjectInputStream input;
	ArrayList<Usuario> listauser = new ArrayList<Usuario>();
	/**
	 * Funcao para abrir o arquivo
	 */
	public void openfile(){
		try{
			input = new ObjectInputStream(new FileInputStream("saida.dat") );
		}catch(IOException ioException){
			System.err.println("Erro ao abrir o arquivo");
		}

	}
	/**
	 * Funcao para leitura do arquivo
	 */
	public void lerarquivo(){
		try{
			while(true){
				Usuario record = (Usuario) input.readObject();
				listauser.add(record);
			}
		}catch(EOFException ENDoFFILEesception){
			return;
		}catch(ClassNotFoundException classNotfound){
			System.err.println("nao foi possivel criar o objeto");
		}catch(IOException ioexception){
			System.err.println("Erro de leitura do arquivo");
		}
	}
	public ArrayList<Usuario> usalista(){
		return listauser;
	}
	public void closefile(){
		try{
			if(input != null)
				input.close();
		}catch(IOException ioexception){
			System.err.println("Erro ao fechar o arquivo");
			System.exit(1);
		}
	}
}
