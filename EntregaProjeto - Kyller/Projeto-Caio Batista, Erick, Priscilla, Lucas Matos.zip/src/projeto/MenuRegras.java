package projeto;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Toolkit;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MenuRegras extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MenuRegras frame = new MenuRegras();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MenuRegras() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(MenuRegras.class.getResource("/projeto/copa-Fifa.jpg")));
		setTitle("Bem vindo administrador!");
		setBounds(100, 100, 361, 275);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblEsseMenuTorna = new JLabel("Esse menu torna poss\u00EDvel as seguintes opera\u00E7\u00F5es:");
		lblEsseMenuTorna.setBounds(28, 11, 302, 14);
		contentPane.add(lblEsseMenuTorna);
		
		JLabel lblCadastrarUsurio = new JLabel("1. Cadastrar usu\u00E1rio/administrador.");
		lblCadastrarUsurio.setBounds(57, 53, 240, 14);
		contentPane.add(lblCadastrarUsurio);
		
		JLabel lblExcluirUsurio = new JLabel("2. Excluir usu\u00E1rio/administrador");
		lblExcluirUsurio.setBounds(57, 78, 240, 14);
		contentPane.add(lblExcluirUsurio);
		
		JLabel lblAtualizarOs = new JLabel("3. Atualizar os times que ir\u00E3o jogar.");
		lblAtualizarOs.setBounds(57, 103, 240, 14);
		contentPane.add(lblAtualizarOs);
		
		JLabel lblAtualizarOs_1 = new JLabel("4. Atualizar os resultados dos jogos.");
		lblAtualizarOs_1.setBounds(57, 128, 240, 14);
		contentPane.add(lblAtualizarOs_1);
		
		JLabel lblConfigurarSua = new JLabel("5. Configurar sua conta.");
		lblConfigurarSua.setBounds(57, 153, 240, 14);
		contentPane.add(lblConfigurarSua);
		
		JButton btnComearAAdministrar = new JButton("Come\u00E7ar a administrar!");
		btnComearAAdministrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
			}
		});
		btnComearAAdministrar.setBounds(94, 202, 170, 23);
		contentPane.add(btnComearAAdministrar);
		
		this.setResizable(false);
	}
}
