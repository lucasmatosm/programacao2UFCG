package projeto;

import java.util.ArrayList;

/**
 * Classe do Usuario tipo Jogador
 */
public class Jogador extends Usuario{
ArrayList<ArrayList<String>> apostas = new ArrayList<ArrayList<String>>();
	public Jogador(String nome, String email, String login, String senha,
			String pergunta, String resposta,ArrayList<ArrayList<String>> apostas ) {
		super(nome, email, login, senha, pergunta, resposta);
	this.apostas = apostas;
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * Metodo para recuperar a resposta de seguranca
	 * @return resposta
	 */
	
	public String getResposta() {
		return resposta;
	}
	public ArrayList<ArrayList<String>> getApostas() {
		return apostas;
	}
	
	public void setapostas(ArrayList<ArrayList<String>> apostas) {
		this.apostas = apostas;
	}
	/**
	 * Modifica a resposta da pergunta de seguranca
	 * @param resposta
	 */
	public void setResposta(String resposta) {
		this.resposta = resposta;
	}
	/**
	 * Metodo para recuperar o nome
	 * @return nome
	 */
	public String getNome() {
		return nome;
	}
	/**
	 * Modifica o nome do Jogador
	 * @param nome
	 */
	public void setNome(String nome) {
		this.nome = nome;
	}
	/**
	 * Metodo para recuperar o email
	 * @return email
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * Modifica o email do Jogador
	 * @param email
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	/**
	 * Metodo para recuperar o login
	 * @return login
	 */
	public String getLogin() {
		return login;
	}
	/**
	 * Modifica o login do Jogador
	 * @param  login
	 */
	public void setLogin(String login) {
		this.login = login;
	}
	/**
	 * Metodo para recuperar a senha
	 * @return senha
	 */
	public String getSenha() {
		return senha;
	}
	/**
	 * Modifica a senha do Jogador
	 * @param  senha
	 */
	public void setSenha(String senha) {
		this.senha = senha;
	}
	/**
	 * Metodo para recuperar a pergunta de seguranca
	 * @return pergunta
	 */
	public String getPergunta() {
		return pergunta;
	}
}
