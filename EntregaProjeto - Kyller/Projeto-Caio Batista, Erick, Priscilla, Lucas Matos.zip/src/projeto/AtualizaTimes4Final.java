package projeto;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class AtualizaTimes4Final extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7025710093336848240L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private List<String> times = new ArrayList<String>();
	private String[] timesp = {"Brasil","Croacia","Mexico", "Camaroes","Espanha","Holanda", "Chile", "Australia","Colombia", "Grecia","Costa-do-Marfim" ,"Japao","Uruguai" ,"Costa-Rica","Inglaterra", "Italia","Suica", "Equador","Franca" ,"Honduras","Argentina", "Bosnia","Ira" ,"Nigeria","Alemanha" ,"Portugal","Gana", "Estados-Unidos", "Belgica" ,"Argelia","Russia", "Coreia-do-Sul"};
	private List<String> lista = Arrays.asList(timesp);  
	private ArrayList<String> timesPossiveis = new ArrayList<String>(lista);

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AtualizaTimes4Final frame = new AtualizaTimes4Final();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AtualizaTimes4Final() {
		
		setBounds(100, 100, 358, 244);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("Jogo 1:");
		label.setBounds(10, 14, 46, 14);
		contentPane.add(label);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(66, 11, 116, 20);
		contentPane.add(textField);
		
		JLabel label_1 = new JLabel("X");
		label_1.setBounds(192, 14, 15, 14);
		contentPane.add(label_1);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(208, 11, 116, 20);
		contentPane.add(textField_1);
		
		JLabel label_2 = new JLabel("Jogo 2:");
		label_2.setBounds(10, 42, 46, 14);
		contentPane.add(label_2);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(66, 39, 116, 20);
		contentPane.add(textField_2);
		
		JLabel label_3 = new JLabel("X");
		label_3.setBounds(192, 42, 15, 14);
		contentPane.add(label_3);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(208, 39, 116, 20);
		contentPane.add(textField_3);
		
		JLabel label_4 = new JLabel("Jogo 3:");
		label_4.setBounds(10, 70, 46, 14);
		contentPane.add(label_4);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(66, 67, 116, 20);
		contentPane.add(textField_4);
		
		JLabel label_5 = new JLabel("X");
		label_5.setBounds(192, 70, 15, 14);
		contentPane.add(label_5);
		
		textField_5 = new JTextField();
		textField_5.setColumns(10);
		textField_5.setBounds(208, 67, 116, 20);
		contentPane.add(textField_5);
		
		JLabel label_6 = new JLabel("Jogo 4:");
		label_6.setBounds(10, 98, 46, 14);
		contentPane.add(label_6);
		
		textField_6 = new JTextField();
		textField_6.setColumns(10);
		textField_6.setBounds(66, 95, 116, 20);
		contentPane.add(textField_6);
		
		JLabel label_7 = new JLabel("X");
		label_7.setBounds(192, 98, 15, 14);
		contentPane.add(label_7);
		
		textField_7 = new JTextField();
		textField_7.setColumns(10);
		textField_7.setBounds(208, 95, 116, 20);
		contentPane.add(textField_7);
		
		JButton button = new JButton("Atualizar");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if (textField.getText().trim().equals("") || textField.getText().equals("")
						|| textField_1.getText().trim().equals("") || textField_1.getText().equals("")
						|| textField_2.getText().trim().equals("") || textField_2.getText().equals("") 
						|| textField_3.getText().trim().equals("") || textField_3.getText().equals("")
						|| textField_4.getText().trim().equals("") || textField_4.getText().equals("")
						|| textField_5.getText().trim().equals("") || textField_5.getText().equals("")
						|| textField_6.getText().trim().equals("") || textField_6.getText().equals("")
						|| textField_7.getText().trim().equals("") || textField_7.getText().equals("")){
					
					JOptionPane.showMessageDialog(null, "Verifique os campos novamente, caractere inv�lido ou n�o preenchidos", "Erro na leitura dos campos", JOptionPane.ERROR_MESSAGE);

				}else{
				
				times.add(textField.getText());
				times.add(textField_1.getText());
				times.add(textField_2.getText());
				times.add(textField_3.getText());
				times.add(textField_4.getText());
				times.add(textField_5.getText());
				times.add(textField_6.getText());
				times.add(textField_7.getText());
				
				if (!(timesPossiveis.containsAll(times))){
					JOptionPane.showMessageDialog(null, "Os times t�m que estar participando da copa para poderem ser cadastrados para pr�xima fase \n    Exemplos : Costa-do-Marfim, Japao, Brasil, Colombia", "Aten��o", JOptionPane.ERROR_MESSAGE);					
					
				}else{
			

				Outputtimes f = new Outputtimes(); //cria objeto do tipo output
				f.openfile(); //abre o arquivo
				f.lerarquivo(); // le todos os objeto e salva em um arquivo

				
				for (Resultado r: f.retornaArquivoFases()) {

					if (r.getFase().equals("Quartas de final")){// verifica se o usuario é do tipo administrador
						r.setTimes(times);	
						break;
					}
				}

				Inputtimes g = new Inputtimes();
				try {
					g.openfile();
				} catch (FileNotFoundException e1) {

					e1.printStackTrace();
				}
				for(Resultado r2 : f.retornaArquivoFases()){
					if (r2.getFase().equals("Quartas de final")){// verifica se o usuario é do tipo administrador
						r2.setTimes(times);
						g.Gravaarquivo(r2);
					}else{
						g.Gravaarquivo(r2);
					}
				}
				g.closefile();
				f.closefile();
				
				JOptionPane.showMessageDialog(null, "Times atualizados com sucesso!");
				dispose();
				
				}	
				}
			}
		});
		button.setBounds(121, 152, 105, 23);
		contentPane.add(button);
	}
}
