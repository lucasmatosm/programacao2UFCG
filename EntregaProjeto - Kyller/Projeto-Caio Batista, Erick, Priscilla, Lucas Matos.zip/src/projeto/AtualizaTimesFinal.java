package projeto;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class AtualizaTimesFinal extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8717785436512427762L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private List<String> times = new ArrayList<String>();
	private String[] timesp = {"Brasil","Croacia","Mexico", "Camaroes","Espanha","Holanda", "Chile", "Australia","Colombia", "Grecia","Costa-do-Marfim" ,"Japao","Uruguai" ,"Costa-Rica","Inglaterra", "Italia","Suica", "Equador","Franca" ,"Honduras","Argentina", "Bosnia","Ira" ,"Nigeria","Alemanha" ,"Portugal","Gana", "Estados-Unidos", "Belgica" ,"Argelia","Russia", "Coreia-do-Sul"};
	private List<String> lista = Arrays.asList(timesp);  
	private ArrayList<String> timesPossiveis = new ArrayList<String>(lista);

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AtualizaTimesFinal frame = new AtualizaTimesFinal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AtualizaTimesFinal() {
		
		setBounds(100, 100, 346, 130);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblFinal = new JLabel("Final:");
		lblFinal.setBounds(10, 14, 46, 14);
		contentPane.add(lblFinal);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(66, 11, 116, 20);
		contentPane.add(textField);
		
		JLabel label_1 = new JLabel("X");
		label_1.setBounds(192, 14, 15, 14);
		contentPane.add(label_1);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(208, 11, 116, 20);
		contentPane.add(textField_1);
		
		JButton button = new JButton("Atualizar");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if (textField.getText().trim().equals("") || textField.getText().equals("") 
						|| textField_1.getText().trim().equals("") || textField_1.getText().equals("")){
					
					JOptionPane.showMessageDialog(null, "Verifique os campos novamente, caractere inv�lido ou n�o preenchidos", "Erro na leitura dos campos", JOptionPane.ERROR_MESSAGE);

				}else{
				
				
				
				times.add(textField.getText());
				times.add(textField_1.getText());
				
				if (!(timesPossiveis.containsAll(times))){
					JOptionPane.showMessageDialog(null, "Os times t�m que estar participando da copa para poderem ser cadastrados para pr�xima fase \n    Exemplos : Costa-do-Marfim, Japao, Brasil, Colombia", "Aten��o", JOptionPane.ERROR_MESSAGE);					
					
				}else {
			

				Outputtimes f = new Outputtimes(); //cria objeto do tipo output
				f.openfile(); //abre o arquivo
				f.lerarquivo(); // le todos os objeto e salva em um arquivo

				
				for (Resultado r: f.retornaArquivoFases()) {

					if (r.getFase().equals("Final")){// verifica se o usuario é do tipo administrador
						r.setTimes(times);	
						break;
					}
				}

				Inputtimes g = new Inputtimes();
				try {
					g.openfile();
				} catch (FileNotFoundException e1) {

					e1.printStackTrace();
				}
				for(Resultado r2 : f.retornaArquivoFases()){
					if (r2.getFase().equals("Final")){// verifica se o usuario é do tipo administrador
						r2.setTimes(times);
						g.Gravaarquivo(r2);
					}else{
						g.Gravaarquivo(r2);
					}
				}
				g.closefile();
				f.closefile();
				
				JOptionPane.showMessageDialog(null, "Times atualizados com sucesso!");
				dispose();
				
				}
				}
			}
		});
		button.setBounds(121, 55, 105, 23);
		contentPane.add(button);
	}

}
