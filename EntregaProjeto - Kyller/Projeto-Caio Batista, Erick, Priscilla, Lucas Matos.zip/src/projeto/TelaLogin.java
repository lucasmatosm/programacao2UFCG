package projeto;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;
import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.SwingConstants;

public class TelaLogin extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	public boolean bou = false;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelaLogin frame = new TelaLogin();
					frame.setVisible(true);
					Output g = new Output();
					g.openfile();
					g.lerarquivo();
					
					
					
					int controle  = 0;
					
					for (Usuario r : g.usalista()) {
						if (r instanceof Administrador){
							controle++;
						}
					}
					

					System.out.println(g.usalista());
					
					if (controle == 0){
						Input f = new Input();
						f.openfile();
						
						for (Usuario r1 : g.usalista()) {
							f.Gravaarquivo(r1);
						}
						
						Administrador e = new Administrador("Administrador", "admin@admin","admin", "123456","Qual a primeira escola que voc� estudou?","", null, null);
						f.Gravaarquivo(e);
						
						System.out.println(g.usalista());
						f.closefile();
					}
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TelaLogin() {
		setTitle("Bol\u00E3o CLEP");
		setIconImage(Toolkit.getDefaultToolkit().getImage(TelaLogin.class.getResource("copadomundo2014.jpg")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnCadastrarse = new JButton("Cadastrar");
		btnCadastrarse.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Cadastro cad = new Cadastro();
				cad.setVisible(true);
			}
		});
		btnCadastrarse.setBounds(20, 205, 107, 23);
		contentPane.add(btnCadastrarse);

		JLabel lblNewLabel = new JLabel("Login");
		lblNewLabel.setBackground(Color.WHITE);
		lblNewLabel.setForeground(Color.BLACK);
		lblNewLabel.setBounds(38, 49, 89, 32);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 26));
		contentPane.add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("Senha");
		lblNewLabel_1.setBounds(38, 124, 89, 32);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 26));
		contentPane.add(lblNewLabel_1);

		textField = new JTextField();
		textField.setBounds(128, 49, 185, 32);
		contentPane.add(textField);
		textField.setColumns(10);

		textField_1 = new JPasswordField();
		textField_1.setBounds(128, 124, 185, 32);
		contentPane.add(textField_1);
		textField_1.setColumns(10);

		JButton btnEntrar = new JButton("Entrar");
		btnEntrar.setBounds(314, 205, 95, 23);
		btnEntrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (textField.getText().equals("")){
					JOptionPane.showMessageDialog(contentPane,"Voc� nao pode entrar sem um login!", "Mensagem de erro", JOptionPane.ERROR_MESSAGE ); 
				}else if (textField_1.getText().equals("")){
					JOptionPane.showMessageDialog(contentPane,"Voc� nao pode entrar sem uma senha!", "Mensagem de erro", JOptionPane.ERROR_MESSAGE );
				}else{
					Output login = new Output();
					login.openfile();
					login.lerarquivo();
					for (int i = 0; i < login.usalista().size(); i++) {
						if (textField.getText().equals(login.usalista().get(i).getLogin()) && textField_1.getText().equals(login.usalista().get(i).getSenha())){
							if(login.usalista().get(i) instanceof Administrador){
								bou = true;
								MenuRegras regras = new MenuRegras();
								MenuAdmin administrador = new MenuAdmin(); 
								administrador.setVisible(true);
								administrador.setLogin(textField.getText());
								regras.setVisible(true);
								TelaLogin.this.setVisible(false);	
							}
							else{
								bou = true;
								MenuUsuario menu = new MenuUsuario();
								BoasVindasUser regras = new BoasVindasUser();
								menu.setVisible(true);
								menu.setLogin(textField.getText());
								regras.setVisible(true);
								TelaLogin.this.setVisible(false);	
							}
							
						}	
					}
					if(bou == false){
						JOptionPane.showMessageDialog(contentPane,"Login ou senha incorretos", "Mensagem de erro", JOptionPane.ERROR_MESSAGE );		
					}
					login.closefile();
				}
			}
		});
		contentPane.add(btnEntrar);
		
		JButton btnEsqueceuSenha = new JButton("Esqueceu Senha");
		btnEsqueceuSenha.setBounds(139, 204, 163, 25);
		btnEsqueceuSenha.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				EsqueceuSenha senha = new EsqueceuSenha();
				senha.setVisible(true);
			}
		});
		contentPane.add(btnEsqueceuSenha);
		
		JLabel lblKmdkx = new JLabel("");
		lblKmdkx.setBackground(Color.WHITE);
		lblKmdkx.setIcon(new ImageIcon(TelaLogin.class.getResource("/projeto/copa-Fifa.jpg")));
		lblKmdkx.setBounds(0, 0, 444, 271);
		contentPane.add(lblKmdkx);
		this.setResizable(false);
	}
}
