package projeto;
import java.io.*;
import java.util.ArrayList;
/**
 * Classe para escrita de objetos do tipo usuario no arquivo
 */
public class Inputtimes implements Serializable {
	private ObjectOutputStream output;
	/**
	 * Metodo para abrir o arquivo
	 */
	public void openfile() throws FileNotFoundException{
		try{
			output = new ObjectOutputStream(new FileOutputStream("times.dat"));
		}catch(IOException ioException){
			System.err.println("Erro ao abrir o arquivo");
		}
	}
	/**
	 * Metodo para gravar dados no arquivo
	 * @param Usuario cliente
	 */
	public void Gravaarquivo(Resultado result){

		try{
			output.writeObject(result);
			
		}
		catch( Exception e ){
			e.printStackTrace( );
		}	
	}
	/**
	 * Metodo para fechar o arquivo
	 */
	public void closefile(){
		try{
			if(output != null)
				output.close();
		}catch(IOException ioexception){
			System.err.println("Erro ao fechar o arquivo");
			System.exit(1);
		}
	}}

