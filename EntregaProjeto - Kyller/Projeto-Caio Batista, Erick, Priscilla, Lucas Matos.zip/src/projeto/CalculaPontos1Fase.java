package projeto;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

public class CalculaPontos1Fase implements EstrategiaCalculaPontos {

	List<Integer> primeiraFase;
	int Fase;
	Usuario usuario;

	@SuppressWarnings("null")
	@Override
	public int calculaPontos(int fase , Usuario user) {
		int pontos = 0;
		usuario = user;
		Fase = fase;
		List<String> primeiraFase = new ArrayList<String>();
		List<Integer> primeiraFaseInt = new ArrayList<Integer>();

		Output g = new Output();
	
		g.openfile();
		

		g.lerarquivo();

		for (Usuario user1: g.usalista()) {
			if (user1.getLogin().equals(usuario.getLogin())){
				if (fase == 1)
					primeiraFase = (List<String>) user1.getApostas().get(0);
				else if (fase == 2)
					primeiraFase = (List<String>) user1.getApostas().get(1);
				else if (fase == 3)
					primeiraFase = (List<String>) user1.getApostas().get(2);
			}
		}



		for (int j = 0; j < primeiraFase.size(); j++){
			int la = Integer.parseInt(primeiraFase.get(j));
			primeiraFaseInt.add(la);
			
		}
		
		for (int i = 0; i < (primeiraFase.size()/2); i++) {
			if ((((pegaGolsAdministrador(i, 1) > pegaGolsAdministrador(i, 2)) 
					&& (pegaGolsApostados(i, 1) > pegaGolsApostados(i, 2)))) 
					|| ((((pegaGolsAdministrador(i, 1) == pegaGolsAdministrador(i, 2)) 
							&& ((pegaGolsApostados(i, 1) == pegaGolsApostados(i, 2)))))
							|| (((pegaGolsAdministrador(i, 1) < pegaGolsAdministrador(i, 2)) 
									&& (pegaGolsApostados(i, 1) < pegaGolsApostados(i, 2)))))){

				pontos++;

			}
			if((pegaGolsAdministrador(i, 1) == pegaGolsApostados(i, 1)) 
					&& (pegaGolsAdministrador(i, 2) != pegaGolsApostados(i, 2))){

				pontos++;

			}
			if ((pegaGolsAdministrador(i, 2) == pegaGolsApostados(i, 2)) 
					&& (pegaGolsAdministrador(i, 1) != pegaGolsApostados(i, 1))){

				pontos++;

			}
		}



		return pontos;



	}




	private int pegaGolsAdministrador(int jogo, int time){
		List<Integer> primeiroTime = new ArrayList<Integer>();
		List<Integer> segundoTime = new ArrayList<Integer>();

		Outputtimes f = new Outputtimes();
		f.openfile();
		f.lerarquivo();

		for (Resultado r : f.retornaArquivoFases()) {
			
			if (Fase == 1 && r.getFase().equals("1 Fase - 1 Rodada")){
				for (int i = 0; i < r.getResultados().size(); i++) {
					if (i % 2 == 0){
						primeiroTime.add(Integer.parseInt(r.getResultados().get(i)));
					}else{
						segundoTime.add(Integer.parseInt(r.getResultados().get(i)));
					}
				}
			}else if (Fase == 2 && r.getFase().equals("1 Fase - 2 Rodada")){
				for (int i = 0; i < r.getResultados().size(); i++) {
					if (i % 2 == 0){
						primeiroTime.add(Integer.parseInt(r.getResultados().get(i)));
					}else{
						segundoTime.add(Integer.parseInt(r.getResultados().get(i)));
					}
				}
			}else if (Fase == 3 && r.getFase().equals("1 Fase - 3 Rodada")){
				for (int i = 0; i < r.getResultados().size(); i++) {
					if (i % 2 == 0){
						primeiroTime.add(Integer.parseInt(r.getResultados().get(i)));
					}else{
						segundoTime.add(Integer.parseInt(r.getResultados().get(i)));
					}
				}
			}
		}
		
		
		if (time == 1){
			return primeiroTime.get(jogo);
		}else{
			return segundoTime.get(jogo);
		}
	}

	private int pegaGolsApostados(int jogo, int time){
		List<Integer> primeiroTime = new ArrayList<Integer>();
		List<Integer> segundoTime = new ArrayList<Integer>();
		List<String> parcial = new ArrayList<String>();

		Output f = new Output();
		f.openfile();
		f.lerarquivo();

		for (Usuario r : f.usalista()) {
			if (r.getLogin().equals(usuario.getLogin()) && Fase == 1){
				parcial = (List<String>) r.getApostas().get(0);
				for (int i = 0; i < parcial.size(); i++) {
					if (i % 2 == 0){
						primeiroTime.add(Integer.parseInt(parcial.get(i)));
					}else{
						segundoTime.add(Integer.parseInt(parcial.get(i)));
					}
				}
			}else if (r.getLogin().equals(usuario.getLogin()) && Fase == 2){
				parcial = (List<String>) r.getApostas().get(1);
				for (int i = 0; i < parcial.size(); i++) {
					if (i % 2 == 0){
						primeiroTime.add(Integer.parseInt(parcial.get(i)));
					}else{
						segundoTime.add(Integer.parseInt(parcial.get(i)));
					}
				}
			}else if (r.getLogin().equals(usuario.getLogin()) && Fase == 3){
				parcial = (List<String>) r.getApostas().get(2);
				for (int i = 0; i < parcial.size(); i++) {
					if (i % 2 == 0){
						primeiroTime.add(Integer.parseInt(parcial.get(i)));
					}else{
						segundoTime.add(Integer.parseInt(parcial.get(i)));
					}
				}
			}
		}

		if (time == 1){
			return primeiroTime.get(jogo);
		}else{
			return segundoTime.get(jogo);
		}
	}

}



