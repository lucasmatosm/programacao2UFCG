package projeto;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class Times8Final extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4660058453095420161L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTextField textField_10;
	private JTextField textField_11;
	private JTextField textField_12;
	private JTextField textField_13;
	private JTextField textField_14;
	private JTextField textField_15;
	private List<String> resultsuser = new ArrayList<String>();
	private Usuario user;
	private boolean mudarApostas;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Times8Final frame = new Times8Final(false , null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Times8Final(final boolean mudarApostas,final Usuario user) {
		this.user = user;
		this.mudarApostas = mudarApostas;

		setBounds(100, 100, 385, 363);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel label = new JLabel("Jogo 1:");
		label.setBounds(10, 14, 46, 14);
		contentPane.add(label);

		JLabel label_1 = new JLabel(pegaTime(0,1));
		label_1.setBounds(66, 14, 106, 14);
		contentPane.add(label_1);

		textField = new JTextField(retornaApostaCasoExista(mudarApostas, 4, 0));
		textField.setColumns(10);
		textField.setBounds(164, 11, 23, 20);
		contentPane.add(textField);

		JLabel label_2 = new JLabel("X");
		label_2.setBounds(201, 14, 23, 14);
		contentPane.add(label_2);

		textField_1 = new JTextField(retornaApostaCasoExista(mudarApostas, 4, 1));
		textField_1.setColumns(10);
		textField_1.setBounds(221, 11, 23, 20);
		contentPane.add(textField_1);

		JLabel label_3 = new JLabel(pegaTime(0,2));
		label_3.setBounds(266, 14, 105, 14);
		contentPane.add(label_3);

		JLabel lblJogo = new JLabel("Jogo 2:");
		lblJogo.setBounds(10, 42, 46, 14);
		contentPane.add(lblJogo);

		JLabel label_5 = new JLabel(pegaTime(1,1));
		label_5.setBounds(66, 42, 106, 14);
		contentPane.add(label_5);

		textField_2 = new JTextField(retornaApostaCasoExista(mudarApostas, 4, 2));
		textField_2.setColumns(10);
		textField_2.setBounds(164, 39, 23, 20);
		contentPane.add(textField_2);

		JLabel label_6 = new JLabel("X");
		label_6.setBounds(201, 42, 23, 14);
		contentPane.add(label_6);

		textField_3 = new JTextField(retornaApostaCasoExista(mudarApostas, 4, 3));
		textField_3.setColumns(10);
		textField_3.setBounds(221, 39, 23, 20);
		contentPane.add(textField_3);

		JLabel label_7 = new JLabel(pegaTime(1,2));
		label_7.setBounds(266, 42, 105, 14);
		contentPane.add(label_7);

		JLabel lblJogo_1 = new JLabel("Jogo 3:");
		lblJogo_1.setBounds(10, 70, 46, 14);
		contentPane.add(lblJogo_1);

		JLabel label_9 = new JLabel(pegaTime(2,1));
		label_9.setBounds(66, 70, 106, 14);
		contentPane.add(label_9);

		textField_4 = new JTextField(retornaApostaCasoExista(mudarApostas, 4, 4));
		textField_4.setColumns(10);
		textField_4.setBounds(164, 67, 23, 20);
		contentPane.add(textField_4);

		JLabel label_10 = new JLabel("X");
		label_10.setBounds(201, 70, 23, 14);
		contentPane.add(label_10);

		textField_5 = new JTextField(retornaApostaCasoExista(mudarApostas, 4, 5));
		textField_5.setColumns(10);
		textField_5.setBounds(221, 67, 23, 20);
		contentPane.add(textField_5);

		JLabel label_11 = new JLabel(pegaTime(2,2));
		label_11.setBounds(266, 70, 105, 14);
		contentPane.add(label_11);

		JLabel lblJogo_2 = new JLabel("Jogo 4:");
		lblJogo_2.setBounds(10, 98, 46, 14);
		contentPane.add(lblJogo_2);

		JLabel label_13 = new JLabel(pegaTime(3,1));
		label_13.setBounds(66, 98, 106, 14);
		contentPane.add(label_13);

		textField_6 = new JTextField(retornaApostaCasoExista(mudarApostas, 4, 6));
		textField_6.setColumns(10);
		textField_6.setBounds(164, 95, 23, 20);
		contentPane.add(textField_6);

		JLabel label_14 = new JLabel("X");
		label_14.setBounds(201, 98, 23, 14);
		contentPane.add(label_14);

		textField_7 = new JTextField(retornaApostaCasoExista(mudarApostas, 4, 7));
		textField_7.setColumns(10);
		textField_7.setBounds(221, 95, 23, 20);
		contentPane.add(textField_7);

		JLabel label_15 = new JLabel(pegaTime(3,2));
		label_15.setBounds(266, 98, 105, 14);
		contentPane.add(label_15);

		JLabel lblJogo_3 = new JLabel("Jogo 5:");
		lblJogo_3.setBounds(10, 126, 46, 14);
		contentPane.add(lblJogo_3);

		JLabel label_17 = new JLabel(pegaTime(4,1));
		label_17.setBounds(66, 126, 106, 14);
		contentPane.add(label_17);

		textField_8 = new JTextField(retornaApostaCasoExista(mudarApostas, 4, 8));
		textField_8.setColumns(10);
		textField_8.setBounds(164, 123, 23, 20);
		contentPane.add(textField_8);

		JLabel label_18 = new JLabel("X");
		label_18.setBounds(201, 126, 23, 14);
		contentPane.add(label_18);

		textField_9 = new JTextField(retornaApostaCasoExista(mudarApostas, 4, 9));
		textField_9.setColumns(10);
		textField_9.setBounds(221, 123, 23, 20);
		contentPane.add(textField_9);

		JLabel label_19 = new JLabel(pegaTime(4,2));
		label_19.setBounds(266, 126, 105, 14);
		contentPane.add(label_19);

		JLabel lblJogo_4 = new JLabel("Jogo 6:");
		lblJogo_4.setBounds(10, 154, 46, 14);
		contentPane.add(lblJogo_4);

		JLabel label_21 = new JLabel(pegaTime(5,1));
		label_21.setBounds(66, 154, 106, 14);
		contentPane.add(label_21);

		textField_10 = new JTextField(retornaApostaCasoExista(mudarApostas, 4, 10));
		textField_10.setColumns(10);
		textField_10.setBounds(164, 151, 23, 20);
		contentPane.add(textField_10);

		JLabel label_22 = new JLabel("X");
		label_22.setBounds(201, 154, 23, 14);
		contentPane.add(label_22);

		textField_11 = new JTextField(retornaApostaCasoExista(mudarApostas, 4, 11));
		textField_11.setColumns(10);
		textField_11.setBounds(221, 151, 23, 20);
		contentPane.add(textField_11);

		JLabel label_23 = new JLabel(pegaTime(5,2));
		label_23.setBounds(266, 154, 105, 14);
		contentPane.add(label_23);

		JLabel lblJogo_5 = new JLabel("Jogo 7:");
		lblJogo_5.setBounds(10, 182, 46, 14);
		contentPane.add(lblJogo_5);

		JLabel label_25 = new JLabel(pegaTime(6,1));
		label_25.setBounds(66, 182, 106, 14);
		contentPane.add(label_25);

		textField_12 = new JTextField(retornaApostaCasoExista(mudarApostas, 4, 12));
		textField_12.setColumns(10);
		textField_12.setBounds(164, 179, 23, 20);
		contentPane.add(textField_12);

		JLabel label_26 = new JLabel("X");
		label_26.setBounds(201, 182, 23, 14);
		contentPane.add(label_26);

		textField_13 = new JTextField(retornaApostaCasoExista(mudarApostas, 4, 13));
		textField_13.setColumns(10);
		textField_13.setBounds(221, 179, 23, 20);
		contentPane.add(textField_13);

		JLabel label_27 = new JLabel(pegaTime(6,2));
		label_27.setBounds(266, 182, 105, 14);
		contentPane.add(label_27);

		JLabel lblJogo_6 = new JLabel("Jogo 8:");
		lblJogo_6.setBounds(10, 210, 46, 14);
		contentPane.add(lblJogo_6);

		JLabel label_29 = new JLabel(pegaTime(7,1));
		label_29.setBounds(66, 210, 106, 14);
		contentPane.add(label_29);

		textField_14 = new JTextField(retornaApostaCasoExista(mudarApostas, 4, 14));
		textField_14.setColumns(10);
		textField_14.setBounds(164, 207, 23, 20);
		contentPane.add(textField_14);

		JLabel label_30 = new JLabel("X");
		label_30.setBounds(201, 210, 23, 14);
		contentPane.add(label_30);

		textField_15 = new JTextField(retornaApostaCasoExista(mudarApostas, 4, 15));
		textField_15.setColumns(10);
		textField_15.setBounds(221, 207, 23, 20);
		contentPane.add(textField_15);

		JLabel label_31 = new JLabel(pegaTime(7,2));
		label_31.setBounds(266, 210, 105, 14);
		contentPane.add(label_31);

		JButton btnConcluir = new JButton("Concluir");
		btnConcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(user instanceof Administrador){

					resultsuser.add(textField.getText());
					resultsuser.add(textField_1.getText());
					resultsuser.add(textField_2.getText());
					resultsuser.add(textField_3.getText());
					resultsuser.add(textField_4.getText());
					resultsuser.add(textField_5.getText());
					resultsuser.add(textField_6.getText());
					resultsuser.add(textField_7.getText());
					resultsuser.add(textField_8.getText());
					resultsuser.add(textField_9.getText());
					resultsuser.add(textField_10.getText());
					resultsuser.add(textField_11.getText());
					resultsuser.add(textField_12.getText());
					resultsuser.add(textField_13.getText());
					resultsuser.add(textField_14.getText());
					resultsuser.add(textField_15.getText());


					Outputtimes f = new Outputtimes(); //cria objeto do tipo output
					f.openfile(); //abre o arquivo
					f.lerarquivo(); // le todos os objeto e salva em um arquivo
					for (Resultado r: f.retornaArquivoFases()) {

						if (r.getFase().equals("Oitavas de final")){// verifica se o usuario é do tipo administrador
							r.setResultados(resultsuser);	
						}
					}

					Inputtimes atualiza = new Inputtimes();
					try {
						atualiza.openfile();
					} catch (FileNotFoundException e) {

						e.printStackTrace();
					}



					for(Resultado r2 : f.retornaArquivoFases()){
						
							atualiza.Gravaarquivo(r2);
						
					}

					f.closefile();
					atualiza.closefile();
					
					calculaPontosDeTodosOsUsuarios(4);
					
					JOptionPane.showMessageDialog(null,"Resultados atualizados com sucesso");
					dispose();

				}else{
					resultsuser.add(textField.getText());
					resultsuser.add(textField_1.getText());
					resultsuser.add(textField_2.getText());
					resultsuser.add(textField_3.getText());
					resultsuser.add(textField_4.getText());
					resultsuser.add(textField_5.getText());
					resultsuser.add(textField_6.getText());
					resultsuser.add(textField_7.getText());
					resultsuser.add(textField_8.getText());
					resultsuser.add(textField_9.getText());
					resultsuser.add(textField_10.getText());
					resultsuser.add(textField_11.getText());
					resultsuser.add(textField_12.getText());
					resultsuser.add(textField_13.getText());
					resultsuser.add(textField_14.getText());
					resultsuser.add(textField_15.getText());

					Jogador apostador = (Jogador) user;


					Output usuario = new Output();
					usuario.openfile();
					usuario.lerarquivo();

					for (Usuario user2: usuario.usalista()) {
						if(user2.getLogin().equals(apostador.getLogin())){
							apostador.getApostas().add(4,((ArrayList<String>) resultsuser));
							apostador.getApostas().remove(5);

						}
					}
					usuario.closefile();
					Input Usuario2 = new Input();
					try {
						Usuario2.openfile();
					} catch (FileNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}

					int controle = 1;

					for (Usuario  user4 : usuario.usalista()) {
						if(user4.getLogin().equals(apostador.getLogin())){
							if (user4 instanceof Jogador && controle == 1){
								controle++;	
								Jogador	user3 = (Jogador) user4;


								user3.setapostas(apostador.getApostas());
								Usuario2.Gravaarquivo(user3);

							}	
						}
						else{
							Usuario2.Gravaarquivo(user4);
						}





					}
					Usuario2.closefile();
					
					JOptionPane.showMessageDialog(null,"Resultados atualizados com sucesso");
					dispose();


				}
			}
		});
		btnConcluir.setBounds(135, 265, 89, 23);
		contentPane.add(btnConcluir);
	}

	private String pegaTime(int jogo, int time){

		Outputtimes f = new Outputtimes();
		f.openfile();
		f.lerarquivo();

		Resultado re = null;
		List<String> primeiroTime = new ArrayList<String>();
		List<String> segundoTime = new ArrayList<String>();

		for (Resultado r: f.retornaArquivoFases()){
			if (r.getFase().equals("Oitavas de final")){
				re = r;
				break;
			}
		}

		f.closefile();

		for (int i= 0; i < re.getTimes().size(); i++){
			if (i % 2 == 0)
				primeiroTime.add(re.getTimes().get(i));
			else
				segundoTime.add(re.getTimes().get(i));
		}

		if (time == 1){
			return primeiroTime.get(jogo);
		}else{
			return segundoTime.get(jogo);
		}
	}
	
	
	
	private  void calculaPontosDeTodosOsUsuarios(int rodada){

		CalculaPontos8Final c1 = new CalculaPontos8Final();

		Output usuario = new Output();
		usuario.openfile();
		usuario.lerarquivo();
		
		List<ArrayList<String>> c = new ArrayList<ArrayList<String>>();

		for (Usuario user2: usuario.usalista()) {
			Usuario user21 = user2;
			try{
			c = user21.getApostas();
			}catch(Exception e){
				c = null;
			}
		
			if (!(user21  instanceof Administrador)){
			
				if((user21.getApostas().isEmpty()) || c.get(rodada - 1).isEmpty()){ 
					user21.setPontos(user21.getPontos() + 0);
				}else{
					user21.setPontos(user21.getPontos() + c1.calculaPontos(rodada, user21));

				}
			
			
			}
		}

		usuario.openfile();
		Input Usuario2 = new Input();
		try {
			Usuario2.openfile();
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		for (Usuario  user3 : usuario.usalista()) {
			Usuario2.Gravaarquivo(user3);
		}
		Usuario2.closefile();




	}
	
	
private String retornaApostaCasoExista(boolean mudarAposta, int rodada, int aposta){
		
		mudarAposta = mudarApostas; 
		
		if (mudarAposta){
			
			Output g = new Output();
			g.openfile();
			g.lerarquivo();
			
			for (Usuario r : g.usalista()) {
				if (!(r instanceof Administrador)){
					if (r.getLogin().equals(user.getLogin())){
						return user.getApostas().get(rodada - 1).get(aposta);
						}
					}
				}
		}
		
		return "0";
		
		
		
	}




}
