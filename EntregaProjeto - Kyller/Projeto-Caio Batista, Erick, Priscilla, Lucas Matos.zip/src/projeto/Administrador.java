package projeto;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
/**
 * Classe Administrador
 */
public class Administrador extends Usuario{
	private static final long serialVersionUID = 1L;
	public static List<String> jogos1fase = new ArrayList<String>();
	public static List<String> jogos8final = new ArrayList<String>();
	public static List<String> jogos4final = new ArrayList<String>();
	public static List<String> jogosSemiFinal = new ArrayList<String>();
	public static List<String> jogoFinal = new ArrayList<String>();
	public static List<String> timesJogos1fase = new ArrayList<String>();
	public static List<String> timesJogos8final = new ArrayList<String>();
	public static List<String> timesJogos4final = new ArrayList<String>();
	public static List<String> timesJogosSemiFinal = new ArrayList<String>();
	public static List<String> timesJogoFinal = new ArrayList<String>();
	public  String horaInicio, horaTermino;
	/**
	 * Construtor da classe Adminstrador
	 * @param nome, email, login, senha, pergunta, resposta
	 */
	public Administrador(String nome, String email, String login, String senha, String pergunta, String resposta, String horaInicio, String horaTermino) {
		super(nome,email,login,senha,pergunta, resposta);
		this.horaInicio = horaInicio;
		this.horaTermino = horaTermino;
	}
	/**
	 * recupera a resposta da pergunta de seguranca
	 * @return resposta
	 */
	public String getResposta() {
		return resposta;
	}
	/**
	 * To string
	 * @return to string
	 */
	@Override
	public String toString() {
		return "Administrador [nome=" + nome + ", email=" + email + ", login="
				+ login + ", pergunta=" + pergunta + ", resposta=" + resposta
				+ ", getResposta()=" + getResposta() + ", getNome()="
				+ getNome() + ", getEmail()=" + getEmail() + ", getLogin()="
				+ getLogin() + ", getPergunta()=" + getPergunta() + "]";
	}
	/**
	 * Modifica a resposta da pergunta de seguranca
	 * @param resposta
	 */
	public void setResposta(String resposta) {
		this.resposta = resposta;
	}
	/**
	 * recupera o nome do adminstrador
	 * @return nome
	 */
	public String getNome() {
		return nome;
	}
	/**
	 * Modifica o nome do adminstrador
	 * @param nome
	 */
	public void setNome(String nome) {
		this.nome = nome;
	}
	/**
	 * recupera o email do adminstrador
	 * @return email
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * Modifica o email do adminstrador
	 * @param email
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	/**
	 * recupera o login do adminstrador
	 * @return login
	 */
	public String getLogin() {
		return login;
	}
	/**
	 * Modifica o login do adminstrador
	 * @param login
	 */
	public void setLogin(String login) {
		this.login = login;
	}
	/**
	 * recupera a senha do adminstrador
	 * @return senha
	 */
	public String getSenha() {
		return senha;
	}
	/**
	 * Modifica a senha do adminstrador
	 * @param senha
	 */
	public void setSenha(String senha) {
		this.senha = senha;
	}
	/**
	 * recupera a pergunta do adminstrador
	 * @return pergunta
	 */
	public String getPergunta() {
		return pergunta;
	}
	/**
	 * recupera a hora de inicio do administrador
	 * @return hora
	 */
	public String getHoraInicio() {
		return horaInicio;
	}
	/**
	 * modifica a hora de inicio do administrador
	 * @param hora
	 */
	public void setHoraInicio(String horaInicio) {
		this.horaInicio = horaInicio;
	}
	/**
	 * recupera a hora de termino do administrador
	 * @return hora
	 */
	public String getHoraTermino() {
		return horaTermino;
	}
	/**
	 * modifica a hora de termino do administrador
	 * @param hora
	 */
	public void setHoraTermino(String horaTermino) {
		this.horaTermino = horaTermino;
	}
	/**
	 * Atualiza os jogos
	 * @param fase, mapa
	 */
	
	public void atualizaJogos(int fase, ArrayList<String> resultados){
		if (fase == 1)
			jogos1fase = resultados;
		if (fase == 2)
			jogos8final = resultados;
		if (fase == 3)
			jogos4final = resultados;
		if (fase == 4)
			jogosSemiFinal = resultados;
		if (fase == 5)
			jogoFinal = resultados;
		
		
		
	}
	
	/**
	 * Atualiza times
	 * @param fase, times
	 */
	public void atualizarTimes(int fase, ArrayList<String> times){
		if (fase == 1)
			timesJogos1fase = times;
		if (fase == 2)
			timesJogos8final = times;
		if (fase == 3)
			timesJogos4final = times;
		if (fase == 4)
			timesJogosSemiFinal = times;
		if (fase == 5)
			timesJogoFinal = times;
	}
	
	/**
	 * Inicia os jogos
	 */
	public void iniciaJogos(){
		
		timesJogos1fase.add("Brasil Croacia");
		timesJogos1fase.add("Mexico Camaroes");
		timesJogos1fase.add("Espanha Holanda");
		timesJogos1fase.add("Chile Australia");
		timesJogos1fase.add("Colombia Grecia");
		timesJogos1fase.add("Costa-do-Marfim Japao");
		timesJogos1fase.add("Uruguai Costa-Rica");
		timesJogos1fase.add("Inglaterra Italia");
		timesJogos1fase.add("Suica Equador");
		timesJogos1fase.add("Franca Honduras");
		timesJogos1fase.add("Argentina Bosnia");
		timesJogos1fase.add("Ira Nigeria");
		timesJogos1fase.add("Alemanha Portugal");
		timesJogos1fase.add("Gana Estados-Unidos");
		timesJogos1fase.add("Belgica Argelia");
		timesJogos1fase.add("Russia Coreia-do-Sul");
		
		
		
		
		
	}
	public static List<String> getJogos1fase() {
		return jogos1fase;
	}
	public static void setJogos1fase(List<String> jogos1fase) {
		Administrador.jogos1fase = jogos1fase;
	}
	public static List<String> getJogos8final() {
		return jogos8final;
	}
	public static void setJogos8final(List<String> jogos8final) {
		Administrador.jogos8final = jogos8final;
	}
	public static List<String> getJogos4final() {
		return jogos4final;
	}
	public static void setJogos4final(List<String> jogos4final) {
		Administrador.jogos4final = jogos4final;
	}
	public static List<String> getJogosSemiFinal() {
		return jogosSemiFinal;
	}
	public static void setJogosSemiFinal(List<String> jogosSemiFinal) {
		Administrador.jogosSemiFinal = jogosSemiFinal;
	}
	public static List<String> getJogoFinal() {
		return jogoFinal;
	}
	public static void setJogoFinal(List<String> jogoFinal) {
		Administrador.jogoFinal = jogoFinal;
	}
	public static List<String> getTimesJogos1fase() {
		return timesJogos1fase;
	}
	public static void setTimesJogos1fase(List<String> timesJogos1fase) {
		Administrador.timesJogos1fase = timesJogos1fase;
	}
	public static List<String> getTimesJogos8final() {
		return timesJogos8final;
	}
	public static void setTimesJogos8final(List<String> timesJogos8final) {
		Administrador.timesJogos8final = timesJogos8final;
	}
	public static List<String> getTimesJogos4final() {
		return timesJogos4final;
	}
	public static void setTimesJogos4final(List<String> timesJogos4final) {
		Administrador.timesJogos4final = timesJogos4final;
	}
	public static List<String> getTimesJogosSemiFinal() {
		return timesJogosSemiFinal;
	}
	public static void setTimesJogosSemiFinal(List<String> timesJogosSemiFinal) {
		Administrador.timesJogosSemiFinal = timesJogosSemiFinal;
	}
	public static List<String> getTimesJogoFinal() {
		return timesJogoFinal;
	}
	public static void setTimesJogoFinal(List<String> timesJogoFinal) {
		Administrador.timesJogoFinal = timesJogoFinal;
	}
	
}
