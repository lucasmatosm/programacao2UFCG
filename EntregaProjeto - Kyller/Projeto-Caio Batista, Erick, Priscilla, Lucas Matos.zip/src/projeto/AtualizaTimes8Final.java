package projeto;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class AtualizaTimes8Final extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTextField textField_10;
	private JTextField textField_11;
	private JTextField textField_12;
	private JTextField textField_13;
	private JLabel lblJogo_6;
	private JTextField textField_14;
	private JLabel label_15;
	private JTextField textField_15;
	private List<String> times = new ArrayList<String>();
	private String[] timesp = {"Brasil","Croacia","Mexico", "Camaroes","Espanha","Holanda", "Chile", "Australia","Colombia", "Grecia","Costa-do-Marfim" ,"Japao","Uruguai" ,"Costa-Rica","Inglaterra", "Italia","Suica", "Equador","Franca" ,"Honduras","Argentina", "Bosnia","Ira" ,"Nigeria","Alemanha" ,"Portugal","Gana", "Estados-Unidos", "Belgica" ,"Argelia","Russia", "Coreia-do-Sul"};
	private List<String> lista = Arrays.asList(timesp);  
	private ArrayList<String> timesPossiveis = new ArrayList<String>(lista);
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AtualizaTimes8Final frame = new AtualizaTimes8Final();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AtualizaTimes8Final() {
		
		setBounds(100, 100, 364, 363);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("Jogo 1:");
		label.setBounds(10, 14, 46, 14);
		contentPane.add(label);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(66, 11, 116, 20);
		contentPane.add(textField);
		
		JLabel label_1 = new JLabel("X");
		label_1.setBounds(192, 14, 15, 14);
		contentPane.add(label_1);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(208, 11, 116, 20);
		contentPane.add(textField_1);
		
		JLabel lblJogo = new JLabel("Jogo 2:");
		lblJogo.setBounds(10, 42, 46, 14);
		contentPane.add(lblJogo);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(66, 39, 116, 20);
		contentPane.add(textField_2);
		
		JLabel label_3 = new JLabel("X");
		label_3.setBounds(192, 42, 15, 14);
		contentPane.add(label_3);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(208, 39, 116, 20);
		contentPane.add(textField_3);
		
		JLabel lblJogo_1 = new JLabel("Jogo 3:");
		lblJogo_1.setBounds(10, 70, 46, 14);
		contentPane.add(lblJogo_1);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(66, 67, 116, 20);
		contentPane.add(textField_4);
		
		JLabel label_5 = new JLabel("X");
		label_5.setBounds(192, 70, 15, 14);
		contentPane.add(label_5);
		
		textField_5 = new JTextField();
		textField_5.setColumns(10);
		textField_5.setBounds(208, 67, 116, 20);
		contentPane.add(textField_5);
		
		JLabel lblJogo_2 = new JLabel("Jogo 4:");
		lblJogo_2.setBounds(10, 98, 46, 14);
		contentPane.add(lblJogo_2);
		
		textField_6 = new JTextField();
		textField_6.setColumns(10);
		textField_6.setBounds(66, 95, 116, 20);
		contentPane.add(textField_6);
		
		JLabel label_7 = new JLabel("X");
		label_7.setBounds(192, 98, 15, 14);
		contentPane.add(label_7);
		
		textField_7 = new JTextField();
		textField_7.setColumns(10);
		textField_7.setBounds(208, 95, 116, 20);
		contentPane.add(textField_7);
		
		JLabel lblJogo_3 = new JLabel("Jogo 5:");
		lblJogo_3.setBounds(10, 126, 46, 14);
		contentPane.add(lblJogo_3);
		
		textField_8 = new JTextField();
		textField_8.setColumns(10);
		textField_8.setBounds(66, 123, 116, 20);
		contentPane.add(textField_8);
		
		JLabel label_9 = new JLabel("X");
		label_9.setBounds(192, 126, 15, 14);
		contentPane.add(label_9);
		
		textField_9 = new JTextField();
		textField_9.setColumns(10);
		textField_9.setBounds(208, 123, 116, 20);
		contentPane.add(textField_9);
		
		JLabel lblJogo_4 = new JLabel("Jogo 6:");
		lblJogo_4.setBounds(10, 154, 46, 14);
		contentPane.add(lblJogo_4);
		
		textField_10 = new JTextField();
		textField_10.setColumns(10);
		textField_10.setBounds(66, 151, 116, 20);
		contentPane.add(textField_10);
		
		JLabel label_11 = new JLabel("X");
		label_11.setBounds(192, 154, 15, 14);
		contentPane.add(label_11);
		
		textField_11 = new JTextField();
		textField_11.setColumns(10);
		textField_11.setBounds(208, 151, 116, 20);
		contentPane.add(textField_11);
		
		JLabel lblJogo_5 = new JLabel("Jogo 7:");
		lblJogo_5.setBounds(10, 182, 46, 14);
		contentPane.add(lblJogo_5);
		
		textField_12 = new JTextField();
		textField_12.setColumns(10);
		textField_12.setBounds(66, 179, 116, 20);
		contentPane.add(textField_12);
		
		JLabel label_13 = new JLabel("X");
		label_13.setBounds(192, 182, 15, 14);
		contentPane.add(label_13);
		
		textField_13 = new JTextField();
		textField_13.setColumns(10);
		textField_13.setBounds(208, 179, 116, 20);
		contentPane.add(textField_13);
		
		lblJogo_6 = new JLabel("Jogo 8:");
		lblJogo_6.setBounds(10, 210, 46, 14);
		contentPane.add(lblJogo_6);
		
		textField_14 = new JTextField();
		textField_14.setColumns(10);
		textField_14.setBounds(66, 207, 116, 20);
		contentPane.add(textField_14);
		
		label_15 = new JLabel("X");
		label_15.setBounds(192, 210, 15, 14);
		contentPane.add(label_15);
		
		textField_15 = new JTextField();
		textField_15.setColumns(10);
		textField_15.setBounds(208, 207, 116, 20);
		contentPane.add(textField_15);
		
		JButton btnAtualizar = new JButton("Atualizar");
		btnAtualizar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				if (textField.getText().trim().equals("") || textField.getText().equals("") 
						|| textField_1.getText().trim().equals("") || textField_1.getText().equals("")
						|| textField_2.getText().trim().equals("") || textField_2.getText().equals("") 
						|| textField_3.getText().trim().equals("") || textField_3.getText().equals("")
						|| textField_4.getText().trim().equals("") || textField_4.getText().equals("")
						|| textField_5.getText().trim().equals("") || textField_5.getText().equals("")
						|| textField_6.getText().trim().equals("") || textField_6.getText().equals("")
						|| textField_7.getText().trim().equals("") || textField_7.getText().equals("")
						|| textField_8.getText().trim().equals("") || textField_8.getText().equals("")
						|| textField_9.getText().trim().equals("") || textField_9.getText().equals("")
						|| textField_10.getText().trim().equals("") || textField_10.getText().equals("")
						|| textField_11.getText().trim().equals("") || textField_11.getText().equals("")
						|| textField_12.getText().trim().equals("") || textField_12.getText().equals("")
						|| textField_13.getText().trim().equals("") || textField_13.getText().equals("")
						|| textField_14.getText().trim().equals("") || textField_14.getText().equals("")
						|| textField_15.getText().trim().equals("") || textField_15.getText().equals("")){
					
					JOptionPane.showMessageDialog(null, "Verifique os campos novamente, caractere inv�lido ou n�o preenchidos", "Erro na leitura dos campos", JOptionPane.ERROR_MESSAGE);

				}else{
				
				times.add(textField.getText());
				times.add(textField_1.getText());
				times.add(textField_2.getText());
				times.add(textField_3.getText());
				times.add(textField_4.getText());
				times.add(textField_5.getText());
				times.add(textField_6.getText());
				times.add(textField_7.getText());
				times.add(textField_8.getText());
				times.add(textField_9.getText());
				times.add(textField_10.getText());
				times.add(textField_11.getText());
				times.add(textField_12.getText());
				times.add(textField_13.getText());
				times.add(textField_14.getText());
				times.add(textField_15.getText());
				
				if (!(timesPossiveis.containsAll(times))){
					JOptionPane.showMessageDialog(null, "Os times t�m que estar participando da copa para poderem ser cadastrados para pr�xima fase \n    Exemplos : Costa-do-Marfim, Japao, Brasil, Colombia", "Aten��o", JOptionPane.ERROR_MESSAGE);					
					
				}else{
				

				Outputtimes f = new Outputtimes(); //cria objeto do tipo output
				f.openfile(); //abre o arquivo
				f.lerarquivo(); // le todos os objeto e salva em um arquivo

				
				for (Resultado r: f.retornaArquivoFases()) {

					if (r.getFase().equals("Oitavas de final")){// verifica se o usuario é do tipo administrador
						r.setTimes(times);	
						break;
					}
				}

				Inputtimes g = new Inputtimes();
				try {
					g.openfile();
				} catch (FileNotFoundException e) {

					e.printStackTrace();
				}
				for(Resultado r2 : f.retornaArquivoFases()){
					if (r2.getFase().equals("Oitavas de final")){// verifica se o usuario é do tipo administrador
						r2.setTimes(times);
						g.Gravaarquivo(r2);
					}else{
						g.Gravaarquivo(r2);
					}
				}
				g.closefile();
				f.closefile();
				
				JOptionPane.showMessageDialog(null, "Times atualizados com sucesso!");
				dispose();
				
				}
				}
			}
		});
		btnAtualizar.setBounds(118, 260, 105, 23);
		contentPane.add(btnAtualizar);
	}
}
