package projeto;

import javax.swing.*;   

import java.awt.event.*;   
import java.io.FileNotFoundException;
import java.util.*;   

import javax.swing.JOptionPane; 
  
public class Clock implements ActionListener {   
  
    private javax.swing.Timer timer;   
    private JLabel label=new JLabel();
    private String horaInicio, horaTermino;
	private Administrador user;
  
    public Clock(){ 
       disparaRelogio();   
    }   
  
    public void disparaRelogio() {   
       if (timer == null) {   
          timer = new javax.swing.Timer(1000, this);   
          timer.setInitialDelay(0);   
          timer.start();   
       } else if (!timer.isRunning()) {   
          timer.restart();   
       }   
    }   
  
    public void actionPerformed(ActionEvent ae) {   
       GregorianCalendar calendario = new GregorianCalendar();   
       int h = calendario.get(GregorianCalendar.HOUR_OF_DAY);   
       int m = calendario.get(GregorianCalendar.MINUTE);   
       int s = calendario.get(GregorianCalendar.SECOND);   
  
       String hora =   
          ((h < 10) ? "0" : "")   
             + h   
             + ":"   
             + ((m < 10) ? "0" : "")   
             + m   
             + ":"   
             + ((s < 10) ? "0" : "")   
             + s;  
  
       label.setText(hora);
       
       Output f = new Output();
       f.openfile();
       f.lerarquivo();
       Administrador admin = null;
       for (Usuario user : f.usalista()) {
    	   if (user instanceof Administrador){
    		   if (user.getLogin().equals("admin")){
    			   admin = (Administrador) user;
    			   break;
    		   }
    	   }
	}      
       
       horaInicio = admin.getHoraInicio();
       horaTermino = admin.getHoraTermino();
       
       if(!(horaInicio == null && horaTermino == null)){
           if(hora.equals(horaInicio)){
   			Output d = new Output();
   			Input g = new Input();
   			d.openfile();
   			d.lerarquivo();
   			
   			for(Usuario user: d.usalista()) {
   				if(!(user instanceof Administrador)) {
   						user.setSituacao(false);
   				}
   			}
   			
   			try {
   				g.openfile();
   			} catch (FileNotFoundException e) {
   				e.printStackTrace();
   			}
   			
   			for (Usuario user2: d.usalista()) {
   				if(!(user instanceof Administrador)) {
   					g.Gravaarquivo(user2);
   				}
   			}
   				
   			d.closefile();
   			g.closefile();
   			JOptionPane.showMessageDialog(null,"Aten��o, o per�odo para apostas foi encerrado!");
        	   
           }
           
           if(hora.equals(horaTermino)){
      			Output d = new Output();
       			Input g = new Input();
       			d.openfile();
       			d.lerarquivo();
       			
       			for(Usuario user: d.usalista()) {
       				if(!(user instanceof Administrador)) {
       						user.setSituacao(true);
       				}
       			}
       			
       			try {
       				g.openfile();
       			} catch (FileNotFoundException e) {
       				e.printStackTrace();
       			}
       			
       			for (Usuario user2: d.usalista()) {
       				if(!(user instanceof Administrador)) {
       					g.Gravaarquivo(user2);
       				}
       			}
       				
       			d.closefile();
       			g.closefile();
        	   JOptionPane.showMessageDialog(null,"Aten��o, o per�odo para apostas foi aberto!");
        	   
           }    	   
       }
    }      
}