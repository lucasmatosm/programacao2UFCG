package projeto;



import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.FileNotFoundException;

public class ExcluirUsuario extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = -3446456084423030852L;
	private JTextField textField;

	/**
	 * Create the panel.
	 */
	public ExcluirUsuario() {
		setLayout(null);
		
		JLabel lblDigiteAbaixoO = new JLabel("Digite abaixo o nome do usu\u00E1rio que voc\u00EA deseja excluir!");
		lblDigiteAbaixoO.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblDigiteAbaixoO.setBounds(37, 40, 367, 20);
		add(lblDigiteAbaixoO);
		
		textField = new JTextField();
		textField.setBounds(155, 86, 129, 20);
		add(textField);
		textField.setColumns(10);
		
		JButton btnExcluir = new JButton("Excluir");
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Output login = new Output();
				login.openfile();
				login.lerarquivo();
				for (int i = 0; i < login.usalista().size(); i++) {
					if (textField.getText().equals(login.usalista().get(i).getLogin())){
						login.usalista().remove(login.usalista().get(i));		
						}	
					}
				login.closefile();
				Input remove = new Input();
				try {
					remove.openfile();
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				for (int i = 0; i < login.usalista().size(); i++) {
					remove.Gravaarquivo(login.usalista().get(i));
				}
				remove.closefile();
				JOptionPane.showMessageDialog(null,"Usuario excluido com sucesso");
				}
			
		});
		btnExcluir.setBounds(173, 153, 89, 23);
		add(btnExcluir);

	}
}