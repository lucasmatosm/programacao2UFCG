package projeto;

public interface EstrategiaCalculaPontos {
	
	/**
	 * Interface para calcular os pontos das apostas
	 * @param i
	 * @param user
	 * @return
	 */
	
	public int calculaPontos(int i, Usuario user);

}
