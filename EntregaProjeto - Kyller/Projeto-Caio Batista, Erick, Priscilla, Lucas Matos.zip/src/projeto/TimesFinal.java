package projeto;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class TimesFinal extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1601433840673251580L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private List<String> resultsuser = new ArrayList<String>();
	private boolean mudarApostas;
	private Usuario user;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TimesFinal frame = new TimesFinal(false,null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TimesFinal(final boolean mudarApostas, final Usuario user) {
		this.mudarApostas = mudarApostas;
		this.user = user;

		setBounds(100, 100, 385, 131);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblJogoFinal = new JLabel("Jogo :");
		lblJogoFinal.setBounds(10, 14, 46, 14);
		contentPane.add(lblJogoFinal);

		JLabel label_1 = new JLabel(pegaTime(0,1));
		label_1.setBounds(66, 14, 106, 14);
		contentPane.add(label_1);

		textField = new JTextField(retornaApostaCasoExista(mudarApostas, 7, 0));
		textField.setColumns(10);
		textField.setBounds(164, 11, 23, 20);
		contentPane.add(textField);

		JLabel label_2 = new JLabel("X");
		label_2.setBounds(201, 14, 23, 14);
		contentPane.add(label_2);

		textField_1 = new JTextField(retornaApostaCasoExista(mudarApostas, 7, 1));
		textField_1.setColumns(10);
		textField_1.setBounds(221, 11, 23, 20);
		contentPane.add(textField_1);

		JLabel label_3 = new JLabel(pegaTime(0,2));
		label_3.setBounds(266, 14, 105, 14);
		contentPane.add(label_3);

		JButton btnConcluir = new JButton("Concluir");
		btnConcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if(user instanceof Administrador){

					resultsuser.add(textField.getText());
					resultsuser.add(textField_1.getText());




					Outputtimes f = new Outputtimes(); //cria objeto do tipo output
					f.openfile(); //abre o arquivo
					f.lerarquivo(); // le todos os objeto e salva em um arquivo
					for (Resultado r: f.retornaArquivoFases()) {

						if (r.getFase().equals("Final")){// verifica se o usuario é do tipo administrador
							r.setResultados(resultsuser);	
						}
					}

					Inputtimes atualiza = new Inputtimes();
					try {
						atualiza.openfile();
					} catch (FileNotFoundException e1) {

						e1.printStackTrace();
					}

					for(Resultado r2 : f.retornaArquivoFases()){
						
							atualiza.Gravaarquivo(r2);
						
					}

					f.closefile();
					atualiza.closefile();
					
					calculaPontosDeTodosOsUsuarios(6);
					
					JOptionPane.showMessageDialog(null,"Resultados atualizados com sucesso");
					dispose();
					
				}else{

					resultsuser.add(textField.getText());
					resultsuser.add(textField_1.getText());
					Jogador apostador = (Jogador) user;


					Output usuario = new Output();
					usuario.openfile();
					usuario.lerarquivo();

					for (Usuario user2: usuario.usalista()) {
						if(user2.getLogin().equals(apostador.getLogin())){
							apostador.getApostas().add(7,((ArrayList<String>) resultsuser));
							apostador.getApostas().remove(8);
						}
					}
					usuario.closefile();
					Input Usuario2 = new Input();
					try {
						Usuario2.openfile();
					} catch (FileNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}

					int controle = 1;

					for (Usuario  user4 : usuario.usalista()) {
						if(user4.getLogin().equals(apostador.getLogin())){
							if (user4 instanceof Jogador && controle == 1){
								controle++;	
								Jogador	user3 = (Jogador) user4;


								user3.setapostas(apostador.getApostas());
								Usuario2.Gravaarquivo(user3);

							}	
						}
						else{
							Usuario2.Gravaarquivo(user4);
						}





					}
					Usuario2.closefile();

					JOptionPane.showMessageDialog(null,"Resultados atualizados com sucesso");
					dispose();
				}
				
			}
		});






		btnConcluir.setBounds(135, 58, 89, 23);
		contentPane.add(btnConcluir);
	}

	private String pegaTime(int jogo, int time){
		Outputtimes f = new Outputtimes();
		f.openfile();
		f.lerarquivo();

		Resultado re = null;
		List<String> primeiroTime = new ArrayList<String>();
		List<String> segundoTime = new ArrayList<String>();

		for (Resultado r: f.retornaArquivoFases()){
			if (r.getFase().equals("Final")){
				re = r;
				break;
			}
		}

		f.closefile();

		for (int i= 0; i < re.getTimes().size(); i++){
			if (i % 2 == 0)
				primeiroTime.add(re.getTimes().get(i));
			else
				segundoTime.add(re.getTimes().get(i));
		}

		if (time == 1){
			return primeiroTime.get(jogo);
		}else{
			return segundoTime.get(jogo);
		}
	}
	
	
	private  void calculaPontosDeTodosOsUsuarios(int rodada){

		CalculaPontosFinal c1 = new CalculaPontosFinal();

		Output usuario = new Output();
		usuario.openfile();
		usuario.lerarquivo();
		
		List<ArrayList<String>> c = new ArrayList<ArrayList<String>>();

		for (Usuario user2: usuario.usalista()) {
			Usuario user21 = user2;
			try{
			c = user21.getApostas();
			}catch(Exception e){
				c = null;
			}
		
			if (!(user21  instanceof Administrador)){
			
				if((user21.getApostas().isEmpty()) || c.get(rodada - 1).isEmpty()){ 
					user21.setPontos(user21.getPontos() + 0);
				}else{
					user21.setPontos(user21.getPontos() + c1.calculaPontos(rodada, user21));

				}
			
			
			}
		}

		usuario.openfile();
		Input Usuario2 = new Input();
		try {
			Usuario2.openfile();
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		for (Usuario  user3 : usuario.usalista()) {
			Usuario2.Gravaarquivo(user3);
		}
		Usuario2.closefile();




	}
	
private String retornaApostaCasoExista(boolean mudarAposta, int rodada, int aposta){
		
		mudarAposta = mudarApostas; 
		
		if (mudarAposta){
			
			Output g = new Output();
			g.openfile();
			g.lerarquivo();
			
			for (Usuario r : g.usalista()) {
				if (!(r instanceof Administrador)){
					if (r.getLogin().equals(user.getLogin())){
						return user.getApostas().get(rodada - 1).get(aposta);
						}
					}
				}
		}
		
		return "0";
		
		
		
	}




}
