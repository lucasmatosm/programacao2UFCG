package projeto;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class AtualizaTimesSemiFinal extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private List<String> times = new ArrayList<String>();
	private String[] timesp = {"Brasil","Croacia","Mexico", "Camaroes","Espanha","Holanda", "Chile", "Australia","Colombia", "Grecia","Costa-do-Marfim" ,"Japao","Uruguai" ,"Costa-Rica","Inglaterra", "Italia","Suica", "Equador","Franca" ,"Honduras","Argentina", "Bosnia","Ira" ,"Nigeria","Alemanha" ,"Portugal","Gana", "Estados-Unidos", "Belgica" ,"Argelia","Russia", "Coreia-do-Sul"};
	private List<String> lista = Arrays.asList(timesp);  
	private ArrayList<String> timesPossiveis = new ArrayList<String>(lista);

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AtualizaTimesSemiFinal frame = new AtualizaTimesSemiFinal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AtualizaTimesSemiFinal() {
		
		setBounds(100, 100, 356, 166);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("Jogo 1:");
		label.setBounds(10, 14, 46, 14);
		contentPane.add(label);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(66, 11, 116, 20);
		contentPane.add(textField);
		
		JLabel label_1 = new JLabel("X");
		label_1.setBounds(192, 14, 15, 14);
		contentPane.add(label_1);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(208, 11, 116, 20);
		contentPane.add(textField_1);
		
		JLabel label_2 = new JLabel("Jogo 2:");
		label_2.setBounds(10, 42, 46, 14);
		contentPane.add(label_2);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(66, 39, 116, 20);
		contentPane.add(textField_2);
		
		JLabel label_3 = new JLabel("X");
		label_3.setBounds(192, 42, 15, 14);
		contentPane.add(label_3);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(208, 39, 116, 20);
		contentPane.add(textField_3);
		
		JButton button = new JButton("Atualizar");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if (textField.getText().trim().equals("") || textField.getText().equals("")
						|| textField_1.getText().trim().equals("") || textField_1.getText().equals("")
						|| textField_2.getText().trim().equals("") || textField_2.getText().equals("") 
						|| textField_3.getText().trim().equals("") || textField_3.getText().equals("")){
					
					JOptionPane.showMessageDialog(null, "Verifique os campos novamente, caractere inv�lido ou n�o preenchidos", "Erro na leitura dos campos", JOptionPane.ERROR_MESSAGE);

				}else{
				
				times.add(textField.getText());
				times.add(textField_1.getText());
				times.add(textField_2.getText());
				times.add(textField_3.getText());
				
				if (!(timesPossiveis.containsAll(times))){
					JOptionPane.showMessageDialog(null, "Os times t�m que estar participando da copa para poderem ser cadastrados para pr�xima fase \n    Exemplos : Costa-do-Marfim, Japao, Brasil, Colombia", "Aten��o", JOptionPane.ERROR_MESSAGE);					
					
				}else {
			

				Outputtimes f = new Outputtimes(); //cria objeto do tipo output
				f.openfile(); //abre o arquivo
				f.lerarquivo(); // le todos os objeto e salva em um arquivo

				
				for (Resultado r: f.retornaArquivoFases()) {

					if (r.getFase().equals("Semifinal")){// verifica se o usuario é do tipo administrador
						r.setTimes(times);	
						break;
					}
				}

				Inputtimes g = new Inputtimes();
				try {
					g.openfile();
				} catch (FileNotFoundException e1) {

					e1.printStackTrace();
				}
				for(Resultado r2 : f.retornaArquivoFases()){
					if (r2.getFase().equals("Semifinal")){// verifica se o usuario é do tipo administrador
						r2.setTimes(times);
						g.Gravaarquivo(r2);
					}else{
						g.Gravaarquivo(r2);
					}
				}
				g.closefile();
				f.closefile();
				
				JOptionPane.showMessageDialog(null, "Times atualizados com sucesso!");
				dispose();
				
				}
				
				}
			}
		});
		button.setBounds(120, 88, 105, 23);
		contentPane.add(button);
	}

}
