package projeto;



import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.FileNotFoundException;

public class Mudarsenha extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = -3446456084423030852L;
	private JTextField textField, textField1, textField2;

	/**
	 * Create the panel.
	 */
	public Mudarsenha() {
		setLayout(null);
		JLabel lblDigiteAbaixoO2 = new JLabel("Digite abaixo o nome do usu\u00E1rio");
		lblDigiteAbaixoO2.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblDigiteAbaixoO2.setBounds(26, 38, 367, 20);
		add(lblDigiteAbaixoO2);
		
		textField2 = new JTextField();
		textField2.setBounds(155, 70, 129, 20);
		add(textField2);
		textField2.setColumns(10);
		
		
		
		JLabel lblDigiteAbaixoO = new JLabel("Digite abaixo a senha antiga");
		lblDigiteAbaixoO.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblDigiteAbaixoO.setBounds(26, 102, 367, 20);
		add(lblDigiteAbaixoO);
		
		textField = new JTextField();
		textField.setBounds(155, 134, 129, 20);
		add(textField);
		textField.setColumns(10);
		
		
		JLabel lblDigiteAbaixo1 = new JLabel("Digite abaixo a nova senha:");
		lblDigiteAbaixo1.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblDigiteAbaixo1.setBounds(26, 166, 367, 20);
		add(lblDigiteAbaixo1);
		
		textField1 = new JTextField();
		textField1.setBounds(155, 198, 129, 20);
		add(textField1);
		textField1.setColumns(10);
		
		JButton btnExcluir = new JButton("Mudar Senha");
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Output login = new Output();
				login.openfile();
				login.lerarquivo();
				String n = textField.getText();
				String g = textField1.getText();
				String h = textField2.getText();
				for (int i = 0; i < login.usalista().size(); i++) {
					if (n.equals(login.usalista().get(i).getSenha()) && h.equals(login.usalista().get(i).getLogin())){
						login.usalista().get(i).setSenha(g);		
						}	
					}
				login.closefile();
				Input remove = new Input();
				try {
					remove.openfile();
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				for (int i = 0; i < login.usalista().size(); i++) {
					remove.Gravaarquivo(login.usalista().get(i));
				}
				remove.closefile();
				JOptionPane.showMessageDialog(null,"Senha alterada com sucesso");
				}
			
		});
		btnExcluir.setBounds(155, 245, 129, 23);
		add(btnExcluir);

	}
}