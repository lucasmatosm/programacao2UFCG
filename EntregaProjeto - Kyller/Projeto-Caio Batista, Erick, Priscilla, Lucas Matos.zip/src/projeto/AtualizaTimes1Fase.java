package projeto;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class AtualizaTimes1Fase extends JFrame {

	/**
	 * code
	 */
	private static final long serialVersionUID = -3407443843741556673L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JLabel lblJogo_1;
	private JTextField textField_2;
	private JLabel label_1;
	private JTextField textField_3;
	private JLabel lblJogo_2;
	private JTextField textField_4;
	private JLabel label_3;
	private JTextField textField_5;
	private JLabel lblJogo_3;
	private JTextField textField_6;
	private JLabel label_5;
	private JTextField textField_7;
	private JLabel lblJogo_4;
	private JTextField textField_8;
	private JLabel label_7;
	private JTextField textField_9;
	private JLabel lblJogo_5;
	private JTextField textField_10;
	private JLabel label_9;
	private JTextField textField_11;
	private JLabel lblJogo_6;
	private JTextField textField_12;
	private JLabel label_11;
	private JTextField textField_13;
	private JLabel lblJogo_7;
	private JTextField textField_14;
	private JLabel label_13;
	private JTextField textField_15;
	private JLabel lblJogo_8;
	private JTextField textField_16;
	private JLabel label_15;
	private JTextField textField_17;
	private JLabel lblJogo_9;
	private JTextField textField_18;
	private JLabel label_17;
	private JTextField textField_19;
	private JLabel lblJogo_10;
	private JTextField textField_20;
	private JLabel label_19;
	private JTextField textField_21;
	private JLabel lblJogo_11;
	private JTextField textField_22;
	private JLabel label_21;
	private JTextField textField_23;
	private JLabel lblJogo_12;
	private JTextField textField_24;
	private JLabel label_23;
	private JTextField textField_25;
	private JLabel lblJogo_13;
	private JTextField textField_26;
	private JLabel label_25;
	private JTextField textField_27;
	private JLabel lblJogo_14;
	private JTextField textField_28;
	private JLabel label_27;
	private JTextField textField_29;
	private JLabel lblJogo_15;
	private JTextField textField_30;
	private JLabel label_29;
	private JTextField textField_31;
	
	private List<String> times = new ArrayList<String>();
	private String[] timesp = {"Brasil","Croacia","Mexico", "Camaroes","Espanha","Holanda", "Chile", "Australia","Colombia", "Grecia","Costa-do-Marfim" ,"Japao","Uruguai" ,"Costa-Rica","Inglaterra", "Italia","Suica", "Equador","Franca" ,"Honduras","Argentina", "Bosnia","Ira" ,"Nigeria","Alemanha" ,"Portugal","Gana", "Estados-Unidos", "Belgica" ,"Argelia","Russia", "Coreia-do-Sul"};
	private List<String> lista = Arrays.asList(timesp);  
	private ArrayList<String> timesPossiveis = new ArrayList<String>(lista);
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AtualizaTimes1Fase frame = new AtualizaTimes1Fase(0);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AtualizaTimes1Fase(final int fase) {

		setBounds(100, 100, 385, 545);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblJogo = new JLabel("Jogo 1:");
		lblJogo.setBounds(10, 11, 46, 14);
		contentPane.add(lblJogo);

		textField = new JTextField();
		textField.setBounds(66, 8, 116, 20);
		contentPane.add(textField);
		textField.setColumns(10);

		JLabel lblX = new JLabel("X");
		lblX.setBounds(192, 11, 15, 14);
		contentPane.add(lblX);

		textField_1 = new JTextField();
		textField_1.setBounds(208, 8, 116, 20);
		contentPane.add(textField_1);
		textField_1.setColumns(10);

		lblJogo_1 = new JLabel("Jogo 2:");
		lblJogo_1.setBounds(10, 39, 46, 14);
		contentPane.add(lblJogo_1);

		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(66, 36, 116, 20);
		contentPane.add(textField_2);

		label_1 = new JLabel("X");
		label_1.setBounds(192, 39, 15, 14);
		contentPane.add(label_1);

		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(208, 36, 116, 20);
		contentPane.add(textField_3);

		lblJogo_2 = new JLabel("Jogo 3:");
		lblJogo_2.setBounds(10, 67, 46, 14);
		contentPane.add(lblJogo_2);

		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(66, 64, 116, 20);
		contentPane.add(textField_4);

		label_3 = new JLabel("X");
		label_3.setBounds(192, 67, 15, 14);
		contentPane.add(label_3);

		textField_5 = new JTextField();
		textField_5.setColumns(10);
		textField_5.setBounds(208, 64, 116, 20);
		contentPane.add(textField_5);

		lblJogo_3 = new JLabel("Jogo 4:");
		lblJogo_3.setBounds(10, 95, 46, 14);
		contentPane.add(lblJogo_3);

		textField_6 = new JTextField();
		textField_6.setColumns(10);
		textField_6.setBounds(66, 92, 116, 20);
		contentPane.add(textField_6);

		label_5 = new JLabel("X");
		label_5.setBounds(192, 95, 15, 14);
		contentPane.add(label_5);

		textField_7 = new JTextField();
		textField_7.setColumns(10);
		textField_7.setBounds(208, 92, 116, 20);
		contentPane.add(textField_7);

		lblJogo_4 = new JLabel("Jogo 5:");
		lblJogo_4.setBounds(10, 123, 46, 14);
		contentPane.add(lblJogo_4);

		textField_8 = new JTextField();
		textField_8.setColumns(10);
		textField_8.setBounds(66, 120, 116, 20);
		contentPane.add(textField_8);

		label_7 = new JLabel("X");
		label_7.setBounds(192, 123, 15, 14);
		contentPane.add(label_7);

		textField_9 = new JTextField();
		textField_9.setColumns(10);
		textField_9.setBounds(208, 120, 116, 20);
		contentPane.add(textField_9);

		lblJogo_5 = new JLabel("Jogo 6:");
		lblJogo_5.setBounds(10, 151, 46, 14);
		contentPane.add(lblJogo_5);

		textField_10 = new JTextField();
		textField_10.setColumns(10);
		textField_10.setBounds(66, 148, 116, 20);
		contentPane.add(textField_10);

		label_9 = new JLabel("X");
		label_9.setBounds(192, 151, 15, 14);
		contentPane.add(label_9);

		textField_11 = new JTextField();
		textField_11.setColumns(10);
		textField_11.setBounds(208, 148, 116, 20);
		contentPane.add(textField_11);

		lblJogo_6 = new JLabel("Jogo 7:");
		lblJogo_6.setBounds(10, 179, 46, 14);
		contentPane.add(lblJogo_6);

		textField_12 = new JTextField();
		textField_12.setColumns(10);
		textField_12.setBounds(66, 176, 116, 20);
		contentPane.add(textField_12);

		label_11 = new JLabel("X");
		label_11.setBounds(192, 179, 15, 14);
		contentPane.add(label_11);

		textField_13 = new JTextField();
		textField_13.setColumns(10);
		textField_13.setBounds(208, 176, 116, 20);
		contentPane.add(textField_13);

		lblJogo_7 = new JLabel("Jogo 8:");
		lblJogo_7.setBounds(10, 207, 46, 14);
		contentPane.add(lblJogo_7);

		textField_14 = new JTextField();
		textField_14.setColumns(10);
		textField_14.setBounds(66, 204, 116, 20);
		contentPane.add(textField_14);

		label_13 = new JLabel("X");
		label_13.setBounds(192, 207, 15, 14);
		contentPane.add(label_13);

		textField_15 = new JTextField();
		textField_15.setColumns(10);
		textField_15.setBounds(208, 204, 116, 20);
		contentPane.add(textField_15);

		lblJogo_8 = new JLabel("Jogo 9:");
		lblJogo_8.setBounds(10, 235, 46, 14);
		contentPane.add(lblJogo_8);

		textField_16 = new JTextField();
		textField_16.setColumns(10);
		textField_16.setBounds(66, 232, 116, 20);
		contentPane.add(textField_16);

		label_15 = new JLabel("X");
		label_15.setBounds(192, 235, 15, 14);
		contentPane.add(label_15);

		textField_17 = new JTextField();
		textField_17.setColumns(10);
		textField_17.setBounds(208, 232, 116, 20);
		contentPane.add(textField_17);

		lblJogo_9 = new JLabel("Jogo 10:");
		lblJogo_9.setBounds(10, 263, 52, 14);
		contentPane.add(lblJogo_9);

		textField_18 = new JTextField();
		textField_18.setColumns(10);
		textField_18.setBounds(66, 260, 116, 20);
		contentPane.add(textField_18);

		label_17 = new JLabel("X");
		label_17.setBounds(192, 263, 15, 14);
		contentPane.add(label_17);

		textField_19 = new JTextField();
		textField_19.setColumns(10);
		textField_19.setBounds(208, 260, 116, 20);
		contentPane.add(textField_19);

		lblJogo_10 = new JLabel("Jogo 11:");
		lblJogo_10.setBounds(10, 291, 52, 14);
		contentPane.add(lblJogo_10);

		textField_20 = new JTextField();
		textField_20.setColumns(10);
		textField_20.setBounds(66, 288, 116, 20);
		contentPane.add(textField_20);

		label_19 = new JLabel("X");
		label_19.setBounds(192, 291, 15, 14);
		contentPane.add(label_19);

		textField_21 = new JTextField();
		textField_21.setColumns(10);
		textField_21.setBounds(208, 288, 116, 20);
		contentPane.add(textField_21);

		lblJogo_11 = new JLabel("Jogo 12:");
		lblJogo_11.setBounds(10, 319, 52, 14);
		contentPane.add(lblJogo_11);

		textField_22 = new JTextField();
		textField_22.setColumns(10);
		textField_22.setBounds(66, 316, 116, 20);
		contentPane.add(textField_22);

		label_21 = new JLabel("X");
		label_21.setBounds(192, 319, 15, 14);
		contentPane.add(label_21);

		textField_23 = new JTextField();
		textField_23.setColumns(10);
		textField_23.setBounds(208, 316, 116, 20);
		contentPane.add(textField_23);

		lblJogo_12 = new JLabel("Jogo 13:");
		lblJogo_12.setBounds(10, 347, 52, 14);
		contentPane.add(lblJogo_12);

		textField_24 = new JTextField();
		textField_24.setColumns(10);
		textField_24.setBounds(66, 344, 116, 20);
		contentPane.add(textField_24);

		label_23 = new JLabel("X");
		label_23.setBounds(192, 347, 15, 14);
		contentPane.add(label_23);

		textField_25 = new JTextField();
		textField_25.setColumns(10);
		textField_25.setBounds(208, 344, 116, 20);
		contentPane.add(textField_25);

		lblJogo_13 = new JLabel("Jogo 14:");
		lblJogo_13.setBounds(10, 375, 52, 14);
		contentPane.add(lblJogo_13);

		textField_26 = new JTextField();
		textField_26.setColumns(10);
		textField_26.setBounds(66, 372, 116, 20);
		contentPane.add(textField_26);

		label_25 = new JLabel("X");
		label_25.setBounds(192, 375, 15, 14);
		contentPane.add(label_25);

		textField_27 = new JTextField();
		textField_27.setColumns(10);
		textField_27.setBounds(208, 372, 116, 20);
		contentPane.add(textField_27);

		lblJogo_14 = new JLabel("Jogo 15:");
		lblJogo_14.setBounds(10, 403, 52, 14);
		contentPane.add(lblJogo_14);

		textField_28 = new JTextField();
		textField_28.setColumns(10);
		textField_28.setBounds(66, 400, 116, 20);
		contentPane.add(textField_28);

		label_27 = new JLabel("X");
		label_27.setBounds(192, 403, 15, 14);
		contentPane.add(label_27);

		textField_29 = new JTextField();
		textField_29.setColumns(10);
		textField_29.setBounds(208, 400, 116, 20);
		contentPane.add(textField_29);

		lblJogo_15 = new JLabel("Jogo 16:");
		lblJogo_15.setBounds(10, 431, 52, 14);
		contentPane.add(lblJogo_15);

		textField_30 = new JTextField();
		textField_30.setColumns(10);
		textField_30.setBounds(66, 428, 116, 20);
		contentPane.add(textField_30);

		label_29 = new JLabel("X");
		label_29.setBounds(192, 431, 15, 14);
		contentPane.add(label_29);

		textField_31 = new JTextField();
		textField_31.setColumns(10);
		textField_31.setBounds(208, 428, 116, 20);
		contentPane.add(textField_31);

		JButton btnAtualizar = new JButton("Atualizar");
		btnAtualizar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				if (textField.getText().trim().equals("") || textField.getText().equals("")
						|| textField_1.getText().trim().equals("") || textField_1.getText().equals("")
						|| textField_2.getText().trim().equals("") || textField_2.getText().equals("") 
						|| textField_3.getText().trim().equals("") || textField_3.getText().equals("")
						|| textField_4.getText().trim().equals("") || textField_4.getText().equals("")
						|| textField_5.getText().trim().equals("") || textField_5.getText().equals("")
						|| textField_6.getText().trim().equals("") || textField_6.getText().equals("")
						|| textField_7.getText().trim().equals("") || textField_7.getText().equals("")
						|| textField_8.getText().trim().equals("") || textField_8.getText().equals("")
						|| textField_9.getText().trim().equals("") || textField_9.getText().equals("")
						|| textField_10.getText().trim().equals("") || textField_10.getText().equals("")
						|| textField_11.getText().trim().equals("") || textField_11.getText().equals("")
						|| textField_12.getText().trim().equals("") || textField_12.getText().equals("")
						|| textField_13.getText().trim().equals("") || textField_13.getText().equals("")
						|| textField_14.getText().trim().equals("") || textField_14.getText().equals("")
						|| textField_15.getText().trim().equals("") || textField_15.getText().equals("")
						|| textField_16.getText().trim().equals("") || textField_16.getText().equals("")
						|| textField_17.getText().trim().equals("") || textField_17.getText().equals("")
						|| textField_18.getText().trim().equals("") || textField_18.getText().equals("") 
						|| textField_19.getText().trim().equals("") || textField_19.getText().equals("")
						|| textField_20.getText().trim().equals("") || textField_20.getText().equals("")
						|| textField_21.getText().trim().equals("") || textField_21.getText().equals("")
						|| textField_22.getText().trim().equals("") || textField_22.getText().equals("")
						|| textField_23.getText().trim().equals("") || textField_23.getText().equals("")
						|| textField_24.getText().trim().equals("") || textField_24.getText().equals("")
						|| textField_25.getText().trim().equals("") || textField_25.getText().equals("")
						|| textField_26.getText().trim().equals("") || textField_26.getText().equals("")
						|| textField_27.getText().trim().equals("") || textField_27.getText().equals("")
						|| textField_28.getText().trim().equals("") || textField_28.getText().equals("")
						|| textField_29.getText().trim().equals("") || textField_29.getText().equals("")
						|| textField_30.getText().trim().equals("") || textField_30.getText().equals("")
						|| textField_31.getText().trim().equals("") || textField_31.getText().equals("")){
					
					JOptionPane.showMessageDialog(null, "Verifique os campos novamente, caractere inv�lido ou n�o preenchidos", "Erro na leitura dos campos", JOptionPane.ERROR_MESSAGE);

				}else{

					times.add(textField.getText());
					times.add(textField_1.getText());
					times.add(textField_2.getText());
					times.add(textField_3.getText());
					times.add(textField_4.getText());
					times.add(textField_5.getText());
					times.add(textField_6.getText());
					times.add(textField_7.getText());
					times.add(textField_8.getText());
					times.add(textField_9.getText());
					times.add(textField_10.getText());
					times.add(textField_11.getText());
					times.add(textField_12.getText());
					times.add(textField_13.getText());
					times.add(textField_14.getText());
					times.add(textField_15.getText());
					times.add(textField_16.getText());
					times.add(textField_17.getText());
					times.add(textField_18.getText());
					times.add(textField_19.getText());
					times.add(textField_20.getText());
					times.add(textField_21.getText());
					times.add(textField_22.getText());
					times.add(textField_23.getText());
					times.add(textField_24.getText());
					times.add(textField_25.getText());
					times.add(textField_26.getText());
					times.add(textField_27.getText());
					times.add(textField_28.getText());
					times.add(textField_29.getText());
					times.add(textField_30.getText());
					times.add(textField_31.getText());

					if (!(timesPossiveis.containsAll(times))){
						JOptionPane.showMessageDialog(null, "Os times t�m que estar participando da copa para poderem ser cadastrados para pr�xima fase \n    Exemplos : Costa-do-Marfim, Japao, Brasil, Colombia", "Aten��o", JOptionPane.ERROR_MESSAGE);
						
						
					
					}else{

					Outputtimes f = new Outputtimes(); //cria objeto do tipo output
					f.openfile(); //abre o arquivo
					f.lerarquivo(); // le todos os objeto e salva em um arquivo

					if (fase == 2){
						for (Resultado r: f.retornaArquivoFases()) {

							if (r.getFase().equals("1 Fase - 2 Rodada")){// verifica se o usuario é do tipo administrador
								r.setTimes(times);	
								break;
							}
						}

						Inputtimes g = new Inputtimes();
						try {
							g.openfile();
						} catch (FileNotFoundException e) {

							e.printStackTrace();
						}
						for(Resultado r2 : f.retornaArquivoFases()){
							if (r2.getFase().equals("1 Fase - 2 Rodada")){
								r2.setTimes(times);
								g.Gravaarquivo(r2);
								
							}else{
								g.Gravaarquivo(r2);
							}
						}
						g.closefile();
						f.closefile();
						
						JOptionPane.showMessageDialog(null, "Times atualizados com sucesso!");

					}else if (fase == 3){

						for (Resultado r: f.retornaArquivoFases()) {

							if (r.getFase().equals("1 Fase - 3 Rodada")){// verifica se o usuario é do tipo administrador
								r.setTimes(times);	
							}
						}

						Inputtimes g = new Inputtimes();
						try {
							g.openfile();
						} catch (FileNotFoundException e) {

							e.printStackTrace();
						}
						for(Resultado r2 : f.retornaArquivoFases()){
							if (r2.getFase().equals("1 Fase - 3 Rodada")){
								r2.setTimes(times);
								g.Gravaarquivo(r2);
								
							}else{
								g.Gravaarquivo(r2);
							}
						}
						g.closefile();
						f.closefile();
						
						JOptionPane.showMessageDialog(null, "Times atualizados com sucesso!");


					}


					
					dispose();
				}
				}
			}

		});
		btnAtualizar.setBounds(156, 472, 89, 23);
		contentPane.add(btnAtualizar);

	}
}
