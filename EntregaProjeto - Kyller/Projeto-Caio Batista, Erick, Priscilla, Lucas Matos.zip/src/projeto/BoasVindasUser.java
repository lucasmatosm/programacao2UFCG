package projeto;


import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.Toolkit;

import javax.swing.JLabel;



import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;



public class BoasVindasUser extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BoasVindasUser frame = new BoasVindasUser();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public BoasVindasUser() {
		setTitle("Bem-vindo usu\u00E1rio!");
		setIconImage(Toolkit.getDefaultToolkit().getImage(BoasVindasUser.class.getResource("/projeto/copa-Fifa.jpg")));
		setBounds(100, 100, 346, 294);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("Esse menu torna poss\u00EDvel as seguintes opera\u00E7\u00F5es:");
		label.setBounds(10, 11, 302, 14);
		contentPane.add(label);
		
		JLabel lblFazermodificarApostas = new JLabel("1. Fazer/Modificar apostas.");
		lblFazermodificarApostas.setBounds(33, 47, 240, 14);
		contentPane.add(lblFazermodificarApostas);
		
		JLabel lblAcessarO = new JLabel("2. Acessar o ranking parcial/geral");
		lblAcessarO.setBounds(33, 72, 240, 14);
		contentPane.add(lblAcessarO);
		
		JLabel lblConsultarTodo = new JLabel("3. Consultar todo hist\u00F3rico e seu perfil.");
		lblConsultarTodo.setBounds(33, 97, 240, 14);
		contentPane.add(lblConsultarTodo);
		
		JLabel lblAcessarcriarsairDos = new JLabel("4. Acessar/Criar/Sair dos seus grupos de aposta.");
		lblAcessarcriarsairDos.setBounds(33, 122, 279, 14);
		contentPane.add(lblAcessarcriarsairDos);
		
		JLabel label_5 = new JLabel("5. Configurar sua conta.");
		label_5.setBounds(33, 147, 240, 14);
		contentPane.add(label_5);
		
		JButton btnComearAApostar = new JButton("Come\u00E7ar a apostar!");
		btnComearAApostar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				dispose();
			}
		});
		btnComearAApostar.setBounds(71, 202, 162, 23);
		contentPane.add(btnComearAApostar);
	}
}
