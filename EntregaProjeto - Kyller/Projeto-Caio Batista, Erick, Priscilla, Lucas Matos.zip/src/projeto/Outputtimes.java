package projeto;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.*;
/**
 * Construtor da classe Output para leitura de dados do arquivo
 */
public class Outputtimes {
	private ObjectInputStream inputtimes;
	ArrayList<Resultado> todasAsFases = new ArrayList<Resultado>();
        Resultado result;
	/**
	 * Funcao para abrir o arquivo
	 */
	public void openfile(){
		try{
			inputtimes = new ObjectInputStream(new FileInputStream("times.dat") );
		}catch(IOException ioException){
			System.err.println("Erro ao abrir o arquivo");
		}

	}
	/**
	 * Funcao para leitura do arquivo
	 */
	public void lerarquivo(){
		try{
			while(true){
					result = (Resultado) inputtimes.readObject();
					todasAsFases.add(result);
				
			}
		}catch(EOFException ENDoFFILEesception){
			return;
		}catch(ClassNotFoundException classNotfound){
			System.err.println("nao foi possivel criar o objeto");
		}catch(IOException ioexception){
			System.err.println("Erro de leitura do arquivo");
		}
	}
	
	public ArrayList<Resultado> retornaArquivoFases(){
		return todasAsFases;
	}
	
	public List<String> retornatimes(){
		return result.getTimes();
	}
	public List<String> retornaresultados(){
		return result.getResultados();
	}

       public String fase(){
    	   return result.getFase();
       }
	
       
       public void closefile(){
		try{
			if(inputtimes != null)
				inputtimes.close();
		}catch(IOException ioexception){
			System.err.println("Erro ao fechar o arquivo");
			System.exit(1);
		}
	}
}

