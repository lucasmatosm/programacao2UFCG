package projeto;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.WindowConstants;
import javax.swing.JSeparator;

import java.awt.Font;

import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.JComboBox;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.FileNotFoundException;
import java.awt.Toolkit;

public class MenuAdmin extends javax.swing.JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = -5480900469428568405L;
	private JPanel jpanelUsuarios;
	private JPanel jPanelJogos;
	private JPanel jPanelConfiguracoes;
	private JTabbedPane jTabbedPane1;
	private JButton btnSair;
	private JLabel lblTrocarLogin;
	private JLabel lblTrocarSenha;
	private JLabel lblNovaSenha;
	private JPasswordField passwordField;
	private JLabel lblNovoLogin;
	private JTextField textField;
	private JSeparator separator_1;
	private JLabel lblCadastrarUsuario;
	private JLabel lblNome;
	private JTextField textField_1;
	private JLabel lblLogin;
	private JTextField textField_2;
	private JLabel lblSenha;
	private JPasswordField passwordField_1;
	private JLabel lblEmail;
	private JTextField textField_3;
	private JLabel lblPergunta;
	private JComboBox<String> comboBox;
	private JLabel lblResposta;
	private JTextField textField_4;
	private JLabel lblExcluirUsuario;
	private JTextField textField_5;
	private JButton btnExcluir;
	private JButton btnMudar_1;
	private JButton btnMudar;
	private String Login;
	private JSeparator separator_2;
	private JLabel lblTimes;
	private JLabel lblTabela;
	private JButton btnAtualizarTabela;
	private JButton btnAtualizarTimes;
	private String escolhido;
	private boolean estado, possivel, possivel2 = false;
	private JTextField textField_6;
	private JTextField textField_7;
	private JPasswordField passwordField_2;
	private JComboBox comboBox_1;
	private JSeparator separator_3;
	private Administrador admin;
	protected String escolhido2;
	private JTextField horas1;
	private JTextField min1;
	private JTextField seg1;
	private JTextField horas2;
	private JTextField min2;
	private JTextField seg2;
	private String horaInicio = "0", horaTermino = "0";


	public static void main(String[] args) {
		MenuAdmin janela = new MenuAdmin();
		janela.setLocationRelativeTo(null);
		janela.setVisible(true);
	}

	public MenuAdmin() {
		super();
		setIconImage(Toolkit.getDefaultToolkit().getImage(MenuAdmin.class.getResource("/projeto/copa-Fifa.jpg")));
		setTitle("Menu - Administrador");
		desenhaJanela();
	}

	private void desenhaJanela() {
		try{
			setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			getContentPane().setLayout(null);
			setSize(497,374);
			setPreferredSize(getSize());
			{
				jTabbedPane1 = new JTabbedPane();
				getContentPane().add(jTabbedPane1);
				jTabbedPane1.setBounds(10, 11, 461, 282);
				{
					jpanelUsuarios = new JPanel();
					jTabbedPane1.addTab("Usuarios", null, jpanelUsuarios, null);
					jpanelUsuarios.setLayout(null);
					{
						separator_1 = new JSeparator();
						separator_1.setBounds(0, 155, 456, 2);
						jpanelUsuarios.add(separator_1);
					}
					{
						lblCadastrarUsuario = new JLabel("Cadastrar administrador");
						lblCadastrarUsuario.setFont(new Font("Tahoma", Font.BOLD, 13));
						lblCadastrarUsuario.setBounds(146, 2, 207, 14);
						jpanelUsuarios.add(lblCadastrarUsuario);
					}
					{
						lblNome = new JLabel("Nome:");
						lblNome.setBounds(10, 27, 46, 14);
						jpanelUsuarios.add(lblNome);
					}
					{
						textField_1 = new JTextField();
						textField_1.setBounds(50, 24, 86, 20);
						jpanelUsuarios.add(textField_1);
						textField_1.setColumns(10);
					}
					{
						lblLogin = new JLabel("Login:");
						lblLogin.setBounds(10, 65, 46, 14);
						jpanelUsuarios.add(lblLogin);
					}
					{
						textField_2 = new JTextField();
						textField_2.setBounds(50, 62, 138, 20);
						jpanelUsuarios.add(textField_2);
						textField_2.setColumns(10);
					}
					{
						lblSenha = new JLabel("Senha:");
						lblSenha.setBounds(198, 65, 46, 14);
						jpanelUsuarios.add(lblSenha);
					}
					{
						passwordField_1 = new JPasswordField();
						passwordField_1.setBounds(260, 62, 186, 20);
						jpanelUsuarios.add(passwordField_1);
					}
					{
						lblEmail = new JLabel("Email:");
						lblEmail.setBounds(10, 99, 46, 14);
						jpanelUsuarios.add(lblEmail);
					}
					{
						textField_3 = new JTextField();
						textField_3.setBounds(50, 93, 138, 20);
						jpanelUsuarios.add(textField_3);
						textField_3.setColumns(10);
					}
					{
						lblPergunta = new JLabel("Pergunta:");
						lblPergunta.setBounds(146, 27, 69, 14);
						jpanelUsuarios.add(lblPergunta);
					}
					{
						comboBox = new JComboBox<String>();
						comboBox.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent e) {
								JComboBox cb = (JComboBox)e.getSource();
								escolhido2 = (String)cb.getSelectedItem();
							}
						});
						comboBox.addItem("Qual foi nome do seu primeiro cachorro?");
						comboBox.addItem("Qual o nome de solteira da sua m�e?");
						comboBox.addItem("Onde seu pai nasceu?");
						comboBox.addItem("Qual a primeira escola que voc� estudou?");

						comboBox.setBounds(204, 24, 242, 20);
						jpanelUsuarios.add(comboBox);
					}
					{
						lblResposta = new JLabel("Resposta:");
						lblResposta.setBounds(198, 99, 69, 14);
						jpanelUsuarios.add(lblResposta);
					}
					{
						textField_4 = new JTextField();
						textField_4.setBounds(260, 93, 186, 20);
						jpanelUsuarios.add(textField_4);
						textField_4.setColumns(10);
					}
					{
						lblExcluirUsuario = new JLabel("Excluir usuario");
						lblExcluirUsuario.setFont(new Font("Tahoma", Font.BOLD, 13));
						lblExcluirUsuario.setBounds(175, 168, 109, 14);
						jpanelUsuarios.add(lblExcluirUsuario);
					}

					JButton btnCadastrar = new JButton("Cadastrar");
					btnCadastrar.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {

							String n = textField_1.getText();
							String l = textField_3.getText();
							String u = textField_2.getText();
							String s = passwordField_1.getText();
							String r = textField_4.getText().toLowerCase();
							if(n.equals("") || l.equals("") || s.equals("") || u.equals("") || r.equals("")){
								JOptionPane.showMessageDialog(null,"Campos n�o preenchidos");
							}
							else if(s.length() < 6 || s.length() > 8){
								JOptionPane.showMessageDialog(null,"As senhas devem conter entre 6 e 8 caracteres");	
							}

							else{
								Output g = new Output();
								g.openfile();
								g.lerarquivo();
								g.closefile();

								for (int i = 0; i < g.usalista().size(); i++) {
									if (u.equals(g.usalista().get(i).getLogin())){
										JOptionPane.showMessageDialog(null,"Nome de usuario existente");
										textField_2.setText(null);
										possivel = false;
										break;
									}
									else{
										possivel = true;
									}
								}
								if (possivel == true){
									Input f = new Input();
									String a = passwordField_1.getText();

									Administrador user = new Administrador(n,l,u,a, escolhido2, r, "", "");
									g.usalista().add(user);
									try {
										f.openfile();
									} catch (FileNotFoundException e1) {
										e1.printStackTrace();
									}
									for (int i = 0; i < g.usalista().size(); i++) {
										f.Gravaarquivo(g.usalista().get(i));
									}
									f.closefile();
									JOptionPane.showMessageDialog(null,"Administrador cadastrado!");
									textField_1.setText(null);
									textField_3.setText(null);
									textField_2.setText(null);
									passwordField_1.setText(null);

									textField_4.setText(null);

								}


							}	


						}
					});
					btnCadastrar.setBounds(175, 124, 99, 23);
					jpanelUsuarios.add(btnCadastrar);

					JLabel lblLogin_1 = new JLabel("Login:");
					lblLogin_1.setBounds(121, 196, 46, 14);
					jpanelUsuarios.add(lblLogin_1);

					textField_5 = new JTextField();
					textField_5.setBounds(164, 193, 120, 20);
					jpanelUsuarios.add(textField_5);
					textField_5.setColumns(10);
					{
						btnExcluir = new JButton("Excluir");
						btnExcluir.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent e) {
								if(textField_5.getText().equals("")){
									JOptionPane.showMessageDialog(null,"Campo n�o preenchido");
								}
								else{
									Output login = new Output();
									login.openfile();
									login.lerarquivo();
									for (int i = 0; i < login.usalista().size(); i++) {
										if (textField_5.getText().equals(login.usalista().get(i).getLogin())){
											login.usalista().remove(login.usalista().get(i));		
											possivel2 = true;
										}	

									}
									if(possivel2 == true){
										login.closefile();
										Input remove = new Input();
										try {
											remove.openfile();
										} catch (FileNotFoundException h) {

											h.printStackTrace();
										}
										for (int i = 0; i < login.usalista().size(); i++) {
											remove.Gravaarquivo(login.usalista().get(i));
										}
										remove.closefile();
										JOptionPane.showMessageDialog(null,"Usuario excluido com sucesso");	
										textField_5.setText(null);
									}

									else {
										JOptionPane.showMessageDialog(null,"Usuario n�o encontrado");	
										textField_5.setText(null);
									}
								}

							}
						});
						btnExcluir.setBounds(178, 220, 89, 23);
						jpanelUsuarios.add(btnExcluir);
					}
				}
				{		
					jPanelJogos = new JPanel();
					jTabbedPane1.addTab("Jogos", null, jPanelJogos, null);
					jPanelJogos.setLayout(null);
					{
						separator_2 = new JSeparator();
						separator_2.setBounds(0, 143, 456, 2);
						jPanelJogos.add(separator_2);
					}
					{
						lblTimes = new JLabel("Times");
						lblTimes.setFont(new Font("Tahoma", Font.BOLD, 13));
						lblTimes.setBounds(200, 0, 51, 25);
						jPanelJogos.add(lblTimes);
					}
					{
						lblTabela = new JLabel("Resultados");
						lblTabela.setFont(new Font("Tahoma", Font.BOLD, 13));
						lblTabela.setBounds(178, 156, 90, 14);
						jPanelJogos.add(lblTabela);
					}
					{
						btnAtualizarTabela = new JButton("Atualizar jogos");
						btnAtualizarTabela.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent e) {
								try{
									Output procuradmin = new Output();
									procuradmin.openfile();
									procuradmin.lerarquivo();

									if (escolhido.equals("1� Fase - 1� Rodada")){


										for (Usuario user : procuradmin.usalista()) {
											if (user instanceof Administrador){
												if(Administrador.timesJogos1fase.toString().equals("[]")){
													admin = (Administrador) user;
													admin.iniciaJogos();
												}else{
													if (user.getLogin().equals(getLogin())){
														
														admin = (Administrador) user;
														admin.iniciaJogos();
														Times1Fase lista = new Times1Fase(false , 1 , admin);
														lista.setVisible(true);
														break;	
													}
												}		
											}

										}

										procuradmin.closefile();

									}else if((escolhido.equals("1� Fase - 2� Rodada"))){
										for (Usuario user : procuradmin.usalista()) {
											if (user.getLogin().equals(getLogin())){
												Administrador admin = (Administrador) user;
												Times1Fase lista = new Times1Fase(false ,2,admin);
												lista.setVisible(true);
											}
										}
									}else if ((escolhido.equals("1� Fase - 3� Rodada"))){
										for (Usuario user : procuradmin.usalista()) {
											if (user.getLogin().equals(getLogin())){
												Administrador admin = (Administrador) user;
												Times1Fase lista = new Times1Fase(false , 3,admin);
												lista.setVisible(true);
											}
										}
									}else if((escolhido.equals("Oitavas de final"))){
										for (Usuario user : procuradmin.usalista()) {
											if (user.getLogin().equals(getLogin())){
												Administrador admin = (Administrador) user;
												Times8Final lista = new Times8Final(false, admin);
												lista.setVisible(true);
											}
										}
									}else if((escolhido.equals("Quartas de final"))){
										for (Usuario user : procuradmin.usalista()) {
											if (user.getLogin().equals(getLogin())){
												Administrador admin = (Administrador) user;
												Times4Final lista = new Times4Final(false, admin);
												lista.setVisible(true);
											}
										}
									}else if((escolhido.equals("Semifinal"))){
										for (Usuario user : procuradmin.usalista()) {
											if (user.getLogin().equals(getLogin())){
												Administrador admin = (Administrador) user;
												TimesSemiFinal lista = new TimesSemiFinal(false, admin);
												lista.setVisible(true);
											}
										}
									}else{
										for (Usuario user : procuradmin.usalista()) {
											if (user.getLogin().equals(getLogin())){
												Administrador admin = (Administrador) user;
												TimesFinal lista = new TimesFinal(false, admin);
												lista.setVisible(true);
											}
										}	
									}

								}catch(Exception e1){
									JOptionPane.showMessageDialog(null, "Esta fase ainda n�o est� acontecendo", "Mensagem de erro", JOptionPane.ERROR_MESSAGE);

								}
							}

						});


						btnAtualizarTabela.setBounds(160, 220, 122, 23);
						jPanelJogos.add(btnAtualizarTabela);
					}
					{
						btnAtualizarTimes = new JButton("Atualizar times");
						btnAtualizarTimes.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent e) {
								try{
									Output procuradmin = new Output();
									procuradmin.openfile();
									procuradmin.lerarquivo();

									if (escolhido.equals("1� Fase - 1� Rodada")){


										JOptionPane.showMessageDialog(null, "Voc� n�o pode mudar a primeira rodada de times j� pre-definidas", "Mensagem de erro", JOptionPane.ERROR_MESSAGE);
										procuradmin.closefile();

									}else if((escolhido.equals("1� Fase - 2� Rodada"))){
										AtualizaTimes1Fase a = new AtualizaTimes1Fase(2);
										a.setVisible(true);

									}else if ((escolhido.equals("1� Fase - 3� Rodada"))){
										AtualizaTimes1Fase a = new AtualizaTimes1Fase(3);
										a.setVisible(true);

									}else if((escolhido.equals("Oitavas de final"))){
										AtualizaTimes8Final a = new AtualizaTimes8Final();
										a.setVisible(true);

									}else if((escolhido.equals("Quartas de final"))){
										AtualizaTimes4Final a = new AtualizaTimes4Final();
										a.setVisible(true);

									}else if((escolhido.equals("Semifinal"))){
										AtualizaTimesSemiFinal a = new AtualizaTimesSemiFinal();
										a.setVisible(true);

									}else{
										AtualizaTimesFinal a = new AtualizaTimesFinal();
										a.setVisible(true);	
									}

								}catch(Exception e1){
									JOptionPane.showMessageDialog(null, "Esta fase ainda n�o est�o acontecendo", "Mensagem de erro", JOptionPane.ERROR_MESSAGE);

								}
							}


						});
						btnAtualizarTimes.setBounds(160, 68, 122, 23);
						jPanelJogos.add(btnAtualizarTimes);
					}
					{
						JComboBox comboBox = new JComboBox();
						comboBox.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent e) {
								JComboBox cb = (JComboBox)e.getSource();
								escolhido = (String)cb.getSelectedItem();
							}
						});
						comboBox.addItem("1� Fase - 1� Rodada");
						comboBox.addItem("1� Fase - 2� Rodada");
						comboBox.addItem("1� Fase - 3� Rodada");
						comboBox.addItem("Oitavas de final");
						comboBox.addItem("Quartas de final");
						comboBox.addItem("Semifinal");
						comboBox.addItem("Final");

						comboBox.setBounds(148, 110, 145, 25);
						jPanelJogos.add(comboBox);			
					}
					{
						separator_3 = new JSeparator();
						separator_3.setBounds(0, 102, 456, 2);
						jPanelJogos.add(separator_3);
					}
				}
				{
					jPanelConfiguracoes = new JPanel();
					jTabbedPane1.addTab("Configuracoes", null, jPanelConfiguracoes, null);
					jPanelConfiguracoes.setLayout(null);

					JSeparator separator = new JSeparator();
					separator.setBounds(0, 120, 456, 2);
					jPanelConfiguracoes.add(separator);
					{
						lblTrocarLogin = new JLabel("Mudar login");
						lblTrocarLogin.setFont(new Font("Tahoma", Font.BOLD, 13));
						lblTrocarLogin.setBounds(180, 0, 92, 16);
						jPanelConfiguracoes.add(lblTrocarLogin);
					}
					{
						lblTrocarSenha = new JLabel("Mudar senha");
						lblTrocarSenha.setFont(new Font("Tahoma", Font.BOLD, 13));
						lblTrocarSenha.setBounds(180, 133, 125, 14);
						jPanelConfiguracoes.add(lblTrocarSenha);
					}
					{
						lblNovaSenha = new JLabel("Repetir senha:");
						lblNovaSenha.setBounds(72, 187, 92, 14);
						jPanelConfiguracoes.add(lblNovaSenha);
					}
					{
						passwordField = new JPasswordField();
						passwordField.setBounds(161, 187, 125, 20);
						jPanelConfiguracoes.add(passwordField);
					}
					{
						lblNovoLogin = new JLabel("Novo login:");
						lblNovoLogin.setBounds(72, 55, 64, 14);
						jPanelConfiguracoes.add(lblNovoLogin);
					}
					{
						textField = new JTextField();
						textField.setBounds(161, 52, 125, 20);
						jPanelConfiguracoes.add(textField);
						textField.setColumns(10);
					}
					{
						btnMudar_1 = new JButton("Mudar");
						btnMudar_1.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent e) {

								Output login = new Output();
								login.openfile();
								login.lerarquivo();
								String n = textField_7.getText();
								String g = passwordField.getText();
								for (int i = 0; i < login.usalista().size(); i++) {
									if (n.equals(login.usalista().get(i).getLogin())){
										login.usalista().get(i).setSenha(g);		
									}	
								}
								login.closefile();
								Input remove = new Input();
								try {
									remove.openfile();
								} catch (FileNotFoundException f) {
									f.printStackTrace();
								}
								for (int i = 0; i < login.usalista().size(); i++) {
									remove.Gravaarquivo(login.usalista().get(i));
								}
								remove.closefile();
								JOptionPane.showMessageDialog(null,"Senha alterada com sucesso");

							}
						});
						btnMudar_1.setBounds(180, 220, 83, 23);
						jPanelConfiguracoes.add(btnMudar_1);
					}
					{
						btnMudar = new JButton("Mudar");
						btnMudar.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent e) {

								Output login = new Output();
								login.openfile();
								login.lerarquivo();
								String n = textField.getText();
								String g = getLogin();
								if(n.trim().equals("") || g.trim().equals(""))
									JOptionPane.showMessageDialog(null,"login nao pode ser alterado");
								for (int i = 0; i < login.usalista().size(); i++) {
									if (g.equals(login.usalista().get(i).getLogin())){
										login.usalista().get(i).setLogin(n);
										estado = true;
									}	
								}
								if(estado = true){
									login.closefile();
									Input remove = new Input();
									try {
										remove.openfile();
									} catch (FileNotFoundException f) {
										f.printStackTrace();
									}
									for (int i = 0; i < login.usalista().size(); i++) {
										remove.Gravaarquivo(login.usalista().get(i));
									}
									remove.closefile();
									JOptionPane.showMessageDialog(null,"Login alterado com sucesso");	
									textField.setText(null);
									textField_7.setText(null);

								}
								else{
									JOptionPane.showMessageDialog(null,"Login incorreto");	
									textField.setText(null);
									textField_7.setText(null);
								}	


							}
						});
						btnMudar.setBounds(180, 86, 83, 23);
						jPanelConfiguracoes.add(btnMudar);
					}

					JLabel label = new JLabel("Nova senha:");
					label.setBounds(72, 158, 79, 14);
					jPanelConfiguracoes.add(label);

					passwordField_2 = new JPasswordField();
					passwordField_2.setBounds(161, 158, 125, 20);
					jPanelConfiguracoes.add(passwordField_2);




				}

				JPanel jPanelHorario = new JPanel();
				jTabbedPane1.addTab("Horario", null, jPanelHorario, null);
				jPanelHorario.setLayout(null);

				JLabel lblDigiteOnicio = new JLabel("Digite o in�cio e o t�rmino do periodo de atualiza��o dos resultados.");
				lblDigiteOnicio.setBounds(33, 25, 387, 14);
				jPanelHorario.add(lblDigiteOnicio);

				JLabel lblnicio = new JLabel("In�cio:");
				lblnicio.setBounds(141, 72, 46, 14);
				jPanelHorario.add(lblnicio);

				JLabel lblTrmino = new JLabel("T�rmino:");
				lblTrmino.setBounds(124, 97, 66, 14);
				jPanelHorario.add(lblTrmino);

				horas1 = new JTextField();
				horas1.setBounds(180, 69, 22, 20);
				jPanelHorario.add(horas1);
				horas1.setColumns(10);

				min1 = new JTextField();
				min1.setBounds(212, 69, 22, 20);
				jPanelHorario.add(min1);
				min1.setColumns(10);

				seg1 = new JTextField();
				seg1.setBounds(244, 69, 22, 20);
				jPanelHorario.add(seg1);
				seg1.setColumns(10);

				horas2 = new JTextField();
				horas2.setBounds(180, 94, 22, 20);
				jPanelHorario.add(horas2);
				horas2.setColumns(10);

				min2 = new JTextField();
				min2.setBounds(212, 94, 22, 20);
				jPanelHorario.add(min2);
				min2.setColumns(10);

				seg2 = new JTextField();
				seg2.setBounds(244, 94, 22, 20);
				jPanelHorario.add(seg2);
				seg2.setColumns(10);

				JLabel label = new JLabel(":         :");
				label.setBounds(205, 72, 46, 14);
				jPanelHorario.add(label);

				JLabel label_1 = new JLabel(":         :");
				label_1.setBounds(205, 97, 46, 14);
				jPanelHorario.add(label_1);

				JButton btnOk = new JButton("OK");
				btnOk.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						if(horas1.getText().trim().equals("") || horas2.getText().trim().equals("") || min1.getText().trim().equals("") || min2.getText().trim().equals("")
								|| seg1.getText().trim().equals("") || seg2.getText().trim().equals("")){
							JOptionPane.showMessageDialog(null, "Preencha os campos corretamente!");

						}else if(Integer.parseInt(horas1.getText()) < 0 || Integer.parseInt(horas1.getText()) > 23
								|| Integer.parseInt(horas2.getText()) < 0 || Integer.parseInt(horas2.getText()) > 23
								|| Integer.parseInt(min1.getText()) < 0 || Integer.parseInt(min1.getText()) > 59
								|| Integer.parseInt(min2.getText()) < 0 || Integer.parseInt(min2.getText()) > 59
								|| Integer.parseInt(seg1.getText()) < 0 || Integer.parseInt(seg1.getText()) > 59
								|| Integer.parseInt(seg2.getText()) < 0 || Integer.parseInt(seg2.getText()) > 59) {

							JOptionPane.showMessageDialog(null, "Hora(s) invalida(s)");


						}else{
							horaInicio = horas1.getText() + ":" + min1.getText() + ":" + seg1.getText();
							horaTermino = horas2.getText() + ":" + min2.getText() + ":" + seg2.getText();

							Output f = new Output();
							Input g = new Input();
							f.openfile();
							f.lerarquivo();
							f.closefile();

							try {
								g.openfile();
							} catch (FileNotFoundException e) {
								e.printStackTrace();
							}

							for (Usuario user2: f.usalista()) {
								if(user2 instanceof Administrador) {
									Administrador admin2 = (Administrador) user2;
									admin2.setHoraInicio(horaInicio);
									admin2.setHoraTermino(horaTermino);
									g.Gravaarquivo(admin2);
								}
								else{
									g.Gravaarquivo(user2);
								}

							}

							g.closefile();

							JOptionPane.showMessageDialog(null,"Atualizado com sucesso");
							horas1.setText("");
							min1.setText("");
							seg1.setText("");
							horas2.setText("");
							min2.setText("");
							seg2.setText("");


						}
					}
				});
				btnOk.setBounds(177, 132, 89, 23);
				jPanelHorario.add(btnOk);
			}
			{
				btnSair = new JButton("Sair");
				btnSair.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						TelaLogin login = new TelaLogin();
						login.setVisible(true);
						setVisible(false);
					}
				});
				btnSair.setBounds(189, 304, 89, 23);
				getContentPane().add(btnSair);
			}
			pack();
		}catch(Exception e) {
			e.printStackTrace();
		}

		this.setResizable(false);
	}

	public String getLogin() {
		return Login;
	}

	public void setLogin(String login2) {
		Login = login2;
	}
}
