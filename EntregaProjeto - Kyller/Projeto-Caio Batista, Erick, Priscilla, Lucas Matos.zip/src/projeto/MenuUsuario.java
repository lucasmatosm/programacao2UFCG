package projeto;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.util.*;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JSeparator;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.JComboBox;

import java.awt.Color;

import javax.swing.SwingConstants;
import javax.swing.JList;
import javax.swing.JTextPane;
import javax.swing.event.AncestorListener;
import javax.swing.event.AncestorEvent;

public class MenuUsuario extends javax.swing.JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = -9188022690639198073L;
	private JPanel jpanelApostas;
	private JPanel jPanelRanking;
	private JPanel jPanelConfiguracoes;
	private JTabbedPane jTabbedPane1;
	private JButton btnSair;
	private String Login;
	private JSeparator separator;
	private JLabel lblMudarLogin;
	private JLabel lblMudarSenha;
	private JPasswordField passwordField;
	private JTextField textField, textField1, textField_6, textField_7, textField_5 ;
	private JButton btnMudar, btnMudar_1;
	private JLabel lblNovaSenha, lblTrocarLogin, lblTrocarSenha, lblNovoLogin;
	private JLabel login;
	private JPasswordField passwordField_1;
	private boolean estado;
	private JLabel label;
	private JPasswordField passwordField_2;
	private String escolhido;
	private Administrador admin;
	private Usuario usuario;
	private JList list_1;

	public static void main(String[] args) {
		MenuUsuario janela = new MenuUsuario();
		janela.setLocationRelativeTo(null);
		janela.setVisible(true);
	}

	public MenuUsuario() {
		super();
		setTitle("Menu - Usuario");
		desenhaJanela();
		new Clock();
	}

	private void desenhaJanela() {
		try{
			setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			getContentPane().setLayout(null);
			setSize(503,515);
			setPreferredSize(getSize());
			{
				jTabbedPane1 = new JTabbedPane();
				getContentPane().add(jTabbedPane1);
				jTabbedPane1.setBounds(10, 11, 467, 420);
				{
					jpanelApostas = new JPanel();
					jTabbedPane1.addTab("Apostas", null, jpanelApostas, null);
					jpanelApostas.setLayout(null);

					JSeparator separator_1 = new JSeparator();
					separator_1.setBounds(0, 186, 462, 2);
					jpanelApostas.add(separator_1);

					JButton btnApostar = new JButton("Apostar");
					btnApostar.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent arg0) {
							Output f = new Output();
							f.openfile();
							f.lerarquivo();
							Administrador admin = null;
							ArrayList<ArrayList<String>> apostas = new ArrayList<ArrayList<String>>();
							for (Usuario user : f.usalista()) {
								if (!(user instanceof Administrador)){
									if (user.getLogin().equals(getLogin())){
										usuario = (Usuario) user;
										apostas = usuario.getApostas();
										break;
									}
								}
							}

							if(usuario.isSituacao()){
								try{
									Output procuradmin = new Output();
									procuradmin.openfile();
									procuradmin.lerarquivo();


									if (escolhido.equals("1� Fase - 1� Rodada") ){
										
										if (!(apostas.get(0).isEmpty())){
											
											throw new Exception("");
										}


										for (Usuario user : procuradmin.usalista()) {

											if (user instanceof Administrador){

												if(Administrador.timesJogos1fase.toString().equals("[]")){

													admin = (Administrador) user;
													admin.iniciaJogos();
													break;
												}
												break;
											}
										}
										
										for (Usuario user1 : procuradmin.usalista()) {

											if (user1.getLogin().equals(getLogin())){

												Times1Fase lista = new Times1Fase(false, 1, user1);
												lista.setVisible(true);
												break;	
											}
										}




									}else if((escolhido.equals("1� Fase - 2� Rodada"))){
										if (!(apostas.get(1).isEmpty())){
											
											throw new Exception("");
										}

										for (Usuario user : procuradmin.usalista()) {
											if (user.getLogin().equals(getLogin())){
												Times1Fase lista = new Times1Fase(false, 2,user);
												lista.setVisible(true);
											}
										}
									}else if ((escolhido.equals("1� Fase - 3� Rodada"))){
										if (!(apostas.get(2).isEmpty())){
											throw new Exception("");
										}

										for (Usuario user : procuradmin.usalista()) {
											if (user.getLogin().equals(getLogin())){
												Times1Fase lista = new Times1Fase(false, 3,user);
												lista.setVisible(true);
											}
										}
									}else if((escolhido.equals("Oitavas de final"))){
										if (!(apostas.get(3).isEmpty())){
											throw new Exception("");
										}

										for (Usuario user : procuradmin.usalista()) {
											if (user.getLogin().equals(getLogin())){
												Times8Final lista = new Times8Final(false, user);
												lista.setVisible(true);
											}
										}
									}else if((escolhido.equals("Quartas de final"))){
										if (!(apostas.get(4).isEmpty())){
											throw new Exception("");
										}
										
										for (Usuario user : procuradmin.usalista()) {
											if (user.getLogin().equals(getLogin())){
												Times4Final lista = new Times4Final(false , user);
												lista.setVisible(true);
											}
										}
									}else if((escolhido.equals("Semifinal"))){
										if (!(apostas.get(5).isEmpty())){
											throw new Exception("");
										}

										for (Usuario user : procuradmin.usalista()) {
											if (user.getLogin().equals(getLogin())){
												TimesSemiFinal lista = new TimesSemiFinal(false, user);
												lista.setVisible(true);
											}
										}
									}else{
										if (!(apostas.get(6).isEmpty())){
											throw new Exception("");
										}

										for (Usuario user : procuradmin.usalista()) {
											if (user.getLogin().equals(getLogin())){
												TimesFinal lista = new TimesFinal(false, user);
												lista.setVisible(true);
											}
										}	
									}
									procuradmin.closefile();
								}catch(Exception e1){
									JOptionPane.showMessageDialog(null, "Esta fase ainda n�o est�o acontecendo ou voc� j� fez a aposta \n   Caso voc� j� tenha apostado aperte em 'modificar aposta'", "Mensagem de erro", JOptionPane.ERROR_MESSAGE);

								}

							}else{
								JOptionPane.showMessageDialog(null, "Voc� n�o pode apostar");
							}

						}

					});
					btnApostar.setBounds(187, 84, 89, 23);
					jpanelApostas.add(btnApostar);

					JButton btnModificiarAposta = new JButton("Modificar aposta");
					btnModificiarAposta.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {Output f = new Output();
						f.openfile();
						f.lerarquivo();
						Administrador admin = null;
						for (Usuario user : f.usalista()) {
							if (!(user instanceof Administrador)){
								if (user.getLogin().equals(getLogin())){
									usuario = (Usuario) user;
									break;
								}
							}
						}

						if(usuario.isSituacao()){
							try{
								Output procuradmin = new Output();
								procuradmin.openfile();
								procuradmin.lerarquivo();
								
								Outputtimes procuraResultados = new Outputtimes();
								procuraResultados.openfile();
								procuraResultados.lerarquivo();
								
								ArrayList<String> r1 = new ArrayList<String>();
								ArrayList<String> r2 = new ArrayList<String>();
								ArrayList<String> r3 = new ArrayList<String>();
								ArrayList<String> r4 = new ArrayList<String>();
								ArrayList<String> r5 = new ArrayList<String>();
								ArrayList<String> r6 = new ArrayList<String>();
								ArrayList<String> r7 = new ArrayList<String>();
								
								for (Resultado rodadas : procuraResultados.retornaArquivoFases()) {
									if (rodadas.getFase().equals("1 Fase - 1 Rodada"))
										r1 = (ArrayList<String>) rodadas.getResultados();
									else if (rodadas.getFase().equals("1 Fase - 2 Rodada"))
										r2 = (ArrayList<String>) rodadas.getResultados();
									else if (rodadas.getFase().equals("1 Fase - 3 Rodada"))
										r3 = (ArrayList<String>) rodadas.getResultados();
									else if (rodadas.getFase().equals("Oitavas de final"))
										r4 = (ArrayList<String>) rodadas.getResultados();
									else if (rodadas.getFase().equals("Quartas de final"))
										r5 = (ArrayList<String>) rodadas.getResultados();
									else if (rodadas.getFase().equals("Semifinal"))
										r6 = (ArrayList<String>) rodadas.getResultados();
									else if (rodadas.getFase().equals("Final"))
										r7 = (ArrayList<String>) rodadas.getResultados();
								}
								
								procuraResultados.closefile();
								
								if (escolhido.equals("1� Fase - 1� Rodada")){
									
									if (!(r1.isEmpty())){
										throw new Exception("");
									}


									for (Usuario user : procuradmin.usalista()) {

										if (user instanceof Administrador){

											if(Administrador.timesJogos1fase.toString().equals("[]")){

												admin = (Administrador) user;
												admin.iniciaJogos();
												break;
											}
											break;
										}
									}
									
									for (Usuario user1 : procuradmin.usalista()) {

										if (user1.getLogin().equals(getLogin())){

											Times1Fase lista = new Times1Fase(true,1, user1);
											lista.setVisible(true);
											break;	
										}
									}




								}else if((escolhido.equals("1� Fase - 2� Rodada"))){
									if (!(r2.isEmpty())){
										throw new Exception("");
									}

									
									for (Usuario user : procuradmin.usalista()) {
										if (user.getLogin().equals(getLogin())){
											Times1Fase lista = new Times1Fase(true ,2,user);
											lista.setVisible(true);
										}
									}
								}else if ((escolhido.equals("1� Fase - 3� Rodada"))){
									if (!(r3.isEmpty())){
										throw new Exception("");
									}

									
									
									for (Usuario user : procuradmin.usalista()) {
										if (user.getLogin().equals(getLogin())){
											Times1Fase lista = new Times1Fase(true, 3,user);
											lista.setVisible(true);
										}
									}
								}else if((escolhido.equals("Oitavas de final"))){
									if (!(r4.isEmpty())){
										throw new Exception("");
									}

									
									for (Usuario user : procuradmin.usalista()) {
										if (user.getLogin().equals(getLogin())){
											Times8Final lista = new Times8Final(true,user);
											lista.setVisible(true);
										}
									}
								}else if((escolhido.equals("Quartas de final"))){
									if (!(r5.isEmpty())){
										throw new Exception("");
									}

									
									
									for (Usuario user : procuradmin.usalista()) {
										if (user.getLogin().equals(getLogin())){
											Times4Final lista = new Times4Final(true,user);
											lista.setVisible(true);
										}
									}
								}else if((escolhido.equals("Semifinal"))){
									if (!(r6.isEmpty())){
										throw new Exception("");
									}

									
									
									for (Usuario user : procuradmin.usalista()) {
										if (user.getLogin().equals(getLogin())){
											TimesSemiFinal lista = new TimesSemiFinal(true, user);
											lista.setVisible(true);
										}
									}
								}else{
									if (!(r7.isEmpty())){
										throw new Exception("");
									}

									
									for (Usuario user : procuradmin.usalista()) {
										if (user.getLogin().equals(getLogin())){
											TimesFinal lista = new TimesFinal(true, user);
											lista.setVisible(true);
										}
									}	
								}
								procuradmin.closefile();
							}catch(Exception e1){
								JOptionPane.showMessageDialog(null, "Esta fase ainda n�o est�o acontecendo ou os resultados j� foram atualizado", "Mensagem de erro", JOptionPane.ERROR_MESSAGE);

							}

						}else{
							JOptionPane.showMessageDialog(null, "Voc� n�o pode apostar");
						}

					}

				});
					btnModificiarAposta.setBounds(164, 300, 134, 23);
					jpanelApostas.add(btnModificiarAposta);

					JSeparator separator_2 = new JSeparator();
					separator_2.setBounds(0, 222, 462, 2);
					jpanelApostas.add(separator_2);

					JComboBox comboBox = new JComboBox();
					comboBox.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							JComboBox cb = (JComboBox)e.getSource();
							escolhido = (String)cb.getSelectedItem();
						}
					});
					comboBox.addItem("1� Fase - 1� Rodada");
					comboBox.addItem("1� Fase - 2� Rodada");
					comboBox.addItem("1� Fase - 3� Rodada");
					comboBox.addItem("Oitavas de final");
					comboBox.addItem("Quartas de final");
					comboBox.addItem("Semifinal");
					comboBox.addItem("Final");

					comboBox.setBounds(157, 194, 151, 20);
					jpanelApostas.add(comboBox);
				}
				{		
					jPanelRanking = new JPanel();
					jTabbedPane1.addTab("Ranking", null, jPanelRanking, null);
					jPanelRanking.setLayout(null);
					DefaultListModel model = new DefaultListModel();
					{
						list_1 = new JList();
						list_1.setBounds(50, 64, 384, 286);
						DefaultListModel model2 = new DefaultListModel();  
						list_1.setModel(model2);

						for (String s : rankingGeral()) {
							model2.addElement(s); 
						}
						jPanelRanking.add(list_1);
					}

					JLabel lblRankingGeral = new JLabel("Ranking Geral");
					lblRankingGeral.setBounds(175, 11, 102, 14);
					jPanelRanking.add(lblRankingGeral);
				}
				{
					jPanelConfiguracoes = new JPanel();
					jTabbedPane1.addTab("Configuracoes", null, jPanelConfiguracoes, null);
					jPanelConfiguracoes.setLayout(null);

					JSeparator separator = new JSeparator();
					separator.setBounds(0, 206, 462, 2);
					jPanelConfiguracoes.add(separator);
					{
						lblTrocarLogin = new JLabel("Mudar login");
						lblTrocarLogin.setFont(new Font("Tahoma", Font.BOLD, 13));
						lblTrocarLogin.setBounds(180, 0, 92, 16);
						jPanelConfiguracoes.add(lblTrocarLogin);
					}
					{
						lblTrocarSenha = new JLabel("Mudar senha");
						lblTrocarSenha.setFont(new Font("Tahoma", Font.BOLD, 13));
						lblTrocarSenha.setBounds(180, 209, 125, 14);
						jPanelConfiguracoes.add(lblTrocarSenha);
					}
					{
						lblNovaSenha = new JLabel("Nova senha:");
						lblNovaSenha.setBounds(72, 265, 79, 14);
						jPanelConfiguracoes.add(lblNovaSenha);
					}
					{
						passwordField = new JPasswordField();
						passwordField.setBounds(161, 262, 125, 20);
						jPanelConfiguracoes.add(passwordField);
					}
					{
						lblNovoLogin = new JLabel("Novo login:");
						lblNovoLogin.setBounds(72, 55, 64, 14);
						jPanelConfiguracoes.add(lblNovoLogin);
					}
					{
						textField = new JTextField();
						textField.setBounds(161, 52, 125, 20);
						jPanelConfiguracoes.add(textField);
						textField.setColumns(10);
					}
					{
						btnMudar_1 = new JButton("Mudar");
						btnMudar_1.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent e) {

								Output login = new Output();
								login.openfile();
								login.lerarquivo();
								String n = getLogin();
								String g = passwordField.getText();
								String l = passwordField_2.getText();
								if (!(l.equals(g))){
									JOptionPane.showMessageDialog(null,"As senhas devem ser iguais");
								}else if (l.trim().equals("") || g.trim().equals("")){
									JOptionPane.showMessageDialog(null,"Senhas invalidas");
								}
								else{
									for (int i = 0; i < login.usalista().size(); i++) {
										if (n.equals(login.usalista().get(i).getLogin())){
											login.usalista().get(i).setSenha(g);		
										}	
									}
									login.closefile();
									Input remove = new Input();
									try {
										remove.openfile();
									} catch (FileNotFoundException f) {
										f.printStackTrace();
									}
									for (int i = 0; i < login.usalista().size(); i++) {
										remove.Gravaarquivo(login.usalista().get(i));
									}
									remove.closefile();
									JOptionPane.showMessageDialog(null,"Senha alterada com sucesso");	
								}	


							}
						});
						btnMudar_1.setBounds(190, 347, 83, 23);
						jPanelConfiguracoes.add(btnMudar_1);
					}
					{
						btnMudar = new JButton("Mudar");
						btnMudar.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent e) {

								Output login = new Output();
								login.openfile();
								login.lerarquivo();
								String n = textField.getText();
								String g = getLogin();
								if(n.trim().equals("") || g.trim().equals(""))
									JOptionPane.showMessageDialog(null,"login nao pode ser alterado");
								for (int i = 0; i < login.usalista().size(); i++) {
									if (g.equals(login.usalista().get(i).getLogin())){
										login.usalista().get(i).setLogin(n);
										estado = true;
									}	
								}
								if(estado = true){
									login.closefile();
									Input remove = new Input();
									try {
										remove.openfile();
									} catch (FileNotFoundException f) {
										f.printStackTrace();
									}
									for (int i = 0; i < login.usalista().size(); i++) {
										remove.Gravaarquivo(login.usalista().get(i));
									}
									remove.closefile();
									JOptionPane.showMessageDialog(null,"Login alterado com sucesso");	
									textField.setText(null);
									textField1.setText(null);

								}
								else{
									JOptionPane.showMessageDialog(null,"Login incorreto");	
									textField.setText(null);
									textField1.setText(null);
								}	


							}
						});
						btnMudar.setBounds(180, 153, 83, 23);
						jPanelConfiguracoes.add(btnMudar);
					}
					{
						label = new JLabel("Nova senha:");
						label.setBounds(72, 306, 79, 14);
						jPanelConfiguracoes.add(label);
					}
					{
						passwordField_2 = new JPasswordField();
						passwordField_2.setBounds(161, 303, 125, 20);
						jPanelConfiguracoes.add(passwordField_2);
					}

				}
			}
			{
				btnSair = new JButton("Sair");
				btnSair.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						TelaLogin login2 = new TelaLogin();
						login2.setVisible(true);
						MenuUsuario.this.setVisible(false);
					}
				});
				btnSair.setBounds(197, 453, 89, 23);
				getContentPane().add(btnSair);
			}
			pack();
		}catch(Exception e) {
			e.printStackTrace();
		}
		this.setResizable(false);
	}

	public String getLogin() {
		return Login;
	}

	public void setLogin(String login) {
		Login = login;
	}


	private List<String> rankingGeral(){
		List<Usuario> UserList = new ArrayList<Usuario>();
		List<String> Ranking = new ArrayList<String>();


		Output procurausuario = new Output();
		procurausuario.openfile();
		procurausuario.lerarquivo();

		for (Usuario user : procurausuario.usalista()){

			if (!(user instanceof Administrador)){
				if ((UserList.toString().equals("[]")) || (user.getPontos() > UserList.get(0).getPontos())){
					UserList.add(0,user);
				}else {
					for (int i = 0; i < UserList.size(); i++){
						if (user.getPontos() >= UserList.get(i).getPontos()){
							UserList.add(i, user);
							break;
						}else if(i == UserList.size()){
							UserList.add(user);
						}
					}

				}
			}
		}

		for (Usuario user1: UserList){
			Ranking.add(user1.getNome() + " - " + user1.getPontos());
		}

		procurausuario.closefile();

		return (ArrayList<String>) Ranking;

	}
	
	private String dados(int dado){
		Output g = new Output();
		g.openfile();
		g.lerarquivo();
		Usuario usr = null;
		
		
		for (Usuario u : g.usalista()) {
			if (u.getLogin().equals(getLogin())){
				usr = u;
			}
		}
		
		System.out.println(usr);
		
		switch (dado) {
		case 1:
			return usr.getNome();
		case 2:
			return usr.getLogin();
		case 3:
			return usr.getEmail();
		case 4:
			return usr.getSenha();
		case 5:
			return usr.getPergunta();
		case 6:
			return usr.getResposta();
		case 7:
			return Integer.toString(usr.getPontos());
		default:
			break;
		}
		
		g.closefile();
		return Login;
	}
}