
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class TelaDeLogin extends JFrame {

	public TelaDeLogin() { 
		JLabel login = new JLabel("Digite seu login");
		final JTextField campoLogin = new JTextField();
		JLabel senha = new JLabel("Digite sua senha");
		final JPasswordField campoSenha = new JPasswordField();
		JButton logar = new JButton("Logar");
		logar.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				String l = campoLogin.getText();
				String s = campoSenha.getText();
				if (l.equals("") && s.equals("")) { 
					JOptionPane.showMessageDialog(TelaDeLogin.this, "logado!");
				}
			}
		});
		JPanel container = new JPanel();
		container.add(login);
		container.add(campoLogin);
		container.add(senha);
		container.add(campoSenha);
		container.add(logar);
		container.setLayout(new BoxLayout(container, BoxLayout.PAGE_AXIS));
		this.add(container);
		this.pack();
	}
	
	public static void main(String[] args) {
		new TelaDeLogin().setVisible(true);
	}
	
}
