
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class TelaDeApostas extends JFrame {

	private int vitoriasBrasil, vitoriasArgentina;
	private JTable tabela;
	
	private void mostraResultado(int paisApostado) {
		int resultado = new Random().nextInt(2) + 1;
		if (resultado == paisApostado) {
			JOptionPane.showMessageDialog(this, "Parab�ns!!");
		} else {
			JOptionPane.showMessageDialog(this, "loser...");
		}
		if (resultado == 1) {
			vitoriasBrasil++;
		} else {
			vitoriasArgentina++;
		}
		tabela.getModel().setValueAt(vitoriasBrasil, 0, 0);
		tabela.getModel().setValueAt(vitoriasArgentina, 0, 1);
	}
	
	public TelaDeApostas() { 
		ImageIcon bandeiraBrasil = new ImageIcon(getClass().getResource("bandeira_brasil.jpg"));
		ImageIcon bandeiraArgentina = new ImageIcon(getClass().getResource("bandeira_argentina.jpg"));
		final JRadioButton brasil = new JRadioButton("Brasil", bandeiraBrasil, true);
		final JRadioButton argentina = new JRadioButton("Argentina", bandeiraArgentina);
		ButtonGroup grupo = new ButtonGroup();
		grupo.add(brasil);
		grupo.add(argentina);
		JCheckBox apostarDinheiro = new JCheckBox("Apostar dinheiro?");
		JButton fazerAposta = new JButton("Fazer aposta");
		fazerAposta.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				int paisApostado;
				if (brasil.isSelected()) {
					paisApostado = 1;
				} else {
					paisApostado = 2;
				}
				mostraResultado(paisApostado);
			}
		});
		Object[] colunas = new Object[]{"Brasil", "Argentina"};
		Object[][] valores = new Object[][]{{0, 0}};
		DefaultTableModel modelo = new DefaultTableModel(valores, colunas);
		tabela = new JTable(modelo);
		JScrollPane scroll = new JScrollPane(tabela);
		JPanel container = new JPanel();
		container.setLayout(new BoxLayout(container, BoxLayout.PAGE_AXIS));
		container.add(brasil);
		container.add(argentina);
		container.add(apostarDinheiro);
		container.add(fazerAposta);
		container.add(scroll);
		add(container);
		pack();
	}
	
	public static void main(String[] args) {
		new TelaDeApostas().setVisible(true);
	}
}
