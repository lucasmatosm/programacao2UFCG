/*Aluno: Lucas Matos de Medeiros
Matricula: 113111435*/

package lp2.lab05;
/** 
Classe para o calculo de uma sequencia de Fibonacci
@version 1.00 28 de novembro de 2013
@author Lucas Matos de Medeiros
*/
public class Fibonacci {
	private int atual;
	private int anterior; 
	/**
	construtor da famosa serie de Fibonacci
	@param atual
	@param anterior
	*/
	public Fibonacci(int atual, int anterior) { 
		this.atual = atual;
		this.anterior = anterior;
	}	
	/**
	Obtem termo n-esimo termo da sequencia
	@param n n-esimo termo
	@return o valor atual n-esimo termo da sequencia
	*/
	public int fibo(int n){	
	for (int i = 1; i <= n; i++) { 
		if (i == 1) { 
			anterior = 0;
			atual = 1;  
		}
		else { 
			atual += anterior; 
		    anterior = atual - anterior; 
		} 
		} 
		return atual; 
}
	}

