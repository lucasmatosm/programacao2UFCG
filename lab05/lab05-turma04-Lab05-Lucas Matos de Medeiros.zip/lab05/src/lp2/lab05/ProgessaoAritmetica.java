package lp2.lab05;
/*Aluno: Lucas Matos de Medeiros
Matricula: 113111435*/
/** 
Classe para o calculo de uma progressao aritmetica
@version 1.00 26 de novembro de 2013
@author Lucas Matos de Medeiros
*/
public class ProgessaoAritmetica {
private int primeiro, razao, proximo, termo;
private java.lang.String geraTermos;
/**
construtor de uma progressao aritmetica
@param primeiro - primeiro termo da sequencia
@param razao - razao da sequencia
*/
public  ProgessaoAritmetica(int primeiro, int razao){
	this.primeiro = primeiro;
	this.razao = razao;
	proximo = primeiro;
}

/**
Obtem a razão da progressao aritmetica
@return retorna a razao
*/
public int getRazao(){
return razao;}
/**
Obtem o proximo valor da progressao aritmetica
@return o proximo valor da progressão
*/
public int proximo(){
	proximo += razao;
	return proximo;
}
/**
Obtem o valor atual n-esimo termo progressao aritmetica
@return o valor atual n-esimo termo progressao
*/
public int primeiro(){
	primeiro = proximo;
	return primeiro;
}

/**
Obtem termo n-esimo progressao aritmetica
@param n n-esimo termo
@return o valor atual n-esimo termo da progressao
*/
public int termo(int n){
	if (n <= 0){
	return primeiro;}
	else{
		termo = primeiro + (n-1)*razao;
		proximo = termo;
		return termo;
	}
}
/**
Obtem os n termos da progressao aritmetica
@param n
@return os n termos da progressão
*/
public java.lang.String geraTermos(int n){
	proximo = primeiro;
	geraTermos = Integer.toString(primeiro) + ",";
	for(int i = 1; i < n; i++){
	    if(i == (n-1)){
	    	geraTermos += (proximo());	
	}
	    else{
	    	geraTermos += (proximo())+",";	
	    }    
	}
	return geraTermos;
}
}