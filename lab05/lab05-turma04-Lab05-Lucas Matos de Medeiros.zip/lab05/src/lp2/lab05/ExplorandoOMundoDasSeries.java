package lp2.lab05;
/*Aluno: Lucas Matos de Medeiros
Matricula: 113111435*/
import java.util.*;

/** 
Classe para a implementacao de uma progressao aritmetica e uma serie de Fibonacci
@version 1.00 29 de novembro de 2013
@author Lucas Matos de Medeiros
*/
public class ExplorandoOMundoDasSeries {
	private static Scanner sc = new Scanner(System.in);
	private static boolean formapa = false, formafibo = false;
	private static int opcao, primeiro, razao;
	private static boolean sair;
	
/**
metodo main
*/
public static void main(String[] args) {
		while(opcao != 6){
			Menu();
			opcao = sc.nextInt();
		    escolhemenu(opcao);
		    if (sair == true){break;}
		}
}


/**
condicionais do menu para o usuario
@param opcao
*/
private static void escolhemenu(int opcao){
switch(opcao){
case 1: 
	System.out.println("Digite o primeiro termo da PA e a razão:");
	primeiro = sc.nextInt();
	razao = sc.nextInt();
	ProgessaoAritmetica pa = new ProgessaoAritmetica(primeiro, razao);
formapa = true;	break;
case 2:
	Fibonacci sequencia = new Fibonacci(0,0);
	formafibo = true;break;
case 3:
	if(formapa == false){
		System.out.println("Para visualizar um termo precisa criar a PA antes");break;
	}
	else{
		System.out.println("Digite o n-esimo termo a ser visualizado");
		int termo1 = sc.nextInt();
		ProgessaoAritmetica pa2 = new ProgessaoAritmetica(primeiro, razao);
		System.out.println("Um termo qualquer " +"(" + termo1 + "): " + pa2.termo(termo1));break;
	}
case 4:
	if(formafibo == false){
		System.out.println("Para visualizar um termo precisa criar a sequencia antes");break;
	}
	else{
		Fibonacci sequencia2 = new Fibonacci(0,0);
		System.out.println("Digite o n-esimo termo a ser visualizado");
		int termo = sc.nextInt();
		System.out.println("Um termo qualquer" +"(" + termo + "): "+ sequencia2.fibo(termo));break;
	}
case 5:
	if (formapa == false && formafibo == false){
		System.out.println("Para visualizar as sequencias precisam ser criadas antes");
	}
	else{
		System.out.println("Digite a quantidade de termos a ser visualizada:");
		int n = sc.nextInt();
		Fibonacci sequencia3 = new Fibonacci(0,0);
		ProgessaoAritmetica pa3 = new ProgessaoAritmetica(primeiro, razao);
		System.out.println(n + " primeiros termos da PA: um por vez...");
		System.out.println("Primeiro: " + pa3.primeiro());
		for (int i = 2; i <=n; i++) {
			System.out.println("Termo " + i + ": " + pa3.proximo());
		}
		System.out.println(n + " primeiros termos da sequencia de Fibonacci: um por vez...");
		for (int i = 0; i <= n; i++) { 
			System.out.println("Termo " + i + ": " +sequencia3.fibo(i)); 
	}
		break;
	}
case 6:
	sair = true;break;
}
}
/**
Cria O menu do usuario
*/
private static void Menu(){
	System.out.println("Selecione uma opção:");
	System.out.println("1. Para criar uma progressao aritmetica;");
	System.out.println("2. Para criar uma serie de Fibonacci;");
	System.out.println("3. Para ver o termo “n” da sua PA;");
	System.out.println("4. Para ver o termo “n” da serie de Fibonacci;");
	System.out.println("5. Para mostrar os “n” primeiros termos da sua PA e da serie de Fibonacci;");
	System.out.println("6. Para sair.");	
}
}
